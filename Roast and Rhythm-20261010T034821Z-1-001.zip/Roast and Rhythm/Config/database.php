<?php
// Database configuration credentials
$host     = "localhost";
$username = "root";
$password = "";
$dbname   = "roast and rhythm"; // Change this if your database name is different

// Create connection using MySQLi
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection established successfully
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Set charset to UTF-8 to prevent accent/symbol display glitches
$conn->set_charset("utf8mb4");
?>