<div class="order-type-selection">
    <h3>Choose Order Type</h3>

    <label class="order-type-option">
        <input
            type="radio"
            name="checkout_order_type"
            value="delivery"
        >
        <span>Delivery</span>
    </label>

    <label class="order-type-option">
        <input
            type="radio"
            name="checkout_order_type"
            value="self_pickup"
        >
        <span>Self Pick Up</span>
    </label>
</div>

<form action="cart.php" method="POST" id="checkout-form">
    <input type="hidden" name="action" value="place_order">
    <input type="hidden" name="order_type" id="checkout-order-type">

    <button type="submit" class="checkout-btn">
        Confirm &amp; Place Order
    </button>
</form>

<style>
.order-type-selection {
    margin: 20px 0;
    padding: 20px;
    background: #fff;
    border: 1px solid #e5e5e5;
    border-radius: 12px;
}

.order-type-selection h3 {
    margin: 0 0 16px;
    font-size: 18px;
    color: #333;
}

.order-type-option {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 10px 0;
    padding: 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.2s ease;
}

.order-type-option:hover {
    border-color: #8b5e3c;
    background: #faf6f2;
}

.order-type-option input {
    width: 18px;
    height: 18px;
    accent-color: #8b5e3c;
    cursor: pointer;
}

.order-type-option span {
    font-size: 15px;
    color: #333;
}

.checkout-btn {
    display: block;
    width: 100%;
    padding: 15px 20px;
    border: none;
    border-radius: 8px;
    background: #8b5e3c;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.2s ease;
}

.checkout-btn:hover {
    background: #6f482d;
}

.checkout-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const checkoutForm = document.getElementById('checkout-form');
    const orderTypeInput = document.getElementById('checkout-order-type');
    const orderTypeOptions = document.querySelectorAll(
        'input[name="checkout_order_type"]'
    );

    if (!checkoutForm || !orderTypeInput) {
        return;
    }

    checkoutForm.addEventListener('submit', function (event) {
        const selectedOrderType = document.querySelector(
            'input[name="checkout_order_type"]:checked'
        );

        if (!selectedOrderType) {
            event.preventDefault();
            alert('Please select Delivery or Self Pick Up.');
            return;
        }

        orderTypeInput.value = selectedOrderType.value;
    });

    orderTypeOptions.forEach(function (option) {
        option.addEventListener('change', function () {
            orderTypeInput.value = this.value;
        });
    });
});
</script>