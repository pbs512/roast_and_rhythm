<?php
header('Content-Type: application/json');
include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Order ID is required'
    ]);
    exit;
}

$order_id = (int)$_GET['order_id'];

try {
    $stmt = $conn->prepare("SELECT id, user_id, total_amount, order_type, table_number, status, pass_redeemed, created_at FROM orders WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $order_result = $stmt->get_result();

    if ($order = $order_result->fetch_assoc()) {
        $items_stmt = $conn->prepare("SELECT product_name, size, sugar, milk, extras, quantity, price FROM order_items WHERE order_id = ?");
        $items_stmt->bind_param("i", $order_id);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        $items = [];
        while ($item = $items_result->fetch_assoc()) {
            $items[] = [
                'name'     => $item['product_name'],
                'size'     => $item['size'],
                'sugar'    => $item['sugar'],
                'milk'     => $item['milk'],
                'extras'   => $item['extras'],
                'quantity' => (int)$item['quantity'],
                'price'    => (float)$item['price']
            ];
        }
        $items_stmt->close();

        echo json_encode([
            'success'       => true,
            'order_id'      => (int)$order['id'],
            'status'        => $order['status'],
            'order_type'    => $order['order_type'],
            'table_number'  => $order['table_number'],
            'total_amount'  => (float)$order['total_amount'],
            'pass_redeemed' => (bool)$order['pass_redeemed'],
            'created_at'    => $order['created_at'],
            'items'         => $items
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Order not found'
        ]);
    }
    
    $stmt->close();

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>