<?php
// customer/update_location.php
header('Content-Type: application/json');
include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['order_id'], $data['lat'], $data['lng'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters.']);
    exit;
}

$order_id = (int)$data['order_id'];
$user_lat = (float)$data['lat'];
$user_lng = (float)$data['lng'];

// Shop Location Coordinates
$shop_lat = 14.599512; 
$shop_lng = 120.984222;

function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371000; // Earth radius in meters
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earthRadius * $c;
}

function normalizeStatus($status) {
    $status = strtolower(trim($status));
    $map = [
        'order placed'     => 'placed',
        'preparing'        => 'in_preparation',
        'ready for pickup' => 'ready_for_pickup'
    ];
    return $map[$status] ?? $status;
}

$distance = round(calculateDistance($user_lat, $user_lng, $shop_lat, $shop_lng));

// 1. Fetch current order status and barista name directly from database
$stmt = $conn->prepare("SELECT status, barista_name FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

$current_status = 'placed';
$barista_name = 'Mark'; // Fallback default name

if ($row = $result->fetch_assoc()) {
    $current_status = normalizeStatus($row['status']);
    if (!empty($row['barista_name'])) {
        $barista_name = $row['barista_name'];
    }
}
$stmt->close();

$new_status = $current_status;

// 2. Proximity Auto-Triggers: Update status in DB based on distance threshold
if ($distance <= 50 && ($current_status === 'placed' || $current_status === 'in_preparation')) {
    // Arrival threshold: User within 50m -> Mark as ready for pickup
    $new_status = 'ready_for_pickup';
} elseif ($distance <= 500 && $current_status === 'placed') {
    // Approaching threshold: User within 500m -> Mark as in preparation
    $new_status = 'in_preparation';
}

// 3. Perform database update if the status changed
if ($new_status !== $current_status) {
    $updateStmt = $conn->prepare("UPDATE orders SET status = ?, barista_name = ? WHERE id = ?");
    $updateStmt->bind_param("ssi", $new_status, $barista_name, $order_id);
    $updateStmt->execute();
    $updateStmt->close();
}

// 4. Return distance, status, and barista name to frontend
echo json_encode([
    'success'      => true,
    'distance'     => $distance,
    'status'       => $new_status,
    'barista_name' => $barista_name
]);
?>