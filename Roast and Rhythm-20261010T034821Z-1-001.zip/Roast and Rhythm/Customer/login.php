<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Direct Database Connection Setup
$host = 'localhost';
$db   = 'roast and rhythm'; // Change if your phpMyAdmin database name is different
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

if (file_exists('../config/database.php')) {
    include_once '../config/database.php';
}

if (!isset($pdo) || $pdo === null) {
    try {
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        $error_msg = "Database Connection Error: " . $e->getMessage();
    }
}

$error_msg = $error_msg ?? '';
$success_msg = '';

if (isset($_SESSION['success'])) {
    $success_msg = $_SESSION['success'];
    unset($_SESSION['success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($pdo)) {
    $login_input = trim($_POST['email'] ?? '');
    $password    = $_POST['password'] ?? '';

    if (empty($login_input) || empty($password)) {
        $error_msg = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
            $stmt->execute([$login_input, $login_input]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['fullname']  = $user['fullname'];
                $_SESSION['user_role'] = $user['role'] ?? 'customer';

                header("Location: dashboard.php");
                exit;
            } else {
                $error_msg = "Invalid email/username or password.";
            }
        } catch (PDOException $e) {
            $error_msg = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Welcome Back</title>
    <style>
        :root {
            --bg-main: #FAF6F0;
            --card-bg: #FFFFFF;
            --dark-espresso: #3D2314;
            --medium-latte: #8C6239;
            --soft-caramel: #C49A6C;
            --cream-accent: #FDFBF7;
            --text-main: #2C1D11;
            --border-light: #EFE8DE;
            --shadow-lg: 0 20px 40px rgba(61, 35, 20, 0.12);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-container {
            display: flex;
            width: 100%;
            max-width: 960px;
            background-color: var(--card-bg);
            border-radius: 28px;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--border-light);
            overflow: hidden;
            min-height: 560px;
        }

        .brand-panel {
            flex: 1;
            background: linear-gradient(135deg, #3D2314 0%, #5A3821 100%);
            padding: 50px 40px;
            color: #FFFFFF;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .brand-header { display: flex; align-items: center; gap: 12px; text-decoration: none; color: #FFFFFF; }
        .brand-logo { font-size: 2rem; }
        .brand-title { font-size: 1.5rem; font-weight: 700; }

        .brand-badge {
            display: inline-block;
            background: rgba(196, 154, 108, 0.2);
            border: 1px solid var(--soft-caramel);
            color: var(--soft-caramel);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        .brand-heading { font-size: 2.2rem; line-height: 1.2; font-weight: 800; margin-bottom: 15px; }
        .brand-heading span { color: var(--soft-caramel); }
        .brand-desc { color: #E0D3C5; font-size: 0.95rem; line-height: 1.6; }

        .perks-list { list-style: none; margin-top: 25px; }
        .perks-list li { display: flex; align-items: center; gap: 10px; font-size: 0.9rem; color: #E0D3C5; margin-bottom: 12px; }
        .perks-list li span { color: var(--soft-caramel); font-weight: bold; }

        .form-panel {
            flex: 1.1;
            padding: 50px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background-color: var(--card-bg);
        }

        .form-header { margin-bottom: 25px; }
        .form-title { font-size: 1.8rem; color: var(--dark-espresso); font-weight: 800; }
        .form-subtitle { font-size: 0.9rem; color: var(--medium-latte); margin-top: 5px; }

        .alert-error {
            background-color: #F8D7DA;
            color: #721C24;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            border: 1px solid #F5C6CB;
        }

        .alert-success {
            background-color: #D4EDDA;
            color: #155724;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            border: 1px solid #C3E6CB;
        }

        .input-group { margin-bottom: 20px; }
        .input-label { display: block; font-size: 0.85rem; font-weight: 700; color: var(--dark-espresso); margin-bottom: 8px; text-transform: uppercase; }
        
        .input-field {
            width: 100%;
            padding: 14px 18px;
            border-radius: 14px;
            border: 1.5px solid var(--border-light);
            background-color: var(--cream-accent);
            font-size: 0.95rem;
            color: var(--text-main);
            outline: none;
            transition: var(--transition);
        }

        .input-field:focus {
            border-color: var(--medium-latte);
            background-color: #FFFFFF;
            box-shadow: 0 0 0 4px rgba(140, 98, 57, 0.1);
        }

        /* Password Wrapper & Toggle Button */
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        .password-wrapper .input-field {
            padding-right: 48px;
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--medium-latte);
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 4px;
            user-select: none;
            transition: var(--transition);
        }

        .toggle-password:hover {
            color: var(--dark-espresso);
        }

        .btn-submit {
            width: 100%;
            padding: 15px;
            background-color: var(--dark-espresso);
            color: #FFFFFF;
            border: none;
            border-radius: 14px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 6px 16px rgba(61, 35, 20, 0.2);
            margin-top: 10px;
        }

        .btn-submit:hover { background-color: var(--medium-latte); transform: translateY(-2px); }

        .form-footer { margin-top: 25px; text-align: center; font-size: 0.9rem; color: var(--medium-latte); }
        .form-footer a { color: var(--dark-espresso); font-weight: 700; text-decoration: none; }
        .form-footer a:hover { color: var(--soft-caramel); text-decoration: underline; }

        @media (max-width: 850px) {
            .auth-container { flex-direction: column; }
            .brand-panel, .form-panel { padding: 35px 30px; }
        }
    </style>
</head>
<body>

    <div class="auth-container">
        <div class="brand-panel">
            <a href="index.php" class="brand-header">
                <span class="brand-logo">☕</span>
                <span class="brand-title">Roast & Rhythm</span>
            </a>

            <div class="brand-content">
                <span class="brand-badge">Welcome Back</span>
                <h1 class="brand-heading">Your daily brew <span>awaits you.</span></h1>
                <p class="brand-desc">Log in to view your ongoing orders, manage your Coffee Pass subscription, and order your favorites.</p>

                <ul class="perks-list">
                    <li><span>✓</span> Fast one-click reordering</li>
                    <li><span>✓</span> Live proximity pickup updates</li>
                    <li><span>✓</span> Coffee Pass wallet balance</li>
                </ul>
            </div>

            <p style="font-size: 0.8rem; color: rgba(255,255,255,0.6);">&copy; <?php echo date('Y'); ?> Roast & Rhythm</p>
        </div>

        <div class="form-panel">
            <div class="form-header">
                <h2 class="form-title">Sign In</h2>
                <p class="form-subtitle">Enter your credentials to access your account.</p>
            </div>

            <?php if (!empty($success_msg)): ?>
                <div class="alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
            <?php endif; ?>

            <?php if (!empty($error_msg)): ?>
                <div class="alert-error"><?php echo htmlspecialchars($error_msg); ?></div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="input-group">
                    <label class="input-label" for="email">Email Address or Username</label>
                    <input type="text" id="email" name="email" class="input-field" placeholder="your@email.com" required>
                </div>

                <div class="input-group">
                    <label class="input-label" for="password">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" class="input-field" placeholder="••••••••" required>
                        <button type="button" class="toggle-password" onclick="togglePasswordVisibility('password', this)" aria-label="Toggle password visibility">👁️</button>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Sign In</button>
            </form>

            <div class="form-footer">
                Don't have an account? <a href="register.php">Sign up here</a>
            </div>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(fieldId, button) {
            const input = document.getElementById(fieldId);
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }
    </script>
</body>
</html>