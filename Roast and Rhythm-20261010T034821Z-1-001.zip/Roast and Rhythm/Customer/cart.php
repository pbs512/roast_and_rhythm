<?php
session_start();

// Redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/database.php';

$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$user_id = (int)$_SESSION['user_id'];

// --- HANDLE ITEM REMOVAL FROM CART ---
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $remove_id = $_GET['id'];
    if (isset($_SESSION['cart'][$remove_id])) {
        unset($_SESSION['cart'][$remove_id]);
    }
    header("Location: cart.php");
    exit();
}

// --- HANDLE CHECKOUT / PLACE ORDER DIRECTLY IN CART.PHP ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'place_order') {
    if (!empty($_SESSION['cart'])) {
        
        $status = 'Pending';

        // 1. Create the main order record
        $order_stmt = $conn->prepare("INSERT INTO orders (user_id, status) VALUES (?, ?)");
        $order_stmt->bind_param("is", $user_id, $status);
        
        if ($order_stmt->execute()) {
            $order_id = $conn->insert_id;
            $order_stmt->close();

            // 2. Insert each item into order_items
            $stmt = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, size, sugar_level, ice_level, milk_base, add_extras) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            foreach ($_SESSION['cart'] as $item) {
                // Determine product ID cleanly across potential array key formats
                $product_id = isset($item['product_id']) ? (int)$item['product_id'] : (isset($item['id']) ? (int)$item['id'] : 0);
                $quantity   = isset($item['quantity']) ? (int)$item['quantity'] : 1;
                
                // Check if the item is explicitly marked as a pastry/food or lacks drink options
                $is_pastry = (!empty($item['category']) && strtolower($item['category']) === 'pastry') 
                          || (!empty($item['type']) && strtolower($item['type']) === 'food')
                          || (isset($item['is_pastry']) && $item['is_pastry'] == true);

                if ($is_pastry) {
                    $size        = 'N/A';
                    $sugar_level = 'N/A';
                    $ice_level   = 'N/A';
                    $milk_base   = 'N/A';
                    $add_extras  = 'None';
                } else {
                    // Coffee/Drink customizations
                    $size        = !empty($item['size']) ? $item['size'] : 'Regular';
                    $sugar_level = !empty($item['sugar']) ? $item['sugar'] : (!empty($item['sugar_level']) ? $item['sugar_level'] : '100%');
                    $ice_level   = !empty($item['ice_level']) ? $item['ice_level'] : 'Regular Ice';
                    $milk_base   = !empty($item['milk']) ? $item['milk'] : (!empty($item['milk_base']) ? $item['milk_base'] : 'Whole Milk');
                    $add_extras  = !empty($item['extras']) ? $item['extras'] : (!empty($item['add_extras']) ? $item['add_extras'] : 'None');
                }

                $stmt->bind_param(
                    "iiisssss", 
                    $order_id, 
                    $product_id, 
                    $quantity, 
                    $size, 
                    $sugar_level, 
                    $ice_level, 
                    $milk_base, 
                    $add_extras
                );
                $stmt->execute();
            }
            $stmt->close();

            // 3. Clear cart and redirect to order history (diary.php)
            unset($_SESSION['cart']);
            header("Location: diary.php?success=1");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Shopping Cart</title>
    <style>
        :root {
            --cream: #FAF5EF;
            --dark-brown: #3C2A20;
            --medium-brown: #795548;
            --light-cream: #FFFDFB;
            --text-main: #2F1F17;
            --text-muted: #8D7B70;
            --shadow: 0 8px 24px rgba(60, 42, 32, 0.08);
            --transition: all 0.25s ease;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--cream);
            color: var(--text-main);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .back-link {
            text-decoration: none;
            color: var(--medium-brown);
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 25px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--dark-brown);
            transform: translateX(-3px);
        }

        .cart-container {
            width: 100%;
            max-width: 600px;
            background-color: var(--light-cream);
            padding: 35px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(121, 85, 72, 0.12);
            box-sizing: border-box;
        }

        h2 {
            color: var(--dark-brown);
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.8rem;
            border-bottom: 2px solid var(--dark-brown);
            padding-bottom: 12px;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 0;
            border-bottom: 1px solid rgba(121, 85, 72, 0.1);
        }

        .cart-item:last-of-type {
            border-bottom: 1px dashed rgba(121, 85, 72, 0.2);
        }

        .item-details strong {
            color: var(--dark-brown);
            font-size: 1.05rem;
        }

        .item-meta {
            font-size: 0.82rem;
            color: var(--text-muted);
            margin-top: 4px;
            display: block;
        }

        .item-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .item-price {
            font-weight: 600;
            color: var(--text-main);
            font-size: 1.05rem;
        }

        .remove-btn {
            color: #a83232;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 6px;
            background-color: rgba(168, 50, 50, 0.05);
            transition: var(--transition);
        }

        .remove-btn:hover {
            background-color: rgba(168, 50, 50, 0.12);
        }

        .total-section {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            font-size: 1.3rem;
            margin-top: 25px;
            padding-top: 15px;
            color: var(--dark-brown);
        }

        .checkout-btn {
            width: 100%;
            display: block;
            text-align: center;
            box-sizing: border-box;
            background-color: var(--dark-brown);
            color: white;
            padding: 14px;
            border: none;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            text-decoration: none;
            margin-top: 25px;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(60, 42, 32, 0.15);
        }

        .checkout-btn:hover {
            background-color: var(--medium-brown);
            transform: translateY(-1px);
        }

        .empty-cart-box {
            text-align: center;
            padding: 50px 20px;
            color: var(--text-muted);
            border: 1px dashed rgba(121, 85, 72, 0.20);
            border-radius: 16px;
            background-color: var(--cream);
        }
    </style>
</head>
<body>

<div class="cart-container">
    <a href="index.php" class="back-link">← Continue Shopping</a>
    <h2>Shopping Cart</h2>

    <?php if (empty($cart)): ?>
        <div class="empty-cart-box">
            <p style="margin: 0; font-size: 1.1rem; font-weight: 600;">Your cart is empty</p>
            <p style="margin: 5px 0 0; font-size: 0.9rem;">Looks like you haven't added any premium roasts yet.</p>
        </div>
    <?php else: ?>
        <?php 
        $grand_total = 0;
        foreach ($cart as $key => $item): 
            $price = isset($item['price']) ? (float)$item['price'] : 150.00; 
            $item_total = $price * $item['quantity'];
            $grand_total += $item_total;
            
            // Build custom specifications summary string, filtering out N/A and None
            $specs = [];
            if (!empty($item['size']) && $item['size'] !== 'N/A')               $specs[] = "Size: " . $item['size'];
            if (!empty($item['sugar_level']) && $item['sugar_level'] !== 'N/A') $specs[] = "Sugar: " . $item['sugar_level'];
            if (!empty($item['ice_level']) && $item['ice_level'] !== 'N/A')     $specs[] = "Ice: " . $item['ice_level'];
            if (!empty($item['milk_base']) && $item['milk_base'] !== 'N/A')     $specs[] = "Milk: " . $item['milk_base'];
            if (!empty($item['add_extras']) && !in_array($item['add_extras'], ['None', 'N/A'])) $specs[] = "Extras: " . $item['add_extras'];
            
            $spec_summary = !empty($specs) ? implode(" | ", $specs) : '';
        ?>
            <div class="cart-item">
                <div class="item-details">
                    <strong><?php echo htmlspecialchars($item['name']); ?></strong> 
                    <span style="color: var(--text-muted); font-size: 0.9rem; margin-left: 5px;">x<?php echo $item['quantity']; ?></span>
                    
                    <?php if (!empty($spec_summary)): ?>
                        <span class="item-meta">✨ <?php echo htmlspecialchars($spec_summary); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item-actions">
                    <span class="item-price">₱<?php echo number_format($item_total, 2); ?></span>
                    <a href="cart.php?action=remove&id=<?php echo urlencode($key); ?>" class="remove-btn">Remove</a>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="total-section">
            <span>Grand Total:</span>
            <span>₱<?php echo number_format($grand_total, 2); ?></span>
        </div>

        <!-- Self-submitting checkout form -->
        <form action="cart.php" method="POST">
            <input type="hidden" name="action" value="place_order">
            <button type="submit" class="checkout-btn">Confirm & Place Order</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>