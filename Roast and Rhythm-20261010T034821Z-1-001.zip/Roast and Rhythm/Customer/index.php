<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user_logged_in = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Artisanal Coffee & Warm Moments</title>
    <style>
        :root {
            --bg-main: #FDFBF7;
            --card-bg: #FFFFFF;
            --accent-bg: #FAF6F0;
            --dark-espresso: #3D2314;
            --medium-latte: #8C6239;
            --soft-caramel: #C49A6C;
            --text-main: #2C1D11;
            --border-light: #EFE8DE;
            --shadow: 0 10px 30px rgba(61, 35, 20, 0.08);
            --transition: all 0.3s ease;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            line-height: 1.6;
        }

        /* --- NAVBAR --- */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 8%;
            background-color: var(--card-bg);
            border-bottom: 1px solid var(--border-light);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .brand-header {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .brand-logo { font-size: 1.8rem; }

        .brand-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--dark-espresso);
            letter-spacing: -0.3px;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-link {
            text-decoration: none;
            color: var(--dark-espresso);
            font-weight: 600;
            padding: 10px 18px;
            border-radius: 25px;
            transition: var(--transition);
        }

        .btn-link:hover {
            background-color: var(--accent-bg);
        }

        .btn-primary {
            background-color: var(--dark-espresso);
            color: #FFFFFF !important;
            padding: 10px 22px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(61, 35, 20, 0.15);
        }

        .btn-primary:hover {
            background-color: var(--medium-latte);
            transform: translateY(-2px);
        }

        .btn-outline {
            border: 1.5px solid var(--dark-espresso);
            color: var(--dark-espresso);
            padding: 10px 22px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .btn-outline:hover {
            background-color: var(--dark-espresso);
            color: #FFFFFF;
        }

        /* --- HERO SECTION --- */
        .hero {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 80px 8%;
            gap: 40px;
            min-height: 80vh;
        }

        .hero-content {
            max-width: 580px;
        }

        .hero-badge {
            display: inline-block;
            background-color: var(--accent-bg);
            border: 1px solid var(--soft-caramel);
            color: var(--medium-latte);
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 20px;
        }

        .hero-title {
            font-size: 3.2rem;
            line-height: 1.15;
            color: var(--dark-espresso);
            font-weight: 800;
            margin-bottom: 20px;
            letter-spacing: -1px;
        }

        .hero-title span {
            color: var(--soft-caramel);
        }

        .hero-description {
            font-size: 1.1rem;
            color: var(--medium-latte);
            margin-bottom: 35px;
        }

        .hero-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .hero-image-card {
            flex: 1;
            max-width: 480px;
            background: linear-gradient(135deg, var(--accent-bg) 0%, #FFFFFF 100%);
            border: 1px solid var(--border-light);
            border-radius: 32px;
            padding: 40px;
            text-align: center;
            box-shadow: var(--shadow);
            position: relative;
        }

        .hero-illustration {
            font-size: 6rem;
            margin-bottom: 20px;
            display: inline-block;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .pass-preview-tag {
            background: var(--dark-espresso);
            color: #FFFFFF;
            padding: 12px 20px;
            border-radius: 16px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-top: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .pass-preview-tag span {
            color: var(--soft-caramel);
            font-weight: 700;
        }

        /* --- FEATURES / HIGHLIGHTS --- */
        .features {
            background-color: var(--card-bg);
            padding: 60px 8%;
            border-top: 1px solid var(--border-light);
            border-bottom: 1px solid var(--border-light);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
        }

        .feature-card {
            background-color: var(--accent-bg);
            padding: 30px;
            border-radius: 20px;
            border: 1px solid var(--border-light);
            transition: var(--transition);
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
        }

        .feature-icon {
            font-size: 2rem;
            margin-bottom: 15px;
        }

        .feature-title {
            font-size: 1.15rem;
            color: var(--dark-espresso);
            font-weight: 700;
            margin-bottom: 8px;
        }

        .feature-desc {
            font-size: 0.9rem;
            color: var(--medium-latte);
        }

        /* --- CTA SECTION --- */
        .cta-section {
            padding: 80px 8%;
            text-align: center;
            background: linear-gradient(135deg, #3D2314 0%, #5A3821 100%);
            color: #FFFFFF;
            margin: 60px 8%;
            border-radius: 32px;
            box-shadow: var(--shadow);
        }

        .cta-section h2 {
            font-size: 2.2rem;
            margin-bottom: 15px;
        }

        .cta-section p {
            color: var(--soft-caramel);
            margin-bottom: 30px;
            font-size: 1.05rem;
        }

        /* --- FOOTER --- */
        footer {
            text-align: center;
            padding: 30px;
            color: var(--medium-latte);
            font-size: 0.85rem;
            border-top: 1px solid var(--border-light);
        }

        @media (max-width: 900px) {
            .hero {
                flex-direction: column;
                text-align: center;
                padding-top: 40px;
            }

            .hero-buttons {
                justify-content: center;
            }

            .hero-title {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar">
        <a href="index.php" class="brand-header">
            <span class="brand-logo">☕</span>
            <span class="brand-title">Roast & Rhythm</span>
        </a>

        <div class="nav-actions">
            <?php if ($user_logged_in): ?>
                <a href="dashboard.php" class="btn-primary">Go to Dashboard</a>
                <a href="logout.php" class="btn-link" style="color: #A94442;">Sign Out</a>
            <?php else: ?>
                <a href="login.php" class="btn-link">Sign In</a>
                <a href="register.php" class="btn-primary">Create Account</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section class="hero">
        <div class="hero-content">
            <span class="hero-badge">Welcome to Roast & Rhythm</span>
            <h1 class="hero-title">Crafted Brews, <span>Perfect Rhythm.</span></h1>
            <p class="hero-description">
                Experience artisanal coffees, fresh pastries, and traditional delicacies handcrafted for your day. Order ahead or subscribe to our Coffee Pass for daily perks.
            </p>

            <div class="hero-buttons">
                <?php if ($user_logged_in): ?>
                    <a href="dashboard.php" class="btn-primary" style="padding: 14px 28px; font-size: 1rem;">Order Now</a>
                <?php else: ?>
                    <a href="register.php" class="btn-primary" style="padding: 14px 28px; font-size: 1rem;">Get Started</a>
                    <a href="dashboard.php" class="btn-outline" style="padding: 14px 28px; font-size: 1rem;">Browse Menu</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="hero-image-card">
            <div class="hero-illustration">☕</div>
            <h3 style="color: var(--dark-espresso); margin-bottom: 8px;">Freshly Brewed Daily</h3>
            <p style="color: var(--medium-latte); font-size: 0.9rem;">Enjoy live tracking and automatic proximity brewing when you pick up.</p>
            
            <div class="pass-preview-tag">
                <span>🎟️ Coffee Pass</span>
                <span>Up to 30 Cups/mo</span>
            </div>
        </div>
    </section>

    <!-- FEATURES -->
    <section class="features">
        <div class="feature-card">
            <div class="feature-icon">🚀</div>
            <h3 class="feature-title">Smart Pickup</h3>
            <p class="feature-desc">Our automated proximity radar detects when you get close so your cup is served fresh and hot.</p>
        </div>

        <div class="feature-card">
            <div class="feature-icon">🎟️</div>
            <h3 class="feature-title">Coffee Pass</h3>
            <p class="feature-desc">Subscribe to flexible monthly coffee passes and claim free drinks directly from your wallet.</p>
        </div>

        <div class="feature-card">
            <div class="feature-icon">🥐</div>
            <h3 class="feature-title">Artisanal Menu</h3>
            <p class="feature-desc">From Classic Espresso to Traditional Batirol and fresh croissants, customized to your taste.</p>
        </div>
    </section>

    <!-- CTA SECTION -->
    <section class="cta-section">
        <h2>Ready for Your Favorite Cup?</h2>
        <p>Sign in to unlock personalized options, save favorites, and redeem your Coffee Pass.</p>
        <?php if (!$user_logged_in): ?>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="register.php" class="btn-primary" style="background-color: var(--soft-caramel); color: var(--dark-espresso) !important;">Create Free Account</a>
                <a href="login.php" class="btn-outline" style="border-color: #FFFFFF; color: #FFFFFF;">Sign In</a>
            </div>
        <?php else: ?>
            <a href="dashboard.php" class="btn-primary" style="background-color: var(--soft-caramel); color: var(--dark-espresso) !important;">Open Order Dashboard</a>
        <?php endif; ?>
    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> Roast & Rhythm Coffee Shop. All rights reserved.
    </footer>

</body>
</html>