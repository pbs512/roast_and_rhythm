<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/database.php';

$message = '';
$message_type = '';
$user_id = (int)$_SESSION['user_id'];

// Check for success message from cart redirect
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $message = "🎉 Order placed successfully!";
    $message_type = "success";
}

// --- CHECK DATABASE TABLES FOR PRODUCT NAMES ---
$has_products_table = ($conn->query("SHOW TABLES LIKE 'products'")->num_rows > 0);
$has_menu_table     = ($conn->query("SHOW TABLES LIKE 'menu'")->num_rows > 0);

$prod_join_sql = "";
$prod_display_col = "oi.product_id";

if ($has_products_table) {
    if ($conn->query("SHOW COLUMNS FROM products LIKE 'name'")->num_rows > 0) {
        $prod_display_col = "p.name";
    } elseif ($conn->query("SHOW COLUMNS FROM products LIKE 'product_name'")->num_rows > 0) {
        $prod_display_col = "p.product_name";
    }
    $prod_join_sql = "LEFT JOIN products p ON oi.product_id = p.id";
} elseif ($has_menu_table) {
    if ($conn->query("SHOW COLUMNS FROM menu LIKE 'name'")->num_rows > 0) {
        $prod_display_col = "m.name";
    } elseif ($conn->query("SHOW COLUMNS FROM menu LIKE 'item_name'")->num_rows > 0) {
        $prod_display_col = "m.item_name";
    }
    $prod_join_sql = "LEFT JOIN menu m ON oi.product_id = m.id";
}

// --- HANDLE RE-ORDER ACTION (PUSH TO CART & REDIRECT) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'reorder_entire_past_order') {
    $order_id_to_copy = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
    
    if ($order_id_to_copy > 0) {
        $item_stmt = $conn->prepare("
            SELECT {$prod_display_col} AS product_name, oi.product_id, oi.quantity, oi.price, 
                   oi.size, oi.sugar, oi.milk, oi.extras
            FROM order_items oi
            {$prod_join_sql}
            WHERE oi.order_id = ?
        ");
        $item_stmt->bind_param("i", $order_id_to_copy);
        $item_stmt->execute();
        $items_result = $item_stmt->get_result();
        
        if ($items_result && $items_result->num_rows > 0) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            
            while ($item = $items_result->fetch_assoc()) {
                $p_name = !empty($item['product_name']) ? $item['product_name'] : 'Item';
                $price  = !empty($item['price']) ? (float)$item['price'] : 0.00;
                
                // Construct normalized item payload
                $cart_item = [
                    'id'          => $item['product_id'],
                    'product_id'  => $item['product_id'],
                    'name'        => $p_name,
                    'price'       => $price,
                    'quantity'    => (int)$item['quantity'],
                    'size'        => !empty($item['size']) ? $item['size'] : 'N/A',
                    'sugar'       => !empty($item['sugar']) ? $item['sugar'] : 'N/A',
                    'milk'        => !empty($item['milk']) ? $item['milk'] : 'N/A',
                    'extras'      => !empty($item['extras']) ? $item['extras'] : 'None'
                ];

                // Create unique key per item variant
                $cart_key = $item['product_id'] . '_' . md5(json_encode([
                    $cart_item['size'], $cart_item['sugar'], $cart_item['milk'], $cart_item['extras']
                ]));
                
                if (isset($_SESSION['cart'][$cart_key])) {
                    $_SESSION['cart'][$cart_key]['quantity'] += (int)$item['quantity'];
                } else {
                    $_SESSION['cart'][$cart_key] = $cart_item;
                }
            }

            $item_stmt->close();

            // Redirect directly to the cart page so the user sees the re-ordered items immediately
            header("Location: cart.php?reordered=1");
            exit();
        }
        $item_stmt->close();
    }
}

// --- FETCH ORDERS & DISPLAY CUSTOMIZATIONS EXACTLY FROM DB COLUMNS ---
$orders = [];

$has_user_id_col = ($conn->query("SHOW COLUMNS FROM orders LIKE 'user_id'")->num_rows > 0);
$has_cust_id_col = ($conn->query("SHOW COLUMNS FROM orders LIKE 'customer_id'")->num_rows > 0);

$where_conditions = [];
if ($has_user_id_col) $where_conditions[] = "o.user_id = $user_id";
if ($has_cust_id_col) $where_conditions[] = "o.customer_id = $user_id";
$where_sql = !empty($where_conditions) ? "(" . implode(" OR ", $where_conditions) . ")" : "1=1";

$query = "SELECT o.id AS order_id, o.status, DATE_FORMAT(o.created_at, '%b %d, %Y - %h:%i %p') AS order_date,
                 {$prod_display_col} AS product_name, oi.quantity,
                 oi.size, oi.sugar, oi.milk, oi.extras
          FROM orders o
          LEFT JOIN order_items oi ON o.id = oi.order_id
          {$prod_join_sql}
          WHERE {$where_sql}
          ORDER BY o.created_at DESC";

$result = $conn->query($query);

// Function to validate if DB option is genuine (not empty, N/A, or None)
function isValidSpec($val) {
    if ($val === null || $val === '') return false;
    $v = strtoupper(trim($val));
    return !in_array($v, ['N/A', 'NONE', 'NULL', '']);
}

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $oid = $row['order_id'];
        if (!isset($orders[$oid])) {
            $orders[$oid] = [
                'order_id'   => $oid,
                'status'     => $row['status'],
                'order_date' => $row['order_date'],
                'items'      => []
            ];
        }
        
        if (!empty($row['product_name'])) {
            $options = [];

            if (isValidSpec($row['size'])) {
                $options['Size'] = $row['size'];
            }
            if (isValidSpec($row['sugar'])) {
                $options['Sugar Level'] = $row['sugar'];
            }
            if (isValidSpec($row['milk'])) {
                $options['Milk Type'] = $row['milk'];
            }
            if (isValidSpec($row['extras'])) {
                $options['Add-ons / Extras'] = $row['extras'];
            }

            $orders[$oid]['items'][] = [
                'product_name' => $row['product_name'],
                'quantity'     => $row['quantity'],
                'options'      => $options
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Quick Re-Order</title>
    <style>
        :root {
            --cream: #FAF5EF;
            --dark-brown: #3C2A20;
            --medium-brown: #795548;
            --light-cream: #FFFDFB;
            --text-main: #2F1F17;
            --text-muted: #8D7B70;
            --shadow: 0 8px 24px rgba(60, 42, 32, 0.08);
            --transition: all 0.25s ease;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--cream);
            color: var(--text-main);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .back-link {
            text-decoration: none;
            color: var(--medium-brown);
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 20px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--dark-brown);
            transform: translateX(-3px);
        }

        .page-container {
            width: 100%;
            max-width: 850px;
        }

        .header-section {
            text-align: center;
            margin-bottom: 30px;
        }

        .header-section h1 {
            color: var(--dark-brown);
            margin: 0 0 8px;
            font-size: 2.2rem;
        }

        .header-section p {
            color: var(--text-muted);
            margin: 0;
            font-size: 0.95rem;
        }

        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            text-align: center;
            font-weight: 600;
        }
        .alert.success { background-color: #e2f0d9; color: #385d1a; border: 1px solid #c5e0b4; }
        .alert.error { background-color: #fce8e6; color: #a83232; border: 1px solid #f5c2c2; }

        .orders-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 22px;
        }

        .order-card {
            background-color: var(--light-cream);
            padding: 24px;
            border-radius: 20px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(121, 85, 72, 0.12);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 14px;
            border-bottom: 1px dashed rgba(121, 85, 72, 0.15);
            padding-bottom: 10px;
        }

        .order-title {
            font-weight: bold;
            font-size: 1.15rem;
            color: var(--dark-brown);
            margin: 0;
        }

        .order-date {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin: 4px 0 0;
        }

        .status-badge {
            background-color: #e2f0d9;
            color: #385d1a;
            padding: 4px 10px;
            border-radius: 10px;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .items-box {
            background-color: var(--cream);
            padding: 16px;
            border-radius: 14px;
            margin-bottom: 18px;
        }

        .item-row {
            padding-bottom: 10px;
            margin-bottom: 10px;
            border-bottom: 1px dashed rgba(121, 85, 72, 0.12);
        }
        .item-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }

        .item-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--dark-brown);
        }

        .item-qty {
            background-color: rgba(121, 85, 72, 0.15);
            color: var(--dark-brown);
            padding: 2px 9px;
            border-radius: 12px;
            font-size: 0.82rem;
            font-weight: 700;
        }

        .customization-details {
            background: #ffffff;
            border-radius: 10px;
            padding: 10px 12px;
            border: 1px solid rgba(121, 85, 72, 0.1);
            margin-top: 8px;
        }

        .spec-line {
            display: flex;
            justify-content: space-between;
            font-size: 0.83rem;
            padding: 4px 0;
            border-bottom: 1px dotted rgba(121, 85, 72, 0.08);
        }
        .spec-line:last-child {
            border-bottom: none;
        }

        .spec-label {
            color: var(--text-muted);
            font-weight: 500;
        }

        .spec-value {
            color: var(--dark-brown);
            font-weight: 600;
        }

        .reorder-btn {
            width: 100%;
            padding: 13px;
            background-color: var(--dark-brown);
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 0.92rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            box-shadow: 0 4px 12px rgba(60, 42, 32, 0.12);
        }

        .reorder-btn:hover {
            background-color: var(--medium-brown);
            transform: translateY(-1px);
        }

        .empty-history {
            text-align: center;
            padding: 50px 20px;
            color: var(--text-muted);
            background-color: var(--light-cream);
            border-radius: 20px;
            border: 1px dashed rgba(121, 85, 72, 0.2);
            grid-column: 1 / -1;
        }

        @media (max-width: 600px) {
            .orders-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="page-container">

    <a href="index.php" class="back-link">← Back to Menu</a>

    <div class="header-section">
        <h1>☕ Quick Re-Order</h1>
        <p>Re-order your favorite usual drinks & treats with one tap to save time on the go.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <div class="orders-grid">
        <?php if (empty($orders)): ?>
            <div class="empty-history">
                <p style="margin: 0; font-size: 1.1rem; font-weight: 600;">No past orders found!</p>
                <p style="margin: 6px 0 0; font-size: 0.88rem;">Once you place an order from the menu, your order presets will appear here for fast re-ordering.</p>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
                <div class="order-card">
                    <div>
                        <div class="order-header">
                            <div>
                                <h4 class="order-title">Order #<?php echo $order['order_id']; ?></h4>
                                <p class="order-date">📅 <?php echo htmlspecialchars($order['order_date']); ?></p>
                            </div>
                            <span class="status-badge"><?php echo htmlspecialchars($order['status']); ?></span>
                        </div>

                        <div class="items-box">
                            <?php if (empty($order['items'])): ?>
                                <p style="margin: 0; font-size: 0.85rem; color: var(--text-muted); font-style: italic;">Items processing...</p>
                            <?php else: ?>
                                <?php foreach ($order['items'] as $item): ?>
                                    <div class="item-row">
                                        <div class="item-main">
                                            <span><?php echo htmlspecialchars($item['product_name']); ?></span>
                                            <span class="item-qty">x<?php echo $item['quantity']; ?></span>
                                        </div>
                                        
                                        <?php if (!empty($item['options'])): ?>
                                            <div class="customization-details">
                                                <?php foreach ($item['options'] as $label => $val): ?>
                                                    <div class="spec-line">
                                                        <span class="spec-label"><?php echo htmlspecialchars($label); ?>:</span>
                                                        <span class="spec-value"><?php echo htmlspecialchars($val); ?></span>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <form action="diary.php" method="POST" style="margin: 0;">
                        <input type="hidden" name="action" value="reorder_entire_past_order">
                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                        <button type="submit" class="reorder-btn">⚡ Re-Order This Preset</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>

</body>
</html>