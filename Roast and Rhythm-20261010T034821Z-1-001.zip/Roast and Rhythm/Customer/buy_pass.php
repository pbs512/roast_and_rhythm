<?php
include '../config/database.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to buy a coffee pass.']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$plan_id = intval($data['plan_id'] ?? 0);

// Check if a valid plan ID was provided or fallback to frontend cup data
if ($plan_id > 0) {
    // Fetch Plan Details from DB
    $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
    $stmt->bind_param("i", $plan_id);
    $stmt->execute();
    $plan = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$plan) {
        echo json_encode(['success' => false, 'message' => 'Subscription plan not found.']);
        exit();
    }

    $validityDays = $plan['validity_days'] ?? 30;
    $remainingCups = $plan['total_cups'];
} else {
    // Fallback: Get parameters passed directly from JS selection
    $remainingCups = intval($data['cups'] ?? 5);
    $validityDays = 30; // Default 30 days validity
    $plan_id = 1; // Default fallback plan ID
}

// Calculate Validity Dates
$startDate = date('Y-m-d H:i:s');
$expirationDate = date('Y-m-d H:i:s', strtotime("+{$validityDays} days"));

// Insert Active Subscription into user_subscriptions
$ins_stmt = $conn->prepare("
    INSERT INTO user_subscriptions (user_id, plan_id, remaining_cups, start_date, expiration_date, status)
    VALUES (?, ?, ?, ?, ?, 'active')
");

if ($ins_stmt) {
    $ins_stmt->bind_param("iiiss", $user_id, $plan_id, $remainingCups, $startDate, $expirationDate);

    if ($ins_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Pass activated successfully!', 'cups' => $remainingCups]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to activate pass: ' . $conn->error]);
    }
    $ins_stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}
?>