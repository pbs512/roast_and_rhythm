<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/database.php';

$user_id = $_SESSION['user_id'];
$user_display_name = isset($_SESSION['name']) ? explode(' ', trim($_SESSION['name']))[0] : 'My';

// --- HANDLE LIVE STATUS FETCH FOR AJAX POLLING ---
if (isset($_GET['fetch_statuses'])) {
    header('Content-Type: application/json');
    $status_stmt = $conn->prepare("SELECT id, status FROM orders WHERE user_id = ?");
    $status_stmt->bind_param("i", $user_id);
    $status_stmt->execute();
    $status_res = $status_stmt->get_result();
    
    $statuses = [];
    while ($row = $status_res->fetch_assoc()) {
        $statuses[$row['id']] = str_replace('_', ' ', $row['status']);
    }
    echo json_encode($statuses);
    exit();
}

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'reorder_entire_past_order') {
    $order_id_to_copy = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
    if ($order_id_to_copy > 0) {
        $item_stmt = $conn->prepare("SELECT COALESCE(p.name, 'Coffee Item') AS display_name, oi.quantity 
                                     FROM order_items oi 
                                     LEFT JOIN products p ON oi.product_id = p.id 
                                     WHERE oi.order_id = ?");
        $item_stmt->bind_param("i", $order_id_to_copy);
        $item_stmt->execute();
        $items_result = $item_stmt->get_result();
        
        if ($items_result->num_rows > 0) {
            if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
            while ($item = $items_result->fetch_assoc()) {
                $p_name = $item['display_name'];
                if (isset($_SESSION['cart'][$p_name])) {
                    $_SESSION['cart'][$p_name]['quantity'] += $item['quantity'];
                } else {
                    $_SESSION['cart'][$p_name] = [
                        'name' => $p_name,
                        'quantity' => $item['quantity']
                    ];
                }
            }
            $message = "🛒 All items from Order #$order_id_to_copy have been added to your cart!";
            $message_type = "success";
        }
        $item_stmt->close();
    }
}

// Clean SQL Query selecting standard order_items columns
$orders = [];
$query = "SELECT o.id AS order_id, 
                 o.total_amount, 
                 o.status, 
                 DATE_FORMAT(o.created_at, '%b %d, %Y - %h:%i %p') AS order_date,
                 COALESCE(p.name, 'Coffee Item') AS product_name, 
                 oi.quantity, 
                 oi.price
          FROM orders o
          JOIN order_items oi ON o.id = oi.order_id
          LEFT JOIN products p ON oi.product_id = p.id
          WHERE o.user_id = ?
          ORDER BY o.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $oid = $row['order_id'];
    if (!isset($orders[$oid])) {
        $orders[$oid] = [
            'order_id' => $oid,
            'total_amount' => $row['total_amount'],
            'status' => $row['status'],
            'order_date' => $row['order_date'],
            'items' => []
        ];
    }
    $orders[$oid]['items'][] = [
        'product_name' => $row['product_name'],
        'quantity' => $row['quantity'],
        'price' => $row['price']
    ];
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Order History</title>
    <style>
        :root {
            --cream: #FAF5EF;
            --dark-brown: #3C2A20;
            --medium-brown: #795548;
            --light-cream: #FFFDFB;
            --text-main: #2F1F17;
            --text-muted: #8D7B70;
            --shadow: 0 8px 24px rgba(60, 42, 32, 0.08);
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--cream);
            color: var(--text-main);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .back-link { text-decoration: none; color: var(--medium-brown); font-weight: 600; font-size: 0.9rem; margin-bottom: 25px; display: inline-flex; align-items: center; gap: 5px; }
        .history-container { width: 100%; max-width: 750px; display: flex; flex-direction: column; gap: 25px; }
        .page-header { text-align: center; margin-bottom: 10px; }
        .page-header h1 { color: var(--dark-brown); margin: 0 0 5px; font-size: 2.2rem; }
        .order-card { background-color: var(--light-cream); padding: 25px; border-radius: 20px; box-shadow: var(--shadow); border: 1px solid rgba(121, 85, 72, 0.1); }
        .order-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(121, 85, 72, 0.15); padding-bottom: 12px; margin-bottom: 15px; }
        .order-info h3 { margin: 0; color: var(--dark-brown); font-size: 1.15rem; }
        .order-info p { margin: 4px 0 0; font-size: 0.82rem; color: var(--text-muted); }
        .order-status { background-color: #e2f0d9; color: #385d1a; padding: 4px 12px; border-radius: 12px; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; }
        .item-row { display: flex; justify-content: space-between; font-size: 0.92rem; padding: 8px 0; border-bottom: 1px dashed rgba(121, 85, 72, 0.08); }
        .order-footer { display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 12px; border-top: 1px solid rgba(121, 85, 72, 0.1); }
        .total-price { font-size: 1.1rem; font-weight: 700; color: var(--dark-brown); }
        .reorder-btn { background-color: transparent; border: 1px solid var(--medium-brown); color: var(--medium-brown); padding: 7px 16px; border-radius: 20px; font-size: 0.82rem; font-weight: 600; cursor: pointer; }
        .alert { padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 0.88rem; text-align: center; }
        .alert.success { background-color: #e2f0d9; color: #385d1a; border: 1px solid #c5e0b4; }
    </style>
</head>
<body>

<a href="index.php" class="back-link">← Back to Menu</a>

<div class="history-container">
    <div class="page-header">
        <h1>📋 <?php echo htmlspecialchars($user_display_name); ?>'s Order History</h1>
        <p>Review details of your previous orders and duplicate them in one click.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
        <div style="text-align: center; padding: 40px; background: white; border-radius: 20px;">
            <p style="margin: 0; font-size: 1.1rem; font-weight: 600; color: var(--text-muted);">No orders found!</p>
        </div>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <div class="order-header">
                    <div class="order-info">
                        <h3>Order #<?php echo $order['order_id']; ?></h3>
                        <p>Placed on: <?php echo $order['order_date']; ?></p>
                    </div>
                    <span class="order-status" id="status-badge-<?php echo $order['order_id']; ?>">
                        <?php echo htmlspecialchars(str_replace('_', ' ', $order['status'])); ?>
                    </span>
                </div>

                <div class="order-body">
                    <?php foreach ($order['items'] as $item): ?>
                        <div class="item-row">
                            <div class="item-details">
                                <strong><?php echo htmlspecialchars($item['product_name']); ?></strong> x<?php echo $item['quantity']; ?>
                            </div>
                            <div style="font-weight: 600; color: var(--medium-brown);">
                                ₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="order-footer">
                    <div class="total-price">Total: ₱<?php echo number_format($order['total_amount'], 2); ?></div>
                    <form action="order_history.php" method="POST" style="margin: 0;">
                        <input type="hidden" name="action" value="reorder_entire_past_order">
                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                        <button type="submit" class="reorder-btn">⚡ Reorder Entire Batch</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function pollOrderStatuses() {
    fetch('order_history.php?fetch_statuses=1')
        .then(response => response.json())
        .then(data => {
            for (const [orderId, statusText] of Object.entries(data)) {
                const badge = document.getElementById(`status-badge-${orderId}`);
                if (badge && badge.innerText.toLowerCase() !== statusText.toLowerCase()) {
                    badge.innerText = statusText;
                }
            }
        })
        .catch(err => console.error("Polling error:", err));
}

setInterval(pollOrderStatuses, 5000);
</script>

</body>
</html>