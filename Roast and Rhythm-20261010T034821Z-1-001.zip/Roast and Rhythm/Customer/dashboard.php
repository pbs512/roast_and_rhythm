<?php
include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['table'])) {
    $_SESSION['table_number'] = (int)$_GET['table'];
    $_SESSION['order_type'] = 'dine_in';
}

$user_logged_in = false;
$user_avatar = 'default_avatar.png';
$user_name = 'Guest User';
$user_initial = '';
$user_pass_cups = 0;

if (isset($_SESSION['user_id'])) {
    $user_logged_in = true;
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("SELECT name, profile_pic FROM users WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $user_name = $row['name'];
            if (!empty($row['profile_pic'])) {
                $avatar_path = '../assets/uploads/' . $row['profile_pic'];
                if (file_exists($avatar_path)) {
                    $user_avatar = $row['profile_pic'];
                }
            }
        }
        $stmt->close();
    }

    if (!empty($user_name)) {
        $user_initial = strtoupper(mb_substr(trim($user_name), 0, 1, 'UTF-8'));
    }

    try {
        $stmt = $conn->prepare("SELECT total_cups FROM user_subscriptions WHERE user_id = ? AND status = 'active'");
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $subResult = $stmt->get_result();
            if ($subRow = $subResult->fetch_assoc()) {
                $user_pass_cups = (int)$subRow['total_cups'];
            }
            $stmt->close();
        }
    } catch (Exception $e) {
        $user_pass_cups = 0;
    }
}

$query = "SELECT * FROM products";
$result = $conn->query($query);

$products = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $raw_image = !empty($row['image_url']) ? $row['image_url'] : (!empty($row['image']) ? $row['image'] : '');
        
        if (!empty($raw_image) && !preg_match('/^http|\//', $raw_image) && strpos($raw_image, 'assets/') !== 0) {
            $raw_image = '../assets/images/' . $raw_image;
        }

        $products[] = [
            'id'       => $row['id'],
            'name'     => $row['name'],
            'category' => $row['category'],
            'price'    => (float)$row['price'],
            'image'    => !empty($raw_image) ? $raw_image : '../assets/images/default.jpg'
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Premium Experience</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,400&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-main: #FAFAF7;
            --card-bg: #FFFFFF;
            --accent-bg: #F4EFEA;
            --dark-espresso: #2B1810;
            --medium-latte: #7A5230;
            --soft-caramel: #D4A373;
            --highlight-pink: #E8A598;
            --text-main: #231B15;
            --text-muted: #8C7B70;
            --border-light: #EBE5DF;
            --shadow-sm: 0 4px 12px rgba(43, 24, 16, 0.03);
            --shadow-lg: 0 12px 32px rgba(43, 24, 16, 0.08);
            --transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            --white: #ffffff;
        }

        *, *::before, *::after { box-sizing: border-box; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .dashboard-wrapper {
            display: flex;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 290px;
            background-color: var(--card-bg);
            border-right: 1px solid var(--border-light);
            display: flex;
            flex-direction: column;
            padding: 24px 18px;
            flex-shrink: 0;
            overflow-y: auto;
            z-index: 10;
        }

        .brand-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            padding-bottom: 14px;
            border-bottom: 1px solid var(--border-light);
        }

        .brand-logo-badge {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, var(--dark-espresso), var(--medium-latte));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            box-shadow: 0 4px 12px rgba(43, 24, 16, 0.15);
        }

        .brand-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.35rem;
            font-weight: 700;
            color: var(--dark-espresso);
            margin: 0;
            letter-spacing: -0.3px;
        }

        .sidebar-profile {
            background: linear-gradient(135deg, #FDFBF7 0%, var(--accent-bg) 100%);
            border-radius: 18px;
            padding: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
            border: 1px solid var(--border-light);
            box-shadow: var(--shadow-sm);
        }

        .profile-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--soft-caramel);
            background-color: var(--white);
            flex-shrink: 0;
        }

        .profile-avatar-initial {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--dark-espresso), var(--medium-latte));
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--soft-caramel);
            flex-shrink: 0;
            box-shadow: 0 2px 8px rgba(43, 24, 16, 0.15);
        }

        .profile-avatar-initial svg {
            width: 22px;
            height: 22px;
            fill: currentColor;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .profile-name {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--dark-espresso);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .profile-role {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--medium-latte);
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }

        .coffee-pass-banner {
            background: linear-gradient(145deg, #2B1810 0%, #42261A 100%);
            color: var(--white);
            border-radius: 18px;
            padding: 16px;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(43, 24, 16, 0.15);
            position: relative;
            display: flex;
            flex-direction: column;
            gap: 10px;
            width: 100%;
        }

        .pass-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .pass-title {
            font-size: 0.78rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--soft-caramel);
        }

        .pass-badge {
            background: rgba(212, 163, 115, 0.25);
            color: #F3D5B5;
            border: 1px solid rgba(212, 163, 115, 0.4);
            font-size: 0.65rem;
            font-weight: 800;
            padding: 3px 8px;
            border-radius: 12px;
            text-transform: uppercase;
        }

        .pass-count {
            font-size: 1.15rem;
            font-weight: 800;
            margin: 2px 0 4px 0;
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--white);
            line-height: 1.2;
        }

        .pass-action-btn {
            width: 100%;
            padding: 10px;
            background: linear-gradient(135deg, var(--soft-caramel), #C69260);
            color: var(--dark-espresso);
            border: none;
            border-radius: 12px;
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        .pass-action-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }

        .nav-section-title {
            font-size: 0.7rem;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin: 8px 0 10px 4px;
        }

        .category-nav {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .filter-btn {
            display: flex;
            align-items: center;
            width: 100%;
            padding: 10px 14px;
            background: none;
            border: 1px solid transparent;
            border-radius: 14px;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-main);
            font-size: 0.88rem;
            font-weight: 600;
            text-align: left;
        }

        .filter-btn:hover {
            background-color: var(--accent-bg);
            color: var(--dark-espresso);
        }

        .filter-btn.active {
            background-color: var(--dark-espresso);
            color: var(--white);
            box-shadow: 0 6px 16px rgba(43, 24, 16, 0.18);
        }

        .icon-circle {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            background-color: var(--accent-bg);
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.95rem;
            flex-shrink: 0;
            transition: var(--transition);
        }

        .filter-btn.active .icon-circle {
            background-color: rgba(255, 255, 255, 0.18);
        }

        .active-tracker-banner {
            display: none;
            background-color: var(--accent-bg);
            border: 1.5px solid var(--soft-caramel);
            border-radius: 14px;
            padding: 12px;
            margin: 14px 0;
            text-align: center;
        }

        .active-tracker-banner p { 
            margin: 0 0 8px 0; 
            font-size: 0.82rem; 
            font-weight: 700; 
            color: var(--dark-espresso); 
        }

        .active-tracker-banner button {
            width: 100%;
            padding: 8px;
            background-color: var(--dark-espresso);
            color: var(--white);
            border: none;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
        }

        .active-tracker-banner button:hover {
            background-color: var(--medium-latte);
        }

        .sidebar-footer {
            margin-top: auto;
            padding-top: 14px;
            border-top: 1px solid var(--border-light);
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px;
            color: var(--medium-latte);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            border-radius: 8px;
            transition: var(--transition);
        }

        .sidebar-link:hover {
            background-color: var(--accent-bg);
            color: var(--dark-espresso);
        }

        .dashboard-main {
            flex-grow: 1;
            display: flex;
            height: 100%;
            overflow: hidden;
        }

        .content-area {
            flex-grow: 1;
            padding: 32px;
            overflow-y: auto;
        }

        .hero-banner {
            background: linear-gradient(135deg, #F4EFEA 0%, #EBE4DC 100%);
            border-radius: 24px;
            padding: 28px 32px;
            margin-bottom: 28px;
            border: 1px solid var(--border-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            box-shadow: var(--shadow-sm);
        }

        .hero-text h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            margin: 0 0 6px 0;
            color: var(--dark-espresso);
        }

        .hero-text p {
            margin: 0;
            color: var(--medium-latte);
            font-size: 0.95rem;
            font-weight: 500;
        }

        .search-box {
            position: relative;
            width: 280px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 42px;
            border-radius: 30px;
            border: 1px solid var(--border-light);
            background-color: var(--white);
            font-size: 0.9rem;
            outline: none;
            transition: var(--transition);
            box-shadow: 0 2px 8px rgba(0,0,0,0.02);
        }

        .search-box input:focus {
            border-color: var(--soft-caramel);
            box-shadow: 0 4px 14px rgba(212, 163, 115, 0.2);
        }

        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.95rem;
            color: var(--text-muted);
        }

        .table-mode-badge {
            padding: 12px 20px;
            border-radius: 16px;
            margin-bottom: 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 0.92rem;
            box-shadow: var(--shadow-sm);
        }

        .table-mode-badge.dine-in {
            background-color: var(--dark-espresso);
            color: var(--white);
            border: 1px solid var(--soft-caramel);
        }

        .table-mode-badge.takeout {
            background-color: var(--card-bg);
            color: var(--dark-espresso);
            border: 1px solid var(--border-light);
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 22px;
        }

        .product-card {
            background-color: var(--card-bg);
            border-radius: 22px;
            padding: 18px;
            display: flex;
            flex-direction: column;
            transition: var(--transition);
            border: 1px solid var(--border-light);
            box-shadow: var(--shadow-sm);
            position: relative;
        }

        .product-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-lg);
            border-color: var(--soft-caramel);
        }

        .card-badge {
            position: absolute;
            top: 26px;
            left: 26px;
            background: rgba(43, 24, 16, 0.85);
            color: var(--white);
            backdrop-filter: blur(4px);
            font-size: 0.68rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 20px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            z-index: 2;
        }

        .product-img-wrapper {
            width: 100%;
            height: 150px;
            border-radius: 16px;
            overflow: hidden;
            background-color: var(--accent-bg);
            margin-bottom: 14px;
            position: relative;
        }

        .product-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .product-card:hover img {
            transform: scale(1.08);
        }

        .product-details {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .product-name {
            color: var(--dark-espresso);
            font-size: 1.05rem;
            font-weight: 700;
            margin: 0 0 6px 0;
            letter-spacing: -0.2px;
        }

        .product-price {
            color: var(--medium-latte);
            font-weight: 800;
            font-size: 1.1rem;
            margin-bottom: 16px;
        }

        .add-btn {
            width: 100%;
            padding: 11px 16px;
            background-color: var(--accent-bg);
            color: var(--dark-espresso);
            border: 1px solid var(--border-light);
            border-radius: 14px;
            font-size: 0.88rem;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: var(--transition);
            margin-top: auto;
        }

        .product-card:hover .add-btn {
            background-color: var(--dark-espresso);
            color: var(--white);
            border-color: var(--dark-espresso);
        }

        .cart-sidebar {
            width: 350px;
            background-color: var(--card-bg);
            border-left: 1px solid var(--border-light);
            padding: 28px;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            height: 100%;
            box-sizing: border-box;
            box-shadow: -4px 0 20px rgba(0,0,0,0.01);
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-light);
            margin-bottom: 16px;
        }

        .cart-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.35rem;
            color: var(--dark-espresso);
            margin: 0;
        }

        .cart-items-wrapper {
            flex-grow: 1;
            overflow-y: auto;
            margin-bottom: 16px;
            padding-right: 4px;
        }

        .cart-item {
            background-color: var(--bg-main);
            border: 1px solid var(--border-light);
            border-radius: 16px;
            padding: 14px;
            margin-bottom: 12px;
            transition: var(--transition);
        }

        .cart-item:hover {
            border-color: var(--soft-caramel);
        }

        .cart-item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            font-weight: 700;
            color: var(--dark-espresso);
            font-size: 0.95rem;
        }

        .cart-item-details {
            font-size: 0.78rem;
            color: var(--medium-latte);
            margin-top: 6px;
            line-height: 1.4;
            background: rgba(255,255,255,0.6);
            padding: 6px 10px;
            border-radius: 8px;
        }

        .delete-item-btn {
            background: none;
            border: none;
            color: #C0392B;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            padding: 0 4px;
            transition: var(--transition);
        }

        .delete-item-btn:hover { transform: scale(1.2); }

        .pass-redemption-box {
            background: linear-gradient(135deg, #FAF6F0 0%, #F4EFEA 100%);
            border: 1.5px dashed var(--soft-caramel);
            border-radius: 16px;
            padding: 14px;
            margin-bottom: 16px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .pass-redemption-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--dark-espresso);
        }

        .redemption-toggle {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.82rem;
            color: var(--medium-latte);
            cursor: pointer;
            font-weight: 600;
        }

        .checkout-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--dark-espresso) 0%, #42261A 100%);
            color: var(--white);
            border: none;
            border-radius: 16px;
            font-size: 1.05rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 8px 20px rgba(43, 24, 16, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .checkout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(43, 24, 16, 0.28);
        }

        .modal-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background-color: rgba(43, 24, 16, 0.45); 
            backdrop-filter: blur(6px); 
            display: none; 
            justify-content: center; 
            align-items: center; 
            z-index: 1000; 
        }

        .customize-modal { 
            background-color: var(--card-bg); 
            border: 1px solid var(--border-light); 
            border-radius: 28px; 
            width: 90%; 
            max-width: 460px; 
            max-height: 85vh; 
            padding: 28px; 
            display: flex; 
            flex-direction: column; 
            box-shadow: var(--shadow-lg);
        }

        .modal-scroll-area { overflow-y: auto; flex-grow: 1; padding-right: 6px; }
        .modal-title { font-family: 'Playfair Display', serif; color: var(--dark-espresso); margin-top: 0; font-size: 1.4rem; border-bottom: 1px solid var(--border-light); padding-bottom: 12px; margin-bottom: 18px; }
        .option-group { margin-bottom: 20px; }
        .option-label { font-weight: 700; color: var(--dark-espresso); margin-bottom: 10px; display: block; font-size: 0.92rem; }
        .option-selectors { display: flex; gap: 8px; flex-wrap: wrap; }
        
        .selector-btn { 
            padding: 9px 16px; 
            border: 1.5px solid var(--border-light); 
            background-color: var(--bg-main); 
            color: var(--dark-espresso); 
            border-radius: 20px; 
            font-size: 0.85rem; 
            cursor: pointer; 
            font-weight: 600; 
            transition: var(--transition); 
        }

        .selector-btn.selected { 
            background-color: var(--dark-espresso); 
            color: var(--white); 
            border-color: var(--dark-espresso); 
        }

        .modal-actions { display: flex; gap: 12px; margin-top: 20px; border-top: 1px solid var(--border-light); padding-top: 18px; }
        .modal-actions button, .modal-actions a { flex: 1; padding: 14px; border-radius: 14px; font-size: 0.95rem; font-weight: 700; cursor: pointer; text-align: center; text-decoration: none; }
        
        .cancel-modal-btn { background-color: var(--accent-bg); border: none; color: var(--dark-espresso); }
        .confirm-modal-btn { background-color: var(--dark-espresso); border: none; color: var(--white); }

        .status-timeline {
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            margin: 24px 0 16px 0;
        }

        .status-timeline::before {
            content: '';
            position: absolute;
            top: 18px;
            left: 0;
            right: 0;
            height: 3px;
            background-color: var(--border-light);
            z-index: 1;
        }

        .status-timeline-progress {
            position: absolute;
            top: 18px;
            left: 0;
            height: 3px;
            background-color: var(--dark-espresso);
            z-index: 2;
            transition: width 0.4s ease;
            width: 0%;
        }

        .timeline-step {
            position: relative;
            z-index: 3;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
        }

        .step-icon {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background-color: var(--card-bg);
            border: 2px solid var(--border-light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            transition: var(--transition);
        }

        .timeline-step.completed .step-icon {
            background-color: var(--dark-espresso);
            border-color: var(--dark-espresso);
            color: var(--white);
        }

        .timeline-step.active .step-icon {
            background-color: var(--soft-caramel);
            border-color: var(--dark-espresso);
            color: var(--dark-espresso);
            box-shadow: 0 0 0 4px rgba(212, 163, 115, 0.3);
            animation: pulse 1.5s infinite;
        }

        .step-label {
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        .timeline-step.completed .step-label,
        .timeline-step.active .step-label {
            color: var(--dark-espresso);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 700;
            transition: var(--transition);
        }

        .status-updated {
            animation: statusPulse 1.2s ease-in-out infinite alternate;
        }

        @keyframes statusPulse {
            0% { transform: scale(1); box-shadow: 0 0 0 rgba(212, 163, 115, 0); }
            100% { transform: scale(1.05); box-shadow: 0 0 10px rgba(212, 163, 115, 0.6); }
        }

        .auth-modal-card {
            background-color: #FDFBF7;
            width: 90%;
            max-width: 420px;
            padding: 32px 28px;
            border-radius: 24px;
            box-shadow: var(--shadow-lg);
            text-align: center;
            position: relative;
            border: 1px solid var(--border-light);
            animation: slideUp 0.3s ease;
        }

        .auth-modal-close {
            position: absolute;
            top: 16px;
            right: 20px;
            background: transparent;
            border: none;
            font-size: 24px;
            color: var(--text-muted);
            cursor: pointer;
            transition: var(--transition);
        }

        .auth-modal-close:hover {
            color: var(--dark-espresso);
        }

        .auth-modal-icon {
            font-size: 42px;
            margin-bottom: 12px;
        }

        .auth-modal-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.5rem;
            color: var(--dark-espresso);
            margin: 0 0 10px 0;
            font-weight: 700;
        }

        .auth-modal-text {
            font-size: 0.92rem;
            color: var(--medium-latte);
            line-height: 1.5;
            margin: 0 0 24px 0;
        }

        .btn-auth-primary {
            background-color: var(--dark-espresso);
            color: var(--white);
            padding: 12px 20px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.9rem;
            transition: var(--transition);
            display: block;
        }

        .btn-auth-primary:hover {
            background-color: var(--medium-latte);
        }

        .btn-auth-secondary {
            background-color: transparent;
            color: var(--dark-espresso);
            padding: 10px 20px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.9rem;
            border: 1.5px solid var(--border-light);
            transition: var(--transition);
            display: block;
        }

        .btn-auth-secondary:hover {
            background-color: var(--accent-bg);
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.08); }
            100% { transform: scale(1); }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <div class="brand-header">
                <div class="brand-logo-badge">☕</div>
                <h2 class="brand-title">Roast & Rhythm</h2>
            </div>

            <div class="sidebar-profile">
                <?php if ($user_logged_in && !empty($user_avatar) && $user_avatar !== 'default_avatar.png'): ?>
                    <img src="../assets/uploads/<?php echo htmlspecialchars($user_avatar); ?>" class="profile-avatar" alt="Avatar">
                <?php else: ?>
                    <div class="profile-avatar-initial">
                        <svg viewBox="0 0 24 24">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                <?php endif; ?>
                
                <div class="profile-info">
                    <span class="profile-name"><?php echo htmlspecialchars($user_name); ?></span>
                    <span class="profile-role">
                        <?php echo $user_logged_in ? 'A Coffee Enthusiast' : 'Guest Account'; ?>
                    </span>
                </div>
            </div>

            <div class="coffee-pass-banner">
                <div class="pass-header">
                    <span class="pass-title">Coffee Pass</span>
                    <span class="pass-badge" id="pass-status-badge"><?php echo $user_pass_cups > 0 ? 'ACTIVE' : 'INACTIVE'; ?></span>
                </div>
                <div class="pass-count" id="pass-count-display">
                    🎟️ <span id="remaining-cups-val"><?php echo $user_pass_cups; ?></span> Cups
                </div>
                <button class="pass-action-btn" onclick="openPassModal()">
                    <?php echo $user_pass_cups > 0 ? 'Manage Pass' : 'Get Pass'; ?>
                </button>
            </div>

            <div class="nav-section-title">Menu Categories</div>
            <nav class="category-nav">
                <button class="filter-btn active" data-category="all">
                    <div class="icon-circle">✨</div> All Items
                </button>
                <button class="filter-btn" data-category="coffee">
                    <div class="icon-circle">☕</div> Coffee
                </button>
                <button class="filter-btn" data-category="non-coffee">
                    <div class="icon-circle">🍃</div> Non-Coffee
                </button>
                <button class="filter-btn" data-category="pastry">
                    <div class="icon-circle">🥐</div> Pastries
                </button>
            </nav>

            <div id="active-tracker-banner" class="active-tracker-banner">
                <p>📍 Active Order <span id="tracker-order-id-label">#RR-00</span></p>
                <span id="active-order-status" class="status-badge" data-status="pending" style="display: inline-block; margin-bottom: 8px;">PENDING</span>
                <button onclick="reopenTracker()">Track Order</button>
            </div>

            <div class="sidebar-footer">
                <a href="diary.php" class="sidebar-link">📖 Coffee Diary</a>
                <?php if ($user_logged_in): ?>
                    <a href="profile.php" class="sidebar-link">⚙️ Account Settings</a>
                    <a href="logout.php" class="sidebar-link" style="color: #C0392B;">🚪 Sign Out</a>
                <?php else: ?>
                    <a href="register.php" class="sidebar-link">👤 Create Account</a>
                <?php endif; ?>
            </div>
        </aside>

        <div class="dashboard-main">
            <main class="content-area">
                <div class="hero-banner">
                    <div class="hero-text">
                        <h1>Good day, <?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?> 👋</h1>
                        <p>What artisanal brew are we preparing for you today?</p>
                    </div>
                    <div class="search-box">
                        <span class="search-icon">🔍</span>
                        <input type="text" id="menu-search-input" placeholder="Search handcrafted drinks..." onkeyup="filterProductsBySearch()">
                    </div>
                </div>

                <?php if (!empty($_SESSION['table_number'])): ?>
                    <div class="table-mode-badge dine-in">
                        <span>📍 <strong>Dine-In Mode:</strong> Serving Table <strong>#<?php echo $_SESSION['table_number']; ?></strong></span>
                        <span style="font-size: 0.8rem; background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px;">QR Verified</span>
                    </div>
                <?php else: ?>
                    <div class="table-mode-badge takeout">
                        <span>🛍️ <strong>Takeout / Pick-Up Mode</strong></span>
                    </div>
                <?php endif; ?>

                <div class="product-grid" id="product-grid">
                    <?php if (!empty($products)): ?>
                        <?php foreach ($products as $index => $product): ?>
                            <div class="product-card" data-category="<?php echo htmlspecialchars($product['category']); ?>" data-name="<?php echo strtolower(htmlspecialchars($product['name'])); ?>">
                                <?php if ($index === 0): ?>
                                    <span class="card-badge">Best Seller</span>
                                <?php elseif ($index === 1): ?>
                                    <span class="card-badge">Popular</span>
                                <?php endif; ?>

                                <div class="product-img-wrapper">
                                    <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=300&auto=format&fit=crop';">
                                </div>
                                
                                <div class="product-details">
                                    <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                                    <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                                    
                                    <button class="add-btn" 
                                            data-id="<?php echo $product['id']; ?>" 
                                            data-name="<?php echo htmlspecialchars($product['name']); ?>" 
                                            data-price="<?php echo $product['price']; ?>"
                                            data-category="<?php echo htmlspecialchars($product['category']); ?>">
                                        <span>➕</span> Add to Order
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="grid-column: 1/-1; text-align: center; color: var(--medium-latte);">No items available right now.</p>
                    <?php endif; ?>
                </div>
            </main>

            <aside class="cart-sidebar">
                <div class="cart-header">
                    <h2 class="cart-title">Order Summary</h2>
                    <span style="font-size: 0.85rem; color: var(--medium-latte); font-weight: 700;" id="cart-count-badge">0 items</span>
                </div>

                <div class="cart-items-wrapper" id="cart-items">
                    <p style="color: var(--text-muted); font-style: italic; text-align: center; margin-top: 40px;">Your order tray is currently empty.</p>
                </div>
                
                <div class="pass-redemption-box" id="pass-redemption-container" style="display: none;">
                    <div class="pass-redemption-header">
                        <span>🎟️ Coffee Pass Perk</span>
                        <span style="font-weight: 800; color: var(--medium-latte);" id="cart-pass-count">0 Available</span>
                    </div>
                    <label class="redemption-toggle">
                        <input type="checkbox" id="use-pass-checkbox" onchange="togglePassRedemption()">
                        Apply 1 Free Cup Pass (-₱<span id="pass-discount-val">0.00</span>)
                    </label>
                </div>

                <div style="border-top: 1px solid var(--border-light); padding-top: 18px; margin-top: auto;">
                    <p style="display: flex; justify-content: space-between; font-weight: 800; font-size: 1.25rem; margin-bottom: 18px; color: var(--dark-espresso);">
                        <span>Total:</span> <span id="cart-total">₱0.00</span>
                    </p>
                    <button class="checkout-btn" onclick="processCheckout()">
                        <span>Checkout Now</span>
                        <span>➔</span>
                    </button>
                </div>
            </aside>
        </div>
    </div>

    <!-- CUSTOMIZE DRINK MODAL -->
    <div class="modal-overlay" id="custom-modal">
        <div class="customize-modal">
            <h3 class="modal-title" id="modal-product-title">Customize Drink</h3>
            
            <div class="modal-scroll-area">
                <div class="option-group">
                    <span class="option-label">Select Size:</span>
                    <div class="option-selectors" id="size-options">
                        <button class="selector-btn selected" data-value="Regular">Regular (₱0)</button>
                        <button class="selector-btn" data-value="Medium" data-addon="20">Medium (+₱20)</button>
                        <button class="selector-btn" data-value="Large" data-addon="35">Large (+₱35)</button>
                    </div>
                </div>

                <div class="option-group">
                    <span class="option-label">Sugar Level:</span>
                    <div class="option-selectors" id="sugar-options">
                        <button class="selector-btn selected" data-value="100%">100%</button>
                        <button class="selector-btn" data-value="70%">70%</button>
                        <button class="selector-btn" data-value="50%">50%</button>
                        <button class="selector-btn" data-value="0% (No Sugar)">0%</button>
                    </div>
                </div>

                <div class="option-group">
                    <span class="option-label">Milk Base:</span>
                    <div class="option-selectors" id="milk-options">
                        <button class="selector-btn selected" data-value="Whole Milk">Whole Milk (₱0)</button>
                        <button class="selector-btn" data-value="Oat Milk" data-addon="45">Oat Milk (+₱45)</button>
                        <button class="selector-btn" data-value="Almond Milk" data-addon="40">Almond Milk (+₱40)</button>
                    </div>
                </div>

                <div class="option-group">
                    <span class="option-label">Add Extras:</span>
                    <div class="option-selectors" id="extra-options">
                        <button class="selector-btn" data-value="Double Shot" data-addon="30">Espresso Double Shot (+₱30)</button>
                        <button class="selector-btn" data-value="Caramel Drizzle" data-addon="15">Caramel Drizzle (+₱15)</button>
                        <button class="selector-btn" data-value="Whipped Cream" data-addon="20">Whipped Cream (+₱20)</button>
                    </div>
                </div>
            </div>

            <div class="modal-actions">
                <button class="cancel-modal-btn" id="close-modal">Cancel</button>
                <button class="confirm-modal-btn" id="confirm-add-btn">Add to Order</button>
            </div>
        </div>
    </div>

    <!-- ACCOUNT REQUIRED POPUP MODAL -->
    <div class="modal-overlay" id="auth-modal">
        <div class="auth-modal-card">
            <button class="auth-modal-close" onclick="closeAuthModal()">&times;</button>
            <div class="auth-modal-icon">☕</div>
            <h3 class="auth-modal-title">Ready to Taste the Rhythm?</h3>
            <p class="auth-modal-text">
                You're just one step away from crafting your order! Create an account or sign in to start brewing your favorite cup.
            </p>
            <div class="modal-actions" style="flex-direction: column; border: none; padding-top: 0; margin-top: 0;">
                <a href="register.php" class="btn-auth-primary">Create Account</a>
                <a href="login.php" class="btn-auth-secondary">Sign In</a>
            </div>
        </div>
    </div>

    <!-- COFFEE PASS SUBSCRIPTION MODAL -->
    <div class="modal-overlay" id="pass-modal">
        <div class="customize-modal">
            <h3 class="modal-title">☕ Roast & Rhythm Pass</h3>
            <div class="modal-scroll-area">
                <p style="font-size: 0.88rem; color: var(--medium-latte); margin-bottom: 16px;">
                    Subscribe to a Coffee Pass for exclusive savings on daily handcrafted drinks!
                </p>

                <div class="pass-plan-card active-plan" data-plan-id="1" data-cups="5" data-price="499" onclick="selectPassPlan(this)" style="border: 1.5px solid var(--dark-espresso); border-radius: 16px; padding: 16px; margin-bottom: 12px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background-color: var(--accent-bg);">
                    <div>
                        <h4 style="margin: 0; color: var(--dark-espresso);">Weekly Starter Pass</h4>
                        <p style="margin: 4px 0 0 0; color: var(--medium-latte); font-size: 0.82rem;">5 Free Coffee Cups</p>
                    </div>
                    <div style="font-weight: 800; color: var(--dark-espresso); font-size: 1.1rem;">₱499</div>
                </div>

                <div class="pass-plan-card" data-plan-id="2" data-cups="12" data-price="999" onclick="selectPassPlan(this)" style="border: 1.5px solid var(--border-light); border-radius: 16px; padding: 16px; margin-bottom: 12px; cursor: pointer; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h4 style="margin: 0; color: var(--dark-espresso);">Monthly Brew Pass</h4>
                        <p style="margin: 4px 0 0 0; color: var(--medium-latte); font-size: 0.82rem;">12 Free Coffee Cups</p>
                    </div>
                    <div style="font-weight: 800; color: var(--dark-espresso); font-size: 1.1rem;">₱999</div>
                </div>
            </div>

            <div class="modal-actions">
                <button class="cancel-modal-btn" onclick="closePassModal()">Close</button>
                <button class="confirm-modal-btn" onclick="purchasePass()">Buy Subscription</button>
            </div>
        </div>
    </div>

    <!-- TRACKER MODAL -->
    <div class="modal-overlay" id="tracker-modal">
        <div class="customize-modal" style="max-width: 500px;">
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-light); padding-bottom: 12px; margin-bottom: 18px;">
                <h3 class="modal-title" style="margin: 0; border: none; padding: 0;">📍 Live Order Tracker</h3>
                <span id="tracker-order-id" style="font-size: 0.88rem; font-weight: 800; background: var(--accent-bg); color: var(--dark-espresso); padding: 4px 12px; border-radius: 20px;">#RR-00</span>
            </div>

            <div class="modal-scroll-area">
                <div style="text-align: center; margin-bottom: 20px;">
                    <p style="font-size: 0.85rem; color: var(--medium-latte); margin: 0 0 4px 0;">Estimated Preparation Time</p>
                    <h2 id="tracker-eta" style="font-size: 1.8rem; margin: 0; color: var(--dark-espresso); font-family: 'Playfair Display', serif;">5 - 8 mins</h2>
                </div>

                <div class="status-timeline">
                    <div class="status-timeline-progress" id="tracker-progress-bar"></div>
                    <div class="timeline-step" id="step-pending">
                        <div class="step-icon">📝</div>
                        <span class="step-label">Placed</span>
                    </div>
                    <div class="timeline-step" id="step-preparing">
                        <div class="step-icon">☕</div>
                        <span class="step-label">Brewing</span>
                    </div>
                    <div class="timeline-step" id="step-ready">
                        <div class="step-icon">🎉</div>
                        <span class="step-label">Ready</span>
                    </div>
                    <div class="timeline-step" id="step-completed">
                        <div class="step-icon">✨</div>
                        <span class="step-label">Served</span>
                    </div>
                </div>

                <div style="background-color: var(--bg-main); border-radius: 16px; padding: 16px; border: 1px solid var(--border-light); margin-top: 20px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 0.9rem; color: var(--dark-espresso);">Order Summary</h4>
                    <div id="tracker-items-list" style="font-size: 0.85rem; color: var(--medium-latte);">
                        Loading items...
                    </div>
                </div>
            </div>

            <div class="modal-actions">
                <button class="confirm-modal-btn" onclick="closeTrackerModal()">Close Tracker</button>
            </div>
        </div>
    </div>

    <script>
        const isUserLoggedIn = <?php echo $user_logged_in ? 'true' : 'false'; ?>;
        let cart = [];
        let pendingItem = null;
        let userPassCups = <?php echo $user_pass_cups; ?>;
        let isPassRedeemedInCart = false;
        let currentCalculatedTotal = 0;
        let selectedPassPlan = { plan_id: 1, cups: 5, price: 499 };
        let activeOrderId = localStorage.getItem('active_order_id') || null;
        let trackerPollInterval = null;

        function pollActiveOrderStatus() {
            const statusBadge = document.getElementById('active-order-status');

            fetch('get_order_status.php?latest=1')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.status) {
                        const newStatus = data.status.toLowerCase();
                        
                        if (statusBadge) {
                            const currentStatus = statusBadge.getAttribute('data-status');

                            if (currentStatus !== newStatus) {
                                statusBadge.innerText = data.status.replace(/_/g, ' ').toUpperCase();
                                statusBadge.setAttribute('data-status', newStatus);
                                statusBadge.className = `status-badge status-${newStatus} status-updated`;

                                setTimeout(() => {
                                    statusBadge.classList.remove('status-updated');
                                }, 3600);
                            }
                        }

                        if (data.order_id) {
                            activeOrderId = data.order_id;
                            localStorage.setItem('active_order_id', activeOrderId);
                            showTrackerBanner(activeOrderId);
                            updateTrackerUI(data);
                        }
                    }
                })
                .catch(err => console.error("Error polling order status:", err));
        }

        document.addEventListener('DOMContentLoaded', () => {
            if (activeOrderId) {
                showTrackerBanner(activeOrderId);
                startOrderTracking(activeOrderId);
            }

            pollActiveOrderStatus();
            setInterval(pollActiveOrderStatus, 3000);
        });

        function showAuthModal() {
            document.getElementById('auth-modal').style.display = 'flex';
        }

        function closeAuthModal() {
            document.getElementById('auth-modal').style.display = 'none';
        }

        function filterProductsBySearch() {
            const query = document.getElementById('menu-search-input').value.toLowerCase();
            const cards = document.querySelectorAll('.product-card');
            
            cards.forEach(card => {
                const name = card.getAttribute('data-name');
                if (name.includes(query)) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function openPassModal() { 
            if (!isUserLoggedIn) {
                showAuthModal();
                return;
            }
            document.getElementById('pass-modal').style.display = 'flex'; 
        }
        
        function closePassModal() { document.getElementById('pass-modal').style.display = 'none'; }

        function selectPassPlan(elem) {
            document.querySelectorAll('.pass-plan-card').forEach(c => c.style.backgroundColor = 'transparent');
            elem.style.backgroundColor = 'var(--accent-bg)';
            selectedPassPlan = {
                plan_id: parseInt(elem.getAttribute('data-plan-id') || 1),
                cups: parseInt(elem.getAttribute('data-cups')),
                price: parseFloat(elem.getAttribute('data-price'))
            };
        }

        function purchasePass() {
            fetch('subscribe_pass.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(selectedPassPlan)
            })
            .then(async res => {
                const text = await res.text();
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new Error('Server returned an invalid response.');
                }
            })
            .then(data => {
                if (data.success) {
                    userPassCups += selectedPassPlan.cups;
                    updatePassDisplay();
                    closePassModal();
                    alert('Coffee Pass updated successfully!');
                } else {
                    alert(data.message || 'Error subscribing to Coffee Pass.');
                }
            })
            .catch(err => alert(err.message || 'Network error. Failed to purchase subscription.'));
        }

        function updatePassDisplay() {
            const valElem = document.getElementById('remaining-cups-val');
            const badgeElem = document.getElementById('pass-status-badge');
            const cartPassCount = document.getElementById('cart-pass-count');

            if (valElem) valElem.textContent = userPassCups;
            if (badgeElem) badgeElem.textContent = userPassCups > 0 ? 'ACTIVE' : 'INACTIVE';
            if (cartPassCount) cartPassCount.textContent = `${userPassCups} Available`;

            updateCartUI();
        }

        function togglePassRedemption() {
            const checkbox = document.getElementById('use-pass-checkbox');
            isPassRedeemedInCart = checkbox ? checkbox.checked : false;
            updateCartUI();
        }

        const filterButtons = document.querySelectorAll('.filter-btn');
        const productCards = document.querySelectorAll('.product-card');

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                document.querySelector('.filter-btn.active')?.classList.remove('active');
                button.classList.add('active');
                const selectedCategory = button.getAttribute('data-category');

                productCards.forEach(card => {
                    const cardCategory = card.getAttribute('data-category');
                    card.style.display = (selectedCategory === 'all' || cardCategory === selectedCategory) ? 'flex' : 'none';
                });
            });
        });

        const customModal = document.getElementById('custom-modal');
        const closeModalBtn = document.getElementById('close-modal');
        const confirmAddBtn = document.getElementById('confirm-add-btn');

        setupSelectionGroup('size-options');
        setupSelectionGroup('sugar-options');
        setupSelectionGroup('milk-options');

        function setupSelectionGroup(groupId) {
            const container = document.getElementById(groupId);
            if (!container) return;
            container.addEventListener('click', (e) => {
                if (e.target.classList.contains('selector-btn')) {
                    container.querySelector('.selector-btn.selected')?.classList.remove('selected');
                    e.target.classList.add('selected');
                }
            });
        }

        const extraOptionsContainer = document.getElementById('extra-options');
        if (extraOptionsContainer) {
            extraOptionsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('selector-btn')) {
                    e.target.classList.toggle('selected');
                }
            });
        }

        const addButtons = document.querySelectorAll('.add-btn');
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalDisplay = document.getElementById('cart-total');

        addButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (!isUserLoggedIn) {
                    showAuthModal();
                    return;
                }

                const id = button.getAttribute('data-id');
                const name = button.getAttribute('data-name');
                const price = parseFloat(button.getAttribute('data-price'));
                const category = button.getAttribute('data-category');

                if (category === 'coffee' || category === 'non-coffee') {
                    pendingItem = { id, name, price, category };
                    document.getElementById('modal-product-title').textContent = `Customize ${name}`;
                    if (customModal) customModal.style.display = 'flex';
                } else {
                    addToCart(id, name, price, 'N/A', 'N/A', 'N/A', [], 0, category);
                }
            });
        });

        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => {
                if (customModal) customModal.style.display = 'none';
                pendingItem = null;
            });
        }

        if (confirmAddBtn) {
            confirmAddBtn.addEventListener('click', () => {
                if (pendingItem) {
                    const selectedSizeBtn = document.querySelector('#size-options .selector-btn.selected');
                    const selectedSugarBtn = document.querySelector('#sugar-options .selector-btn.selected');
                    const selectedMilkBtn = document.querySelector('#milk-options .selector-btn.selected');
                    const selectedExtraBtns = document.querySelectorAll('#extra-options .selector-btn.selected');

                    const size = selectedSizeBtn ? selectedSizeBtn.getAttribute('data-value') : 'Regular';
                    const sugar = selectedSugarBtn ? selectedSugarBtn.getAttribute('data-value') : '100%';
                    const milk = selectedMilkBtn ? selectedMilkBtn.getAttribute('data-value') : 'Whole Milk';
                    
                    let addonPrice = parseFloat(selectedSizeBtn?.getAttribute('data-addon') || 0);
                    addonPrice += parseFloat(selectedMilkBtn?.getAttribute('data-addon') || 0);

                    const extras = [];
                    selectedExtraBtns.forEach(btn => {
                        extras.push(btn.getAttribute('data-value'));
                        addonPrice += parseFloat(btn.getAttribute('data-addon') || 0);
                    });

                    addToCart(pendingItem.id, pendingItem.name, pendingItem.price, size, sugar, milk, extras, addonPrice, pendingItem.category);
                    
                    if (customModal) customModal.style.display = 'none';
                    pendingItem = null;
                }
            });
        }

        function addToCart(id, name, basePrice, size, sugar, milk, extras, totalAddons, category) {
            const finalPrice = basePrice + totalAddons;
            const extrasKey = extras.slice().sort().join(',');
            const cartItemKey = `${id}-${size}-${sugar}-${milk}-${extrasKey}`;
            const existingItem = cart.find(item => item.key === cartItemKey);

            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({ key: cartItemKey, id, name, basePrice, price: finalPrice, size, sugar, milk, extras, category, quantity: 1 });
            }
            updateCartUI();
        }

        function removeFromCart(key) {
            cart = cart.filter(item => item.key !== key);
            updateCartUI();
        }

        function changeCartQuantity(key, delta) {
            const itemIndex = cart.findIndex(item => item.key === key);
            if (itemIndex !== -1) {
                cart[itemIndex].quantity += delta;
                
                if (cart[itemIndex].quantity <= 0) {
                    cart.splice(itemIndex, 1);
                }
                updateCartUI();
            }
        }

        function updateCartUI() {
            if (!cartItemsContainer || !cartTotalDisplay) return;

            cartItemsContainer.innerHTML = '';
            let total = 0;
            let itemCount = 0;
            let eligibleCoffeeFound = false;
            let highestBasePrice = 0;

            const passContainer = document.getElementById('pass-redemption-container');
            const passDiscountElem = document.getElementById('pass-discount-val');
            const cartCountBadge = document.getElementById('cart-count-badge');

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<p style="color: var(--text-muted); font-style: italic; text-align: center; margin-top: 40px;">Your order tray is currently empty.</p>';
                cartTotalDisplay.textContent = '₱0.00';
                currentCalculatedTotal = 0;
                if (cartCountBadge) cartCountBadge.textContent = '0 items';
                if (passContainer) passContainer.style.display = 'none';
                return;
            }

            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                itemCount += item.quantity;

                if (item.category === 'coffee') {
                    eligibleCoffeeFound = true;
                    if (item.basePrice > highestBasePrice) highestBasePrice = item.basePrice;
                }

                let detailsText = '';
                if (item.size !== 'N/A') {
                    detailsText = `${item.size} • ${item.sugar} • ${item.milk}`;
                    if (item.extras.length > 0) detailsText += `<br>+ ${item.extras.join(', ')}`;
                }

                const itemDiv = document.createElement('div');
                itemDiv.className = 'cart-item';
                itemDiv.innerHTML = `
                    <div class="cart-item-header">
                        <span style="font-weight:700;">${item.name}</span>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span style="font-weight:800; color:var(--dark-espresso);">₱${itemTotal.toFixed(2)}</span>
                            <button class="delete-item-btn" onclick="removeFromCart('${item.key}')" title="Remove Item">&times;</button>
                        </div>
                    </div>
                    ${detailsText ? `<div class="cart-item-details">${detailsText}</div>` : ''}
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px; padding-top: 8px; border-top: 1px dashed var(--border-light);">
                        <span style="font-size: 0.78rem; color: var(--text-muted); font-weight: 600;">Quantity</span>
                        <div style="display: flex; align-items: center; gap: 6px; background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; padding: 2px 8px;">
                            <button onclick="changeCartQuantity('${item.key}', -1)" style="background:none; border:none; color:var(--dark-espresso); font-weight:800; cursor:pointer; font-size:1rem; width:20px; height:20px; display:flex; align-items:center; justify-content:center;">−</button>
                            <span style="font-weight:700; font-size:0.88rem; min-width:18px; text-align:center; color:var(--dark-espresso);">${item.quantity}</span>
                            <button onclick="changeCartQuantity('${item.key}', 1)" style="background:none; border:none; color:var(--dark-espresso); font-weight:800; cursor:pointer; font-size:1rem; width:20px; height:20px; display:flex; align-items:center; justify-content:center;">+</button>
                        </div>
                    </div>
                `;
                cartItemsContainer.appendChild(itemDiv);
            });

            if (cartCountBadge) cartCountBadge.textContent = `${itemCount} item${itemCount > 1 ? 's' : ''}`;

            if (eligibleCoffeeFound && userPassCups > 0) {
                if (passContainer) passContainer.style.display = 'flex';
                if (passDiscountElem) passDiscountElem.textContent = highestBasePrice.toFixed(2);

                if (isPassRedeemedInCart) {
                    total = Math.max(0, total - highestBasePrice);
                }
            } else {
                if (passContainer) passContainer.style.display = 'none';
                isPassRedeemedInCart = false;
            }

            currentCalculatedTotal = total;
            cartTotalDisplay.textContent = `₱${total.toFixed(2)}`;
        }

        function processCheckout() {
            if (!isUserLoggedIn) {
                showAuthModal();
                return;
            }

            if (cart.length === 0) {
                alert('Your tray is empty!');
                return;
            }

            const payload = {
                cart: cart,
                total: currentCalculatedTotal,
                order_type: "<?php echo isset($_SESSION['order_type']) ? $_SESSION['order_type'] : 'takeout'; ?>",
                pass_redeemed: isPassRedeemedInCart
            };

fetch('place_order.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
})
.then(async response => {
    const text = await response.text();

    console.log('HTTP Status:', response.status);
    console.log('Server Response:', text);

    let result;

    try {
        result = JSON.parse(text);
    } catch (error) {
        throw new Error('Invalid server response. Check the Console for details.');
    }

    if (!response.ok || !result.success) {
        throw new Error(result.message || 'Failed to place order.');
    }

    alert(result.message || 'Order placed successfully.');
    location.reload();
})
.catch(error => {
    console.error('Order submission error:', error);
    alert(error.message || 'An error occurred while submitting the order. Please try again.');
});
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (isPassRedeemedInCart) {
                        userPassCups = Math.max(0, userPassCups - 1);
                    }
                    cart = [];
                    isPassRedeemedInCart = false;
                    const passCheckbox = document.getElementById('use-pass-checkbox');
                    if (passCheckbox) passCheckbox.checked = false;
                    updatePassDisplay();

                    activeOrderId = data.order_id;
                    localStorage.setItem('active_order_id', activeOrderId);
                    showTrackerBanner(activeOrderId);
                    openTrackerModal();
                    startOrderTracking(activeOrderId);
                } else {
                    alert('Failed to place order: ' + data.message);
                }
            })
            .catch(() => {
                alert('An error occurred while submitting the order. Please try again.');
            });
        }

        function showTrackerBanner(orderId) {
            const banner = document.getElementById('active-tracker-banner');
            const label = document.getElementById('tracker-order-id-label');
            if (banner && label) {
                label.textContent = `#RR-${orderId}`;
                banner.style.display = 'block';
            }
        }

        function hideTrackerBanner() {
            const banner = document.getElementById('active-tracker-banner');
            if (banner) banner.style.display = 'none';
        }

        function openTrackerModal() {
            const trackerModal = document.getElementById('tracker-modal');
            if (trackerModal) trackerModal.style.display = 'flex';
        }

        function closeTrackerModal() {
            const trackerModal = document.getElementById('tracker-modal');
            if (trackerModal) trackerModal.style.display = 'none';
        }

        function reopenTracker() {
            if (activeOrderId) {
                openTrackerModal();
                fetchOrderStatus(activeOrderId);
            }
        }

        function startOrderTracking(orderId) {
            if (trackerPollInterval) clearInterval(trackerPollInterval);
            fetchOrderStatus(orderId);
            trackerPollInterval = setInterval(() => {
                fetchOrderStatus(orderId);
            }, 5000);
        }

        function fetchOrderStatus(orderId) {
            fetch(`get_order_status.php?order_id=${orderId}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    updateTrackerUI(data);
                }
            })
            .catch(() => {});
        }

        function updateTrackerUI(data) {
            document.getElementById('tracker-order-id').textContent = `#RR-${data.order_id}`;

            const etaElem = document.getElementById('tracker-eta');
            const progressBar = document.getElementById('tracker-progress-bar');

            const steps = {
                pending: document.getElementById('step-pending'),
                preparing: document.getElementById('step-preparing'),
                ready: document.getElementById('step-ready'),
                completed: document.getElementById('step-completed')
            };

            // Reset step states
            Object.values(steps).forEach(step => {
                if (step) step.className = 'timeline-step';
            });

            // Normalize status string from database/barista selection
            let rawStatus = (data.status || 'ORDER_PLACED').toUpperCase().replace(/ /g, '_');

            // Rank status levels (1: Placed, 2: Brewing, 3: Ready, 4: Served)
            let statusRank = 1;
            if (rawStatus === 'BREWING' || rawStatus === 'PREPARING') {
                statusRank = 2;
            } else if (rawStatus === 'READY' || rawStatus === 'READY_FOR_PICKUP') {
                statusRank = 3;
            } else if (rawStatus === 'SERVED' || rawStatus === 'COMPLETED') {
                statusRank = 4;
            }

            // Apply step styles and progress bar based on status rank
            if (statusRank >= 1) {
                if (statusRank === 1) {
                    steps.pending?.classList.add('active');
                    if (progressBar) progressBar.style.width = '0%';
                    if (etaElem) etaElem.textContent = '5 - 8 mins';
                } else {
                    steps.pending?.classList.add('completed');
                }
            }

            if (statusRank >= 2) {
                if (statusRank === 2) {
                    steps.preparing?.classList.add('active');
                    if (progressBar) progressBar.style.width = '33%';
                    if (etaElem) etaElem.textContent = '2 - 4 mins';
                } else {
                    steps.preparing?.classList.add('completed');
                }
            }

            if (statusRank >= 3) {
                if (statusRank === 3) {
                    steps.ready?.classList.add('active');
                    if (progressBar) progressBar.style.width = '66%';
                    if (etaElem) etaElem.textContent = 'Ready for pickup!';
                } else {
                    steps.ready?.classList.add('completed');
                }
            }

            if (statusRank >= 4) {
                steps.completed?.classList.add('completed');
                if (progressBar) progressBar.style.width = '100%';
                if (etaElem) etaElem.textContent = 'Order Served 🎉';

                clearInterval(trackerPollInterval);
                localStorage.removeItem('active_order_id');
                activeOrderId = null;
                setTimeout(hideTrackerBanner, 3000);
            }

            const itemsContainer = document.getElementById('tracker-items-list');
            if (itemsContainer && data.items && data.items.length > 0) {
                itemsContainer.innerHTML = data.items.map(i => 
                    `<div style="display:flex; justify-content:space-between; margin-bottom: 6px;">
                        <span>${i.quantity}x ${i.product_name || i.name || 'Item'}</span>
                        <span style="font-weight:700;">₱${parseFloat(i.price).toFixed(2)}</span>
                    </div>`
                ).join('');
            }
        }

        window.onclick = function(event) {
            const authModal = document.getElementById('auth-modal');
            if (event.target === authModal) {
                closeAuthModal();
            }
        };
    </script>
</body>
</html>