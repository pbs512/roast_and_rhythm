<?php
// 1. Initialize session environment
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Unset all session global variables
$_SESSION = array();

// 3. Destroy session cookie in user browser if present
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// 4. Complete session destruction on server
session_destroy();

// 5. Redirect back to login page or dashboard
header("Location: index.php"); // Adjust 'index.php' to your login page filename if different
exit();
?>