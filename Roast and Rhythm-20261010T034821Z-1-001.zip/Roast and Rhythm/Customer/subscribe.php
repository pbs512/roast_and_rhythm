<?php
// customer/subscribe.php
session_start();
header('Content-Type: application/json');

// Get POST data from JSON payload
$data = json_decode(file_get_contents('php://input'), true);
$plan_id = $data['plan_id'] ?? null;

$valid_plans = ['weekly', 'monthly', 'vip'];

if (!$plan_id || !in_array($plan_id, $valid_plans)) {
    echo json_encode(['success' => false, 'message' => 'Invalid plan selection.']);
    exit;
}

// TODO: Perform database query here (e.g., update user balance/cups)
// include '../config/db.php';
// mysqli_query($conn, "UPDATE users SET pass_type='$plan_id' WHERE id=...");

echo json_encode(['success' => true]);
?>