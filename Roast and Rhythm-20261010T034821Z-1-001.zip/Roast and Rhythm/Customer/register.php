<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Direct Database Connection Setup
$host = 'localhost';
$db   = 'roast and rhythm'; 
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

if (file_exists('../config/database.php')) {
    include_once '../config/database.php';
}

if (!isset($pdo) || $pdo === null) {
    try {
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        $error_msg = "Database Connection Error: " . $e->getMessage();
    }
}

$error_msg = $error_msg ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($pdo)) {
    // Basic Details
    $first_name       = trim($_POST['first_name'] ?? '');
    $middle_name      = trim($_POST['middle_name'] ?? '');
    $last_name        = trim($_POST['last_name'] ?? '');
    $extension        = trim($_POST['extension'] ?? '');
    $birthday         = trim($_POST['birthday'] ?? '');
    $age              = trim($_POST['age'] ?? '');
    
    // Address & Contact
    $house_no         = trim($_POST['house_no'] ?? '');
    $street_name      = trim($_POST['street_name'] ?? '');
    $city             = trim($_POST['city'] ?? '');
    $country          = trim($_POST['country'] ?? '');
    $zip_code         = trim($_POST['zip_code'] ?? '');
    $contact_number   = trim($_POST['contact_number'] ?? '');
    
    // Credentials
    $email            = trim($_POST['email'] ?? '');
    $username         = trim($_POST['username'] ?? '');
    $password         = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Create full name string for backwards compatibility
    $fullname = trim("$first_name $middle_name $last_name $extension");

    if (empty($first_name) || empty($last_name) || empty($email) || empty($username) || empty($password) || empty($confirm_password)) {
        $error_msg = "Please fill in all required fields.";
    } elseif ($password !== $confirm_password) {
        $error_msg = "Passwords do not match. Please try again.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
            $stmt->execute([$email, $username]);

            if ($stmt->rowCount() > 0) {
                $error_msg = "Email or Username is already registered.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $insertStmt = $pdo->prepare("INSERT INTO users 
                    (first_name, middle_name, last_name, extension, fullname, birthday, age, house_no, street_name, city, country, zip_code, contact_number, email, username, password, role) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'customer')");

                $success = $insertStmt->execute([
                    $first_name, 
                    $middle_name, 
                    $last_name, 
                    $extension, 
                    $fullname, 
                    $birthday,
                    $age,
                    $house_no, 
                    $street_name, 
                    $city,
                    $country, 
                    $zip_code, 
                    $contact_number, 
                    $email, 
                    $username, 
                    $hashed_password
                ]);

                if ($success) {
                    $_SESSION['success'] = "Account created successfully! Please log in.";
                    header("Location: login.php");
                    exit;
                } else {
                    $error_msg = "Registration failed. Please try again.";
                }
            }
        } catch (PDOException $e) {
            $error_msg = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - Join Us</title>
    
    <!-- jQuery and Select2 CDN for custom flag rendering -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style>
        :root {
            --bg-main: #FAF6F0;
            --card-bg: #FFFFFF;
            --dark-espresso: #3D2314;
            --medium-latte: #8C6239;
            --soft-caramel: #C49A6C;
            --cream-accent: #FDFBF7;
            --text-main: #2C1D11;
            --border-light: #EFE8DE;
            --shadow-lg: 0 20px 40px rgba(61, 35, 20, 0.12);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-container {
            display: flex;
            width: 100%;
            max-width: 1080px;
            background-color: var(--card-bg);
            border-radius: 28px;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--border-light);
            overflow: hidden;
            min-height: 650px;
        }

        .brand-panel {
            flex: 0.8;
            background: linear-gradient(135deg, #3D2314 0%, #5A3821 100%);
            padding: 50px 40px;
            color: #FFFFFF;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .brand-header { display: flex; align-items: center; gap: 12px; text-decoration: none; color: #FFFFFF; }
        .brand-logo { font-size: 2rem; }
        .brand-title { font-size: 1.5rem; font-weight: 700; }

        .brand-badge {
            display: inline-block;
            background: rgba(196, 154, 108, 0.2);
            border: 1px solid var(--soft-caramel);
            color: var(--soft-caramel);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        .brand-heading { font-size: 2.2rem; line-height: 1.2; font-weight: 800; margin-bottom: 15px; }
        .brand-heading span { color: var(--soft-caramel); }
        .brand-desc { color: #E0D3C5; font-size: 0.95rem; line-height: 1.6; }

        .perks-list { list-style: none; margin-top: 25px; }
        .perks-list li { display: flex; align-items: center; gap: 10px; font-size: 0.9rem; color: #E0D3C5; margin-bottom: 12px; }
        .perks-list li span { color: var(--soft-caramel); font-weight: bold; }

        .form-panel {
            flex: 1.2;
            padding: 40px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background-color: var(--card-bg);
            max-height: 90vh;
            overflow-y: auto;
        }

        .form-header { margin-bottom: 20px; }
        .form-title { font-size: 1.8rem; color: var(--dark-espresso); font-weight: 800; }
        .form-subtitle { font-size: 0.9rem; color: var(--medium-latte); margin-top: 5px; }

        .alert-error {
            background-color: #F8D7DA;
            color: #721C24;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            border: 1px solid #F5C6CB;
        }

        .form-row {
            display: grid;
            gap: 12px;
            margin-bottom: 14px;
        }

        .form-row.col-4 {
            grid-template-columns: 2fr 2fr 2fr 1fr;
        }

        .form-row.col-3 {
            grid-template-columns: 1fr 1fr 1fr;
        }

        .form-row.col-2 {
            grid-template-columns: 1fr 1fr;
        }

        .input-group { 
            display: flex; 
            flex-direction: column; 
        }

        .input-label { 
            display: block; 
            font-size: 0.75rem; 
            font-weight: 700; 
            color: var(--dark-espresso); 
            margin-bottom: 6px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
        }

        .input-field {
            width: 100%;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1.5px solid var(--border-light);
            background-color: var(--cream-accent);
            font-size: 0.9rem;
            color: var(--text-main);
            outline: none;
            transition: var(--transition);
        }

        .input-field:focus {
            border-color: var(--medium-latte);
            background-color: #FFFFFF;
            box-shadow: 0 0 0 4px rgba(140, 98, 57, 0.1);
        }

        /* Password Wrapper & Toggle Eye Button */
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        .password-wrapper .input-field {
            padding-right: 42px;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--medium-latte);
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            user-select: none;
        }

        .toggle-password:hover {
            color: var(--dark-espresso);
        }

        /* Customizing Select2 theme to match overall UI */
        .select2-container--default .select2-selection--single {
            background-color: var(--cream-accent);
            border: 1.5px solid var(--border-light);
            border-radius: 10px;
            height: 45px;
            display: flex;
            align-items: center;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: var(--text-main);
            font-size: 0.9rem;
            line-height: normal;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 43px;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background-color: var(--dark-espresso);
            color: #FFFFFF;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 6px 16px rgba(61, 35, 20, 0.2);
            margin-top: 10px;
        }

        .btn-submit:hover { background-color: var(--medium-latte); transform: translateY(-2px); }

        .form-footer { margin-top: 20px; text-align: center; font-size: 0.85rem; color: var(--medium-latte); }
        .form-footer a { color: var(--dark-espresso); font-weight: 700; text-decoration: none; }
        .form-footer a:hover { color: var(--soft-caramel); text-decoration: underline; }

        @media (max-width: 850px) {
            .auth-container { flex-direction: column; }
            .brand-panel, .form-panel { padding: 35px 25px; }
            .form-row.col-4, .form-row.col-3, .form-row.col-2 { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <div class="auth-container">
        <div class="brand-panel">
            <a href="index.php" class="brand-header">
                <span class="brand-logo">☕</span>
                <span class="brand-title">Roast & Rhythm</span>
            </a>

            <div class="brand-content">
                <span class="brand-badge">Join The Club</span>
                <h1 class="brand-heading">Start your coffee <span>journey with us.</span></h1>
                <p class="brand-desc">Create your personal account to unlock seamless pickup ordering, custom brews, and daily perks.</p>

                <ul class="perks-list">
                    <li><span>✓</span> Instant Coffee Pass eligibility</li>
                    <li><span>✓</span> Live order tracking radar</li>
                    <li><span>✓</span> Saved favorite brews & pastries</li>
                </ul>
            </div>

            <p style="font-size: 0.8rem; color: rgba(255,255,255,0.6);">&copy; <?php echo date('Y'); ?> Roast & Rhythm</p>
        </div>

        <div class="form-panel">
            <div class="form-header">
                <h2 class="form-title">Create Account</h2>
                <p class="form-subtitle">Fill in your details below to get started.</p>
            </div>

            <?php if (!empty($error_msg)): ?>
                <div class="alert-error"><?php echo htmlspecialchars($error_msg); ?></div>
            <?php endif; ?>

            <form action="register.php" method="POST">
                <!-- Personal Name Fields -->
                <div class="form-row col-4">
                    <div class="input-group">
                        <label class="input-label" for="first_name">First Name</label>
                        <input type="text" id="first_name" name="first_name" class="input-field" placeholder="First Name" required>
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="middle_name">Middle Name</label>
                        <input type="text" id="middle_name" name="middle_name" class="input-field" placeholder="Middle Name">
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="last_name">Last Name</label>
                        <input type="text" id="last_name" name="last_name" class="input-field" placeholder="Last Name" required>
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="extension">Ext.</label>
                        <input type="text" id="extension" name="extension" class="input-field" placeholder="Jr., III">
                    </div>
                </div>

                <!-- Age & Birthday Fields -->
                <div class="form-row col-2">
                    <div class="input-group">
                        <label class="input-label" for="birthday">Birthday</label>
                        <input type="date" id="birthday" name="birthday" class="input-field" onchange="calculateAge()" required>
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="age">Age</label>
                        <input type="number" id="age" name="age" class="input-field" placeholder="Age" min="1" max="120" readonly>
                    </div>
                </div>

                <!-- Address Fields -->
                <div class="form-row col-2">
                    <div class="input-group">
                        <label class="input-label" for="house_no">House No.</label>
                        <input type="text" id="house_no" name="house_no" class="input-field" placeholder="House / Bldg No.">
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="street_name">Street Name</label>
                        <input type="text" id="street_name" name="street_name" class="input-field" placeholder="Street Name">
                    </div>
                </div>

                <div class="form-row col-3">
                    <div class="input-group">
                        <label class="input-label" for="city">City / Municipality</label>
                        <input type="text" id="city" name="city" class="input-field" placeholder="City">
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="zip_code">Zip Code</label>
                        <input type="text" id="zip_code" name="zip_code" class="input-field" placeholder="Zip Code">
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="country">Country</label>
                        <select id="country" name="country" class="input-field country-select" required>
                            <option value="" disabled selected>Select Country</option>
                            <option value="Philippines" data-code="ph">Philippines (+63)</option>
                            <option value="United States" data-code="us">United States (+1)</option>
                            <option value="Canada" data-code="ca">Canada (+1)</option>
                            <option value="United Kingdom" data-code="gb">United Kingdom (+44)</option>
                            <option value="Australia" data-code="au">Australia (+61)</option>
                            <option value="Japan" data-code="jp">Japan (+81)</option>
                            <option value="South Korea" data-code="kr">South Korea (+82)</option>
                            <option value="Singapore" data-code="sg">Singapore (+65)</option>
                            <option value="Germany" data-code="de">Germany (+49)</option>
                            <option value="France" data-code="fr">France (+33)</option>
                            <option value="Italy" data-code="it">Italy (+39)</option>
                            <option value="China" data-code="cn">China (+86)</option>
                            <option value="India" data-code="in">India (+91)</option>
                            <option value="Indonesia" data-code="id">Indonesia (+62)</option>
                            <option value="Malaysia" data-code="my">Malaysia (+60)</option>
                            <option value="Vietnam" data-code="vn">Vietnam (+84)</option>
                            <option value="Thailand" data-code="th">Thailand (+66)</option>
                            <option value="New Zealand" data-code="nz">New Zealand (+64)</option>
                            <option value="Brazil" data-code="br">Brazil (+55)</option>
                            <option value="United Arab Emirates" data-code="ae">UAE (+971)</option>
                        </select>
                    </div>
                </div>

                <!-- Contact & Email Fields -->
                <div class="form-row col-2">
                    <div class="input-group">
                        <label class="input-label" for="contact_number">Contact Number</label>
                        <input type="tel" id="contact_number" name="contact_number" class="input-field" placeholder="e.g., 9123456789">
                    </div>
                    <div class="input-group">
                        <label class="input-label" for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="input-field" placeholder="e.g., jane@example.com" required>
                    </div>
                </div>

                <!-- Username & Passwords -->
                <div class="form-row">
                    <div class="input-group">
                        <label class="input-label" for="username">Username</label>
                        <input type="text" id="username" name="username" class="input-field" placeholder="Choose username" required>
                    </div>
                </div>

                <div class="form-row col-2">
                    <div class="input-group">
                        <label class="input-label" for="password">Password</label>
                        <div class="password-wrapper">
                            <input type="password" id="password" name="password" class="input-field" placeholder="Create password" required>
                            <button type="button" class="toggle-password" onclick="togglePasswordVisibility('password', this)" aria-label="Toggle password visibility">👁️</button>
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label" for="confirm_password">Re-type Password</label>
                        <div class="password-wrapper">
                            <input type="password" id="confirm_password" name="confirm_password" class="input-field" placeholder="Confirm password" required>
                            <button type="button" class="toggle-password" onclick="togglePasswordVisibility('confirm_password', this)" aria-label="Toggle confirm password visibility">👁️</button>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Register Account</button>
            </form>

            <div class="form-footer">
                Already have an account? <a href="login.php">Log in here</a>
            </div>
        </div>
    </div>

    <script>
        // Toggle password visibility
        function togglePasswordVisibility(fieldId, button) {
            const input = document.getElementById(fieldId);
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }

        // Automatic Age Calculation when Birthday is selected
        function calculateAge() {
            const birthInput = document.getElementById('birthday').value;
            if (birthInput) {
                const birthDate = new Date(birthInput);
                const today = new Date();
                let age = today.getFullYear() - birthDate.getFullYear();
                const monthDiff = today.getMonth() - birthDate.getMonth();
                
                if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                document.getElementById('age').value = age > 0 ? age : 0;
            }
        }

        // Initialize Select2 with SVG flags
        $(document).ready(function() {
            function formatCountry (state) {
                if (!state.id) { return state.text; }
                var code = $(state.element).data('code');
                if (!code) return state.text;
                
                var $state = $(
                    '<span><img src="https://flagcdn.com/20x15/' + code + '.png" style="width:20px; height:15px; margin-right:8px; vertical-align:middle; border-radius:2px;"/>' + state.text + '</span>'
                );
                return $state;
            };

            $('.country-select').select2({
                templateResult: formatCountry,
                templateSelection: formatCountry,
                width: '100%'
            });
        });
    </script>
</body>
</html>