<?php
header('Content-Type: application/json');
include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$plan_id = isset($data['plan_id']) ? (int)$data['plan_id'] : 1;
$cups = isset($data['cups']) ? (int)$data['cups'] : 5;
$price = isset($data['price']) ? (float)$data['price'] : 0.00;

try {
    $stmt = $conn->prepare("SELECT id, total_cups FROM user_subscriptions WHERE user_id = ? AND status = 'active'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $new_total = $row['total_cups'] + $cups;
        $update_stmt = $conn->prepare("UPDATE user_subscriptions SET total_cups = ? WHERE id = ?");
        $update_stmt->bind_param("ii", $new_total, $row['id']);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO user_subscriptions (user_id, plan_id, total_cups, status) VALUES (?, ?, ?, 'active')");
        $insert_stmt->bind_param("iii", $user_id, $plan_id, $cups);
        $insert_stmt->execute();
        $insert_stmt->close();
    }
    $stmt->close();

    echo json_encode(['success' => true, 'message' => 'Subscription updated successfully']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>