<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Order ID is required'
    ]);
    exit;
}

$order_id = (int) $_GET['order_id'];

try {
    $stmt = $conn->prepare("
        SELECT
            id,
            user_id,
            total_amount,
            payment_method,
            table_number,
            status,
            created_at
        FROM orders
        WHERE id = ?
    ");

    if (!$stmt) {
        throw new Exception($conn->error);
    }

    $stmt->bind_param("i", $order_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    $stmt->close();

    if (!$order) {
        echo json_encode([
            'success' => false,
            'message' => 'Order not found'
        ]);
        exit;
    }

    $items_stmt = $conn->prepare("
        SELECT
            product_name,
            size,
            sugar,
            milk,
            extras,
            quantity,
            price
        FROM order_items
        WHERE order_id = ?
    ");

    if (!$items_stmt) {
        throw new Exception($conn->error);
    }

    $items_stmt->bind_param("i", $order_id);
    $items_stmt->execute();

    $items_result = $items_stmt->get_result();
    $items = [];

    while ($item = $items_result->fetch_assoc()) {
        $items[] = [
            'name' => $item['product_name'],
            'size' => $item['size'] ?? '',
            'sugar' => $item['sugar'] ?? '',
            'milk' => $item['milk'] ?? '',
            'extras' => $item['extras'] ?? '',
            'quantity' => (int) $item['quantity'],
            'price' => (float) $item['price']
        ];
    }

    $items_stmt->close();

    echo json_encode([
        'success' => true,
        'order_id' => (int) $order['id'],
        'status' => strtolower($order['status']),
        'order_type' => 'delivery',
        'payment_method' => $order['payment_method'],
        'table_number' => $order['table_number'],
        'total_amount' => (float) $order['total_amount'],
        'created_at' => $order['created_at'],
        'items' => $items
    ]);

} catch (Throwable $e) {
    error_log('Process order error: ' . $e->getMessage());

    echo json_encode([
        'success' => false,
        'message' => 'Unable to retrieve order details.'
    ]);
}
?>