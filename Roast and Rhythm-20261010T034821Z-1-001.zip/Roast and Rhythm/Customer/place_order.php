<?php
header('Content-Type: application/json');
include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['cart'])) {
    echo json_encode(['success' => false, 'message' => 'Cart is empty']);
    exit;
}

$user_id = $_SESSION['user_id'];
$total = (float)$data['total'];
$order_type = isset($data['order_type']) ? $data['order_type'] : 'takeout';
$pass_redeemed = !empty($data['pass_redeemed']);
$table_number = isset($_SESSION['table_number']) ? (int)$_SESSION['table_number'] : null;

$conn->begin_transaction();

try {
    // Removed pass_redeemed from the INSERT statement to match your database schema
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, order_type, table_number, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
    $stmt->bind_param("idsi", $user_id, $total, $order_type, $table_number);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, product_name, size, sugar, milk, extras, quantity, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    foreach ($data['cart'] as $item) {
        $product_id = (int)$item['id'];
        $product_name = $item['name'];
        $size = isset($item['size']) ? $item['size'] : '';
        $sugar = isset($item['sugar']) ? $item['sugar'] : '';
        $milk = isset($item['milk']) ? $item['milk'] : '';
        $extras = isset($item['extras']) ? (is_array($item['extras']) ? implode(', ', $item['extras']) : $item['extras']) : '';
        $quantity = (int)$item['quantity'];
        $price = (float)$item['price'];

        $item_stmt->bind_param("iisssssid", $order_id, $product_id, $product_name, $size, $sugar, $milk, $extras, $quantity, $price);
        $item_stmt->execute();
    }
    $item_stmt->close();

    // Still updates user subscription cups if a pass was redeemed
    if ($pass_redeemed) {
        $sub_stmt = $conn->prepare("UPDATE user_subscriptions SET total_cups = GREATEST(0, total_cups - 1) WHERE user_id = ? AND status = 'active'");
        $sub_stmt->bind_param("i", $user_id);
        $sub_stmt->execute();
        $sub_stmt->close();
    }

    $conn->commit();
    echo json_encode(['success' => true, 'order_id' => $order_id]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>