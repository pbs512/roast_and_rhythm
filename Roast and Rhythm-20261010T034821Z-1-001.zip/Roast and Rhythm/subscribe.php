<?php

session_start();

header('Content-Type: application/json; charset=utf-8');

try {

    require_once '../Config/database.php';

    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'You must be logged in.'
        ]);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);

    if (!is_array($data)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request.'
        ]);
        exit;
    }

    $user_id = (int)$_SESSION['user_id'];
    $plan_id = $data['plan_id'] ?? null;

    if (!$plan_id) {
        echo json_encode([
            'success' => false,
            'message' => 'No subscription plan selected.'
        ]);
        exit;
    }

    if (is_numeric($plan_id)) {

        $plan_id = (int)$plan_id;

    } else {

        $plan_name = strtolower(trim($plan_id));

        $plan_map = [
            'weekly' => 1,
            'monthly' => 2,
            'vip' => 3
        ];

        if (!isset($plan_map[$plan_name])) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid subscription plan.'
            ]);
            exit;
        }

        $plan_id = $plan_map[$plan_name];
    }

    $plan_stmt = $conn->prepare("
        SELECT id, validity_days, total_cups
        FROM subscription_plans
        WHERE id = ?
        LIMIT 1
    ");

    $plan_stmt->bind_param("i", $plan_id);
    $plan_stmt->execute();

    $plan_result = $plan_stmt->get_result();
    $plan = $plan_result->fetch_assoc();

    $plan_stmt->close();

    if (!$plan) {
        echo json_encode([
            'success' => false,
            'message' => 'Subscription plan not found.'
        ]);
        exit;
    }

    $cups = (int)$plan['total_cups'];
    $validity_days = (int)$plan['validity_days'];

    $start_date = date('Y-m-d');

    $expiration_date = date(
        'Y-m-d',
        strtotime("+{$validity_days} days")
    );

    $check_stmt = $conn->prepare("
        SELECT id
        FROM user_subscriptions
        WHERE user_id = ?
        AND status = 'active'
        LIMIT 1
    ");

    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();

    $check_result = $check_stmt->get_result();
    $existing = $check_result->fetch_assoc();

    $check_stmt->close();

    if ($existing) {

        $subscription_id = (int)$existing['id'];

        $update_stmt = $conn->prepare("
            UPDATE user_subscriptions
            SET plan_id = ?,
                remaining_cups = ?,
                total_cups = ?,
                start_date = ?,
                expiration_date = ?,
                status = 'active'
            WHERE id = ?
        ");

        $update_stmt->bind_param(
            "iiissi",
            $plan_id,
            $cups,
            $cups,
            $start_date,
            $expiration_date,
            $subscription_id
        );

        $update_stmt->execute();
        $update_stmt->close();

    } else {

        $insert_stmt = $conn->prepare("
            INSERT INTO user_subscriptions
            (
                user_id,
                plan_id,
                remaining_cups,
                total_cups,
                start_date,
                expiration_date,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, 'active')
        ");

        $insert_stmt->bind_param(
            "iiiiss",
            $user_id,
            $plan_id,
            $cups,
            $cups,
            $start_date,
            $expiration_date
        );

        $insert_stmt->execute();
        $insert_stmt->close();
    }

    echo json_encode([
        'success' => true,
        'message' => 'Subscription purchased successfully!',
        'plan_id' => $plan_id,
        'cups' => $cups,
        'expiration_date' => $expiration_date
    ]);

} catch (Throwable $e) {

    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);

    exit;
}
?>