<?php

require_once __DIR__ . '/../Config/database.php';

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function normalizeStatus($status) {

    $status = strtolower(trim($status));

    $map = [
        'pending' => 'placed',
        'order placed' => 'placed',
        'order_placed' => 'placed',
        'preparing' => 'in_preparation',
        'ready for pickup' => 'ready_for_delivery',
        'ready_for_pickup' => 'ready_for_delivery',
        'ready for delivery' => 'ready_for_delivery',
        'out for delivery' => 'out_for_delivery',
        'out_for_delivery' => 'out_for_delivery',
        'delivered' => 'completed',
        'served' => 'completed'
    ];

    return $map[$status] ?? $status;
}


/*
|--------------------------------------------------------------------------
| UPDATE ORDER STATUS
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['ajax_update'])
) {

    ini_set('display_errors', 0);
    error_reporting(E_ALL);

    header('Content-Type: application/json; charset=utf-8');

    $order_id = isset($_POST['order_id'])
        ? (int)$_POST['order_id']
        : 0;

    $raw_status = isset($_POST['new_status'])
        ? $_POST['new_status']
        : '';

    $new_status = normalizeStatus($raw_status);

    $allowed_statuses = [
        'placed',
        'in_preparation',
        'ready_for_delivery',
        'out_for_delivery',
        'completed',
        'cancelled'
    ];

    if (
        $order_id <= 0 ||
        !in_array($new_status, $allowed_statuses, true)
    ) {

        echo json_encode([
            'success' => false,
            'message' => 'Invalid status or order ID.'
        ]);

        exit;
    }

    $stmt = $conn->prepare(
        "UPDATE orders SET status = ? WHERE id = ?"
    );

    if (!$stmt) {

        echo json_encode([
            'success' => false,
            'message' => 'Database query error: ' . $conn->error
        ]);

        exit;
    }

    $stmt->bind_param(
        "si",
        $new_status,
        $order_id
    );

    if ($stmt->execute()) {

        echo json_encode([
            'success' => true,
            'message' =>
                'Order #RR-' .
                $order_id .
                ' is now ' .
                strtoupper(
                    str_replace(
                        '_',
                        ' ',
                        $new_status
                    )
                ),
            'status' => $new_status,
            'order_id' => $order_id
        ]);

    } else {

        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $stmt->error
        ]);
    }

    $stmt->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| ASSIGN RIDER
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['assign_rider'])
) {

    ini_set('display_errors', 0);
    error_reporting(E_ALL);

    header('Content-Type: application/json; charset=utf-8');

    $order_id = isset($_POST['order_id'])
        ? (int)$_POST['order_id']
        : 0;

    $rider_id = isset($_POST['rider_id'])
        ? (int)$_POST['rider_id']
        : 0;

    if ($order_id <= 0) {

        echo json_encode([
            'success' => false,
            'message' => 'Invalid order ID.'
        ]);

        exit;
    }

    if ($rider_id <= 0) {

        echo json_encode([
            'success' => false,
            'message' => 'Please select a rider.'
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Check Rider
    |--------------------------------------------------------------------------
    */

    $riderStmt = $conn->prepare("
        SELECT
            id,
            fullname
        FROM users
        WHERE id = ?
        AND role = 'rider'
        LIMIT 1
    ");

    if (!$riderStmt) {

        echo json_encode([
            'success' => false,
            'message' => 'Rider query error: ' . $conn->error
        ]);

        exit;
    }

    $riderStmt->bind_param(
        "i",
        $rider_id
    );

    $riderStmt->execute();

    $riderResult =
        $riderStmt->get_result();

    $rider =
        $riderResult->fetch_assoc();

    $riderStmt->close();


    if (!$rider) {

        echo json_encode([
            'success' => false,
            'message' => 'Selected rider was not found.'
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Check Order
    |--------------------------------------------------------------------------
    */

    $orderStmt = $conn->prepare("
        SELECT
            id
        FROM orders
        WHERE id = ?
        LIMIT 1
    ");

    if (!$orderStmt) {

        echo json_encode([
            'success' => false,
            'message' => 'Order query error: ' . $conn->error
        ]);

        exit;
    }

    $orderStmt->bind_param(
        "i",
        $order_id
    );

    $orderStmt->execute();

    $orderResult =
        $orderStmt->get_result();

    $order =
        $orderResult->fetch_assoc();

    $orderStmt->close();


    if (!$order) {

        echo json_encode([
            'success' => false,
            'message' => 'Order not found.'
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Save Rider
    |--------------------------------------------------------------------------
    */

    $updateRiderStmt = $conn->prepare("
        UPDATE orders
        SET rider_id = ?
        WHERE id = ?
    ");

    if (!$updateRiderStmt) {

        echo json_encode([
            'success' => false,
            'message' => 'Assignment query error: ' . $conn->error
        ]);

        exit;
    }

    $updateRiderStmt->bind_param(
        "ii",
        $rider_id,
        $order_id
    );

    if ($updateRiderStmt->execute()) {

        echo json_encode([
            'success' => true,
            'message' =>
                'Rider ' .
                $rider['fullname'] .
                ' assigned to Order #RR-' .
                $order_id,
            'order_id' => $order_id,
            'rider_id' => $rider_id,
            'rider_name' => $rider['fullname']
        ]);

    } else {

        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to assign rider: ' .
                $updateRiderStmt->error
        ]);
    }

    $updateRiderStmt->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| GET RIDERS
|--------------------------------------------------------------------------
*/

$riders = [];

$riderQuery = $conn->query("
    SELECT
        id,
        fullname
    FROM users
    WHERE role = 'rider'
    ORDER BY fullname ASC
");

if ($riderQuery) {

    while ($rider = $riderQuery->fetch_assoc()) {

        $riders[] = $rider;
    }
}


/*
|--------------------------------------------------------------------------
| GET ACTIVE ORDERS
|--------------------------------------------------------------------------
*/

$query = "
    SELECT
        o.id,
        o.total_amount,
        o.status,
        o.order_type,
        o.table_number,
        o.rider_id,
        o.created_at,
        u.fullname AS rider_name
    FROM orders o
    LEFT JOIN users u
        ON o.rider_id = u.id
        AND u.role = 'rider'
    WHERE o.status NOT IN ('completed', 'cancelled')
    ORDER BY o.id DESC
";

$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Barista - Order Management</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: #FAF7F2;
            color: #3D2314;
            padding: 20px;
            margin: 0;
        }

        h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        .alert {
            padding: 10px 14px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-weight: 600;
            display: none;
        }

        .alert-success {
            background: #E2F0D9;
            color: #2B5B11;
            border: 1px solid #C5E0B4;
        }

        .alert-error {
            background: #FCE4D6;
            color: #C00000;
            border: 1px solid #F8CBAD;
        }

        .order-card {
            background: #FFF;
            border: 1px solid #EFE8DE;
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            transition:
                border-color 0.3s ease,
                transform 0.2s ease;
        }

        .order-card:hover {
            border-color: #C49A6C;
        }

        .order-info {
            font-weight: bold;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .table-tag {
            background-color: #8C6239;
            color: #FFF;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.9rem;
        }

        .takeout-tag {
            background-color: #6c757d;
            color: #FFF;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.9rem;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .status-placed {
            background-color: #FFF3CD;
            color: #856404;
            border: 1px solid #FFEEBA;
        }

        .status-in_preparation {
            background-color: #CCE5FF;
            color: #004085;
            border: 1px solid #B8DAFF;
        }

        .status-ready_for_delivery {
            background-color: #D4EDDA;
            color: #155724;
            border: 1px solid #C3E6CB;
        }

        .status-out_for_delivery {
            background-color: #CCE5FF;
            color: #004085;
            border: 1px solid #B8DAFF;
        }

        .status-completed {
            background-color: #E2E3E5;
            color: #383D41;
            border: 1px solid #D6D8DB;
        }

        .status-cancelled {
            background-color: #F8D7DA;
            color: #721C24;
            border: 1px solid #F5C6CB;
        }

        @keyframes statusHighlight {

            0% {
                transform: scale(1);
                box-shadow: 0 0 0 rgba(140, 98, 57, 0);
            }

            50% {
                transform: scale(1.08);
                box-shadow: 0 0 12px rgba(140, 98, 57, 0.5);
            }

            100% {
                transform: scale(1);
                box-shadow: 0 0 0 rgba(140, 98, 57, 0);
            }

        }

        .status-updated {
            animation:
                statusHighlight 1.2s ease-in-out infinite;
        }

        .order-actions {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .rider-assignment {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .rider-assignment label {
            font-size: 0.85rem;
            font-weight: 700;
        }

        .rider-select {
            min-width: 170px;
        }

        .assign-rider-btn {
            background-color: #8C6239;
        }

        .assign-rider-btn:hover {
            background-color: #6F4C2D;
        }

        .assign-rider-btn.assigned {
            background-color: #5C8A29;
        }

        .assigned-rider {
            background: #F3EEE8;
            border: 1px solid #E3D5C5;
            padding: 7px 10px;
            border-radius: 8px;
            font-size: 0.85rem;
            font-weight: 700;
        }

        select {
            padding: 9px 12px;
            border-radius: 8px;
            border: 1px solid #C49A6C;
            background: #FFF;
            font-weight: 600;
            color: #3D2314;
            cursor: pointer;
        }

        button {
            background-color: #3D2314;
            color: white;
            border: none;
            padding: 9px 16px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition:
                background-color 0.2s ease,
                transform 0.1s ease;
        }

        button:hover {
            background-color: #8C6239;
        }

        button:active {
            transform: scale(0.97);
        }

        button:disabled {
            opacity: 0.65;
            cursor: not-allowed;
        }

        .delivery-btn {
            background-color: #5C8A29;
            padding: 10px 18px;
        }

        .delivery-btn:hover {
            background-color: #42691D;
        }

        .delivery-btn:disabled {
            background-color: #999;
            cursor: not-allowed;
        }

        .completed-btn {
            background-color: #777;
        }

        .completed-btn:hover {
            background-color: #555;
        }

        @media (max-width: 1100px) {

            .order-card {
                flex-direction: column;
                align-items: stretch;
            }

            .order-actions {
                justify-content: flex-start;
            }

        }

        @media (max-width: 600px) {

            body {
                padding: 12px;
            }

            .order-card {
                padding: 14px;
            }

            .order-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .order-actions form {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
            }

            .rider-assignment {
                width: 100%;
            }

            .rider-select {
                flex: 1;
                min-width: 0;
            }

        }

    </style>

</head>

<body>

    <h2>☕ Active Barista Orders</h2>

    <div
        id="flash-message"
        class="alert"
    ></div>


    <?php if ($result && $result->num_rows > 0): ?>

        <?php while ($order = $result->fetch_assoc()): ?>

            <?php

                $current_status =
                    normalizeStatus($order['status']);

                $assigned_rider_id =
                    !empty($order['rider_id'])
                    ? (int)$order['rider_id']
                    : 0;

                $assigned_rider_name =
                    $order['rider_name'] ?? '';

            ?>

            <div
                class="order-card"
                id="order-card-<?php echo $order['id']; ?>"
            >

                <div class="order-info">

                    <span>
                        Order #RR-<?php echo $order['id']; ?>
                    </span>

                    <span>|</span>


                    <?php if (
                        isset($order['order_type']) &&
                        $order['order_type'] === 'dine_in' &&
                        !empty($order['table_number'])
                    ): ?>

                        <span class="table-tag">

                            📍 Table

                            <?php
                            echo htmlspecialchars(
                                $order['table_number']
                            );
                            ?>

                        </span>

                    <?php else: ?>

                        <span class="takeout-tag">
                            🛍️ Takeout
                        </span>

                    <?php endif; ?>


                    <span>|</span>


                    <span>

                        ₱<?php

                        echo number_format(
                            $order['total_amount'],
                            2
                        );

                        ?>

                    </span>


                    <span>|</span>


                    <span
                        class="status-badge status-<?php echo htmlspecialchars($current_status); ?>"
                        id="badge-<?php echo $order['id']; ?>"
                    >

                        <?php

                        echo strtoupper(
                            str_replace(
                                '_',
                                ' ',
                                $current_status
                            )
                        );

                        ?>

                    </span>

                </div>


                <div class="order-actions">


                    <div class="rider-assignment">

                        <label>
                            Rider:
                        </label>


                        <select
                            class="rider-select"
                            id="rider-select-<?php echo $order['id']; ?>"
                        >

                            <option value="">
                                Select Rider
                            </option>


                            <?php foreach ($riders as $rider): ?>

                                <option
                                    value="<?php echo (int)$rider['id']; ?>"
                                    <?php

                                    echo (
                                        $assigned_rider_id ===
                                        (int)$rider['id']
                                    )
                                    ? 'selected'
                                    : '';

                                    ?>
                                >

                                    <?php

                                    echo htmlspecialchars(
                                        $rider['fullname']
                                    );

                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>


                        <button
                            type="button"
                            class="<?php echo $assigned_rider_id ? 'assign-rider-btn assigned' : 'assign-rider-btn'; ?>"
                            id="assign-btn-<?php echo $order['id']; ?>"
                            onclick="assignRider(<?php echo $order['id']; ?>)"
                        >

                            <?php if ($assigned_rider_id): ?>

                                Assigned

                            <?php else: ?>

                                Assign Rider

                            <?php endif; ?>

                        </button>


                        <?php if ($assigned_rider_id && $assigned_rider_name): ?>

                            <span
                                class="assigned-rider"
                                id="assigned-rider-<?php echo $order['id']; ?>"
                            >

                                Assigned to:
                                <?php
                                echo htmlspecialchars(
                                    $assigned_rider_name
                                );
                                ?>

                            </span>

                        <?php else: ?>

                            <span
                                class="assigned-rider"
                                id="assigned-rider-<?php echo $order['id']; ?>"
                                style="display:none;"
                            ></span>

                        <?php endif; ?>

                    </div>


                    <?php if (
                        $current_status === 'in_preparation' ||
                        $current_status === 'placed'
                    ): ?>

                        <button
                            type="button"
                            class="delivery-btn"
                            onclick="markReadyForDelivery(<?php echo $order['id']; ?>)"
                        >

                            Ready for Delivery

                        </button>

                    <?php elseif (
                        $current_status === 'ready_for_delivery'
                    ): ?>

                        <button
                            type="button"
                            class="delivery-btn"
                            disabled
                        >

                            Ready for Delivery

                        </button>

                    <?php elseif (
                        $current_status === 'out_for_delivery'
                    ): ?>

                        <button
                            type="button"
                            class="completed-btn"
                            onclick="markDelivered(<?php echo $order['id']; ?>)"
                        >

                            Mark as Delivered

                        </button>

                    <?php endif; ?>


                    <form
                        onsubmit="updateOrderStatus(
                            event,
                            <?php echo $order['id']; ?>
                        )"
                    >

                        <select
                            id="status-select-<?php echo $order['id']; ?>"
                        >

                            <option
                                value="placed"
                                <?php

                                echo (
                                    $current_status === 'placed'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                Order Placed
                            </option>


                            <option
                                value="in_preparation"
                                <?php

                                echo (
                                    $current_status === 'in_preparation'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                In Preparation
                            </option>


                            <option
                                value="ready_for_delivery"
                                <?php

                                echo (
                                    $current_status === 'ready_for_delivery'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                Ready for Delivery
                            </option>


                            <option
                                value="out_for_delivery"
                                <?php

                                echo (
                                    $current_status === 'out_for_delivery'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                Out for Delivery
                            </option>


                            <option
                                value="completed"
                                <?php

                                echo (
                                    $current_status === 'completed'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                Delivered
                            </option>


                            <option
                                value="cancelled"
                                <?php

                                echo (
                                    $current_status === 'cancelled'
                                )
                                ? 'selected'
                                : '';

                                ?>
                            >
                                Cancelled
                            </option>

                        </select>


                        <button type="submit">
                            Update Status
                        </button>

                    </form>

                </div>

            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <p>No active orders found.</p>

    <?php endif; ?>


<script>


/*
|--------------------------------------------------------------------------
| ASSIGN RIDER
|--------------------------------------------------------------------------
*/

function assignRider(orderId) {

    const select =
        document.getElementById(
            'rider-select-' + orderId
        );

    const button =
        document.getElementById(
            'assign-btn-' + orderId
        );

    const assignedRider =
        document.getElementById(
            'assigned-rider-' + orderId
        );

    const msgBox =
        document.getElementById(
            'flash-message'
        );


    if (!select || !button) {
        return;
    }


    const riderId =
        select.value;


    if (!riderId) {

        msgBox.style.display =
            'block';

        msgBox.className =
            'alert alert-error';

        msgBox.innerText =
            'Please select a rider first.';

        return;
    }


    button.disabled =
        true;

    button.innerText =
        'Assigning...';


    const formData =
        new FormData();


    formData.append(
        'assign_rider',
        '1'
    );

    formData.append(
        'order_id',
        orderId
    );

    formData.append(
        'rider_id',
        riderId
    );


    fetch(
        window.location.href,
        {
            method: 'POST',
            body: formData
        }
    )

    .then(function(response) {

        return response.text();

    })

    .then(function(text) {

        let data;


        try {

            data =
                JSON.parse(text);

        } catch (error) {

            console.error(
                'Invalid server response:',
                text
            );

            throw new Error(
                'Invalid server response.'
            );
        }


        msgBox.style.display =
            'block';


        if (data.success) {

            msgBox.className =
                'alert alert-success';

            msgBox.innerText =
                data.message;


            button.disabled =
                false;

            button.className =
                'assign-rider-btn assigned';

            button.innerText =
                'Assigned';


            if (assignedRider) {

                assignedRider.style.display =
                    'inline-block';

                assignedRider.innerText =
                    'Assigned to: ' +
                    data.rider_name;

            }


        } else {

            msgBox.className =
                'alert alert-error';

            msgBox.innerText =
                data.message ||
                'Failed to assign rider.';


            button.disabled =
                false;

            button.innerText =
                'Assign Rider';

        }

    })

    .catch(function(error) {

        console.error(
            'Assign Rider Error:',
            error
        );


        msgBox.style.display =
            'block';

        msgBox.className =
            'alert alert-error';

        msgBox.innerText =
            error.message ||
            'Network error while assigning rider.';


        button.disabled =
            false;

        button.innerText =
            'Assign Rider';

    });

}


/*
|--------------------------------------------------------------------------
| UPDATE ORDER STATUS
|--------------------------------------------------------------------------
*/

function sendStatusUpdate(
    orderId,
    newStatus,
    callback
) {

    const msgBox =
        document.getElementById(
            'flash-message'
        );


    const formData =
        new FormData();


    formData.append(
        'ajax_update',
        '1'
    );

    formData.append(
        'order_id',
        orderId
    );

    formData.append(
        'new_status',
        newStatus
    );


    fetch(
        window.location.href,
        {
            method: 'POST',
            body: formData
        }
    )

    .then(function(response) {

        return response.text();

    })

    .then(function(text) {

        let data;


        try {

            data =
                JSON.parse(text);

        } catch (error) {

            console.error(
                'Invalid server response:',
                text
            );

            throw new Error(
                'Invalid server response.'
            );
        }


        msgBox.style.display =
            'block';


        if (data.success) {

            msgBox.className =
                'alert alert-success';

            msgBox.innerText =
                data.message;


            updateOrderDisplay(
                orderId,
                newStatus
            );


            if (callback) {
                callback();
            }


        } else {

            msgBox.className =
                'alert alert-error';

            msgBox.innerText =
                data.message ||
                'Failed to update order.';

        }

    })

    .catch(function(error) {

        console.error(
            'Update Error:',
            error
        );


        msgBox.style.display =
            'block';

        msgBox.className =
            'alert alert-error';

        msgBox.innerText =
            error.message ||
            'Network error during status update.';

    });

}


/*
|--------------------------------------------------------------------------
| READY FOR DELIVERY
|--------------------------------------------------------------------------
*/

function markReadyForDelivery(orderId) {

    const button =
        document.querySelector(
            '#order-card-' +
            orderId +
            ' .delivery-btn'
        );


    if (button) {

        button.disabled =
            true;

        button.innerText =
            'Updating...';

    }


    sendStatusUpdate(
        orderId,
        'ready_for_delivery',
        function() {

            const badge =
                document.getElementById(
                    'badge-' + orderId
                );


            if (badge) {

                badge.innerText =
                    'READY FOR DELIVERY';


                badge.className =
                    'status-badge status-ready_for_delivery status-updated';


                setTimeout(
                    function() {

                        badge.classList.remove(
                            'status-updated'
                        );

                    },
                    3600
                );

            }


            if (button) {

                button.disabled =
                    true;

                button.innerText =
                    'Ready for Delivery';

            }

        }
    );

}


/*
|--------------------------------------------------------------------------
| MARK DELIVERED
|--------------------------------------------------------------------------
*/

function markDelivered(orderId) {

    const button =
        document.querySelector(
            '#order-card-' +
            orderId +
            ' .completed-btn'
        );


    if (button) {

        button.disabled =
            true;

        button.innerText =
            'Completing...';

    }


    sendStatusUpdate(
        orderId,
        'completed',
        function() {

            const card =
                document.getElementById(
                    'order-card-' +
                    orderId
                );


            if (card) {

                setTimeout(
                    function() {

                        card.remove();


                        const remaining =
                            document.querySelectorAll(
                                '.order-card'
                            );


                        if (
                            remaining.length === 0
                        ) {

                            const emptyMessage =
                                document.createElement(
                                    'p'
                                );


                            emptyMessage.innerText =
                                'No active orders found.';


                            document.body.appendChild(
                                emptyMessage
                            );

                        }

                    },
                    800
                );

            }

        }
    );

}


/*
|--------------------------------------------------------------------------
| MANUAL STATUS UPDATE
|--------------------------------------------------------------------------
*/

function updateOrderStatus(
    event,
    orderId
) {

    event.preventDefault();


    const selectElem =
        document.getElementById(
            'status-select-' +
            orderId
        );


    if (!selectElem) {
        return;
    }


    const newStatus =
        selectElem.value;


    sendStatusUpdate(
        orderId,
        newStatus
    );

}


/*
|--------------------------------------------------------------------------
| UPDATE ORDER DISPLAY
|--------------------------------------------------------------------------
*/

function updateOrderDisplay(
    orderId,
    newStatus
) {

    const badge =
        document.getElementById(
            'badge-' +
            orderId
        );


    if (badge) {

        badge.innerText =
            newStatus
                .replace(
                    /_/g,
                    ' '
                )
                .toUpperCase();


        badge.className =
            'status-badge status-' +
            newStatus +
            ' status-updated';


        setTimeout(
            function() {

                badge.classList.remove(
                    'status-updated'
                );

            },
            3600
        );

    }


    const card =
        document.getElementById(
            'order-card-' +
            orderId
        );


    if (!card) {
        return;
    }


    if (
        newStatus === 'completed' ||
        newStatus === 'cancelled'
    ) {

        setTimeout(
            function() {

                card.remove();

            },
            800
        );

        return;
    }


    const actions =
        card.querySelector(
            '.order-actions'
        );


    if (!actions) {
        return;
    }


    const existingDeliveryButton =
        actions.querySelector(
            '.delivery-btn'
        );


    if (
        newStatus ===
        'ready_for_delivery'
    ) {

        if (existingDeliveryButton) {

            existingDeliveryButton.disabled =
                true;

            existingDeliveryButton.innerText =
                'Ready for Delivery';

        }

        return;
    }


    if (
        newStatus ===
        'out_for_delivery'
    ) {

        if (existingDeliveryButton) {

            existingDeliveryButton.className =
                'completed-btn';

            existingDeliveryButton.disabled =
                false;

            existingDeliveryButton.innerText =
                'Mark as Delivered';


            existingDeliveryButton.onclick =
                function() {

                    markDelivered(
                        orderId
                    );

                };

        }

    }

}

</script>

</body>

</html>