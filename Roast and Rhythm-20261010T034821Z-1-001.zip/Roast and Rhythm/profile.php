<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'Config/database.php';

$message = '';
$message_type = '';
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $new_password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (!empty($full_name) && !empty($email)) {
        try {
            $address_parts = array_map('trim', explode(',', $address));

            $house_no = $address_parts[0] ?? '';
            $street_name = $address_parts[1] ?? '';
            $city = $address_parts[2] ?? '';
            $country_zip = $address_parts[3] ?? '';

            $country = $country_zip;
            $zip_code = '';

            if (preg_match('/\s+(\d{4,6})$/', $country_zip, $matches)) {
                $zip_code = $matches[1];
                $country = trim(preg_replace('/\s+\d{4,6}$/', '', $country_zip));
            }

            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

                $stmt = $conn->prepare("
                    UPDATE users 
                    SET name = ?, 
                        email = ?, 
                        house_no = ?, 
                        street_name = ?, 
                        city = ?, 
                        country = ?, 
                        zip_code = ?, 
                        password = ?
                    WHERE id = ?
                ");

                $stmt->bind_param(
                    "ssssssssi",
                    $full_name,
                    $email,
                    $house_no,
                    $street_name,
                    $city,
                    $country,
                    $zip_code,
                    $hashed_password,
                    $user_id
                );
            } else {
                $stmt = $conn->prepare("
                    UPDATE users 
                    SET name = ?, 
                        email = ?, 
                        house_no = ?, 
                        street_name = ?, 
                        city = ?, 
                        country = ?, 
                        zip_code = ?
                    WHERE id = ?
                ");

                $stmt->bind_param(
                    "sssssssi",
                    $full_name,
                    $email,
                    $house_no,
                    $street_name,
                    $city,
                    $country,
                    $zip_code,
                    $user_id
                );
            }

            if ($stmt->execute()) {
                $_SESSION['name'] = $full_name;
                $_SESSION['fullname'] = $full_name;

                $message = "Profile details updated successfully!";
                $message_type = "success";
            } else {
                $message = "Could not update details. Please try again.";
                $message_type = "error";
            }

            $stmt->close();

        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                $message = "This email address is already taken by another account.";
            } else {
                $message = "Database error: " . $e->getMessage();
            }

            $message_type = "error";
        }
    } else {
        $message = "Full Name and Email Address cannot be blank.";
        $message_type = "error";
    }
}

$user_stmt = $conn->prepare("
    SELECT username, email, name, house_no, street_name, city, country, zip_code, contact_number, profile_pic
    FROM users
    WHERE id = ?
");

$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();

$user_stmt->bind_result(
    $db_username,
    $db_email,
    $db_name,
    $db_house_no,
    $db_street_name,
    $db_city,
    $db_country,
    $db_zip_code,
    $db_contact_number,
    $db_profile_pic
);

$user_stmt->fetch();
$user_stmt->close();

$db_address = trim(
    $db_house_no . ', ' .
    $db_street_name . ', ' .
    $db_city . ', ' .
    $db_country . ' ' .
    $db_zip_code
);

$db_address = trim($db_address, " ,");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Rhythm - My Account</title>

    <style>
        :root {
            --cream: #FAF5EF;
            --dark-brown: #3C2A20;
            --medium-brown: #795548;
            --light-cream: #FFFDFB;
            --text-main: #2F1F17;
            --text-muted: #8D7B70;
            --shadow: 0 8px 24px rgba(60, 42, 32, 0.08);
            --transition: all 0.25s ease;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--cream);
            color: var(--text-main);
            min-height: 100vh;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .back-link {
            text-decoration: none;
            color: var(--medium-brown);
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 25px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--dark-brown);
            transform: translateX(-3px);
        }

        .profile-card {
            background-color: var(--light-cream);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(121, 85, 72, 0.12);
            width: 100%;
            max-width: 520px;
            box-sizing: border-box;
        }

        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .avatar-container {
            position: relative;
            width: 100px;
            height: 100px;
            margin: 0 auto 15px;
        }

        .avatar-preview {
            width: 100%;
            height: 100%;
            background-color: var(--cream);
            border-radius: 50%;
            border: 3px solid var(--dark-brown);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            color: var(--dark-brown);
            font-weight: bold;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        .profile-header h2 {
            margin: 10px 0 5px;
            color: var(--dark-brown);
            font-size: 1.6rem;
        }

        .profile-header p {
            margin: 0;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }

        .full-width {
            grid-column: span 2;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        label {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark-brown);
        }

        input,
        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid rgba(121, 85, 72, 0.25);
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 0.92rem;
            background-color: var(--cream);
            color: var(--text-main);
            font-family: inherit;
            transition: var(--transition);
        }

        input:focus,
        textarea:focus {
            outline: none;
            border-color: var(--dark-brown);
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(60, 42, 32, 0.05);
        }

        input:read-only {
            background-color: rgba(121, 85, 72, 0.06);
            color: var(--text-muted);
            border-color: rgba(121, 85, 72, 0.15);
            cursor: not-allowed;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .save-btn {
            width: 100%;
            padding: 14px;
            background-color: var(--dark-brown);
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 15px;
            box-shadow: 0 4px 12px rgba(60, 42, 32, 0.15);
        }

        .save-btn:hover {
            background-color: var(--medium-brown);
            transform: translateY(-1px);
        }

        .alert {
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.88rem;
            text-align: center;
        }

        .alert.success {
            background-color: #e2f0d9;
            color: #385d1a;
            border: 1px solid #c5e0b4;
        }

        .alert.error {
            background-color: #fce8e6;
            color: #a83232;
            border: 1px solid #f5c2c2;
        }

        @media (max-width: 480px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .full-width {
                grid-column: span 1;
            }

            .profile-card {
                padding: 25px;
            }
        }
    </style>
</head>

<body>

<a href="index.php" class="back-link">← Back to Menu</a>

<div class="profile-card">

    <div class="profile-header">
        <div class="avatar-container">
            <div class="avatar-preview">
                <?php
                echo !empty($db_name)
                    ? strtoupper(substr($db_name, 0, 1))
                    : 'U';
                ?>
            </div>
        </div>

        <h2><?php echo htmlspecialchars($db_name ?? 'User'); ?></h2>
        <p>@<?php echo htmlspecialchars($db_username ?? ''); ?></p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert <?php echo htmlspecialchars($message_type); ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form action="profile.php" method="POST">

        <div class="form-grid">

            <div class="form-group">
                <label for="username">Username (Non-editable)</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value="<?php echo htmlspecialchars($db_username ?? ''); ?>"
                    readonly
                >
            </div>

            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input
                    type="text"
                    id="full_name"
                    name="full_name"
                    required
                    value="<?php echo htmlspecialchars($db_name ?? ''); ?>"
                    placeholder="Enter name"
                >
            </div>

            <div class="form-group full-width">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value="<?php echo htmlspecialchars($db_email ?? ''); ?>"
                    placeholder="e.g., info@brand.com"
                >
            </div>

            <div class="form-group full-width">
                <label for="address">Delivery / Shipping Address</label>
                <textarea
                    id="address"
                    name="address"
                    placeholder="House No., Street, City, Country ZIP"
                ><?php echo htmlspecialchars($db_address); ?></textarea>
            </div>

            <div class="form-group full-width">
                <label for="password">Change Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Leave blank to keep your current password"
                >
            </div>

        </div>

        <button type="submit" class="save-btn">
            Save Profile Details
        </button>

    </form>

</div>

</body>
</html>