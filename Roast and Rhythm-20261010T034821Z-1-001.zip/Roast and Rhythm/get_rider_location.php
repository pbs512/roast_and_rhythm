<?php
require_once "database.php";

header("Content-Type: application/json");

$order_id = intval($_GET["order_id"] ?? 0);

if ($order_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid order ID."
    ]);
    exit;
}

$stmt = $conn->prepare("
    SELECT rider_name, latitude, longitude, status, updated_at
    FROM delivery_tracking
    WHERE order_id = ?
    ORDER BY id DESC
    LIMIT 1
");

$stmt->bind_param("i", $order_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Waiting for rider location..."
    ]);
    exit;
}

$data = $result->fetch_assoc();

echo json_encode([
    "success" => true,
    "rider_name" => $data["rider_name"],
    "latitude" => $data["latitude"],
    "longitude" => $data["longitude"],
    "status" => $data["status"],
    "updated_at" => $data["updated_at"]
]);

$stmt->close();
$conn->close();
?>