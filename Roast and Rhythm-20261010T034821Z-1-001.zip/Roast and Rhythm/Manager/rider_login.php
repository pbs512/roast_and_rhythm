<?php
session_start();
require_once "../database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare("
        SELECT id, username, fullname, password, role
FROM users
WHERE username = ? AND role = 'rider'
LIMIT 1
    ");

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $user = $result->fetch_assoc();

        if (
            password_verify($password, $user["password"]) ||
            $password === $user["password"]
        ) {

            $_SESSION["rider_id"] = $user["id"];
            $_SESSION["rider_username"] = $user["username"];
            $_SESSION["rider_name"] = $user["fullname"];

            header("Location: rider_tracking.php");
            exit;

        } else {
            $error = "Invalid username or password.";
        }

    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Rider Login</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Arial, sans-serif;
    background: #f5f5f5;
}

.login-card {
    width: 90%;
    max-width: 400px;
    background: white;
    padding: 35px;
    border-radius: 20px;
    box-shadow: 0 10px 35px rgba(0,0,0,.15);
}

.logo {
    text-align: center;
    font-size: 42px;
    margin-bottom: 10px;
}

h1 {
    text-align: center;
    margin: 0;
    color: #222;
}

.subtitle {
    text-align: center;
    color: #777;
    margin: 8px 0 25px;
}

input {
    width: 100%;
    padding: 14px;
    margin-bottom: 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    font-size: 15px;
}

button {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 10px;
    background: #6f4e37;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #593d2c;
}

.error {
    background: #ffe9e9;
    color: #c62828;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 15px;
    text-align: center;
}

</style>

</head>

<body>

<div class="login-card">

    <div class="logo">🛵</div>

    <h1>Rider Login</h1>

    <p class="subtitle">
        Sign in to start your delivery
    </p>

    <?php if ($error): ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>

    <form method="POST">

        <input
            type="text"
            name="username"
            placeholder="Rider username"
            required
        >

        <input
            type="password"
            name="password"
            placeholder="Password"
            required
        >

        <button type="submit">
            Login as Rider
        </button>

    </form>

</div>

</body>
</html>