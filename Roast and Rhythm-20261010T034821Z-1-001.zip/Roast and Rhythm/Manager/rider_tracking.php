<?php

session_start();

if (!isset($_SESSION["rider_id"])) {
    header("Location: rider_login.php");
    exit;
}

require_once __DIR__ . "/../Config/database.php";

$riders = [];

$riderStmt = $conn->prepare("
    SELECT id, fullname
    FROM users
    WHERE LOWER(role) = 'rider'
    ORDER BY id ASC
    LIMIT 2
");

$riderStmt->execute();
$riderResult = $riderStmt->get_result();

while ($rider = $riderResult->fetch_assoc()) {
    $riders[] = $rider;
}

$riderStmt->close();

$orders = [];

foreach ($riders as $rider) {

    $stmt = $conn->prepare("
        SELECT
            o.id,
            o.status,
            o.latitude,
            o.longitude,
            o.user_id,
            u.fullname,
            u.house_no,
            u.street_name,
            u.city,
            u.country,
            u.zip_code
        FROM orders o
        LEFT JOIN users u
            ON u.id = o.user_id
        WHERE o.rider_id = ?
        AND o.status NOT IN ('delivered', 'completed', 'cancelled')
        ORDER BY o.id DESC
        LIMIT 1
    ");

    $stmt->bind_param("i", $rider["id"]);
    $stmt->execute();

    $result = $stmt->get_result();

    $orders[$rider["id"]] = $result->fetch_assoc();

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Rider GPS Tracking</title>

<link
    rel="stylesheet"
    href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    min-height: 100vh;
    padding: 30px;
}

.top-bar {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}

.navigation {
    display: flex;
    gap: 10px;
}

.nav-btn {
    width: auto;
    margin: 0;
    padding: 11px 18px;
    background: #6f4e37;
    text-decoration: none;
    color: white;
    border-radius: 10px;
    font-size: 14px;
    display: inline-block;
}

.logout-btn {
    background: #842029;
}

.nav-btn:hover {
    opacity: .9;
}

.page-title {
    text-align: center;
    margin: 0 0 25px;
    color: #3d2314;
}

.riders-container {
    width: 100%;
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
}

.card {
    width: 100%;
    background: white;
    padding: 25px;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0,0,0,.12);
}

.rider-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.rider-icon {
    width: 55px;
    height: 55px;
    border-radius: 50%;
    background: #6f4e37;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 25px;
}

.rider-header h2 {
    margin: 0;
    color: #3d2314;
}

.rider-header p {
    margin: 4px 0 0;
    color: #777;
    font-size: 13px;
}

.order-box {
    background: #f7f3ef;
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 15px;
}

.order-box strong {
    font-size: 18px;
}

.status {
    margin-top: 8px;
    font-weight: bold;
    color: #6f4e37;
}

.delivery-address {
    margin-top: 12px;
    padding: 15px;
    background: #f7f3ef;
    border-radius: 12px;
    line-height: 1.6;
}

.delivery-title {
    font-weight: bold;
    color: #3d2314;
    margin-bottom: 5px;
}

.customer-name {
    font-weight: bold;
    color: #6f4e37;
    margin-bottom: 5px;
}

.address-text {
    color: #555;
    font-size: 14px;
}

.eta-box {
    margin-top: 12px;
    padding: 14px;
    border-radius: 12px;
    background: #fff8e7;
    border: 1px solid #ead8a7;
    color: #6b5315;
}

.eta-title {
    font-size: 13px;
    font-weight: bold;
    margin-bottom: 5px;
}

.eta-time {
    font-size: 20px;
    font-weight: bold;
    color: #3d2314;
}

.eta-distance {
    margin-top: 4px;
    font-size: 13px;
    color: #777;
}

button {
    width: 100%;
    padding: 14px;
    margin-top: 10px;
    border: 0;
    border-radius: 10px;
    background: #6f4e37;
    color: white;
    font-size: 15px;
    cursor: pointer;
}

button:hover {
    opacity: .9;
}

button:disabled {
    background: #aaa;
    cursor: not-allowed;
}

.stop-btn {
    background: #777;
}

.delivered-btn {
    background: #198754;
}

.status-box {
    margin-top: 18px;
    padding: 14px;
    border-radius: 10px;
    background: #f1f1f1;
    line-height: 1.6;
    font-size: 14px;
}

.success {
    background: #d1e7dd !important;
    color: #0f5132;
}

.error {
    background: #f8d7da !important;
    color: #842029;
}

.no-order {
    background: #fff3cd;
    color: #856404;
    padding: 15px;
    border-radius: 10px;
}

.map-title {
    margin-top: 20px;
    margin-bottom: 8px;
    font-weight: bold;
    color: #3d2314;
    display: none;
}

.map {
    width: 100%;
    height: 350px;
    margin-top: 10px;
    border-radius: 15px;
    overflow: hidden;
    display: none;
    border: 1px solid #ddd;
}

.coordinates {
    margin-top: 10px;
    padding: 10px;
    background: #f7f3ef;
    border-radius: 10px;
    font-size: 13px;
    color: #555;
    display: none;
}

@media (max-width: 800px) {

    .riders-container {
        grid-template-columns: 1fr;
    }

    body {
        padding: 15px;
    }

    .top-bar {
        flex-direction: column;
        align-items: stretch;
    }

    .navigation {
        width: 100%;
    }

    .nav-btn {
        flex: 1;
        text-align: center;
    }

}

</style>

</head>

<body>

<div class="top-bar">

    <div class="navigation">

        <a
            href="../diary.php"
            class="nav-btn"
        >
            ← Back to Diary
        </a>

    </div>

    <div class="navigation">

        <a
            href="rider_logout.php"
            class="nav-btn logout-btn"
        >
            Logout
        </a>

    </div>

</div>

<h1 class="page-title">
    Rider GPS Tracking
</h1>

<div class="riders-container">

<?php foreach ($riders as $index => $rider): ?>

<?php

$riderNumber = $index + 1;

$order = $orders[$rider["id"]] ?? null;

?>

<div class="card">

<div class="rider-header">

<div class="rider-icon">
    🛵
</div>

<div>

<h2>
    Rider <?php echo $riderNumber; ?>
</h2>

<p>
    <?php echo htmlspecialchars($rider["fullname"]); ?>
</p>

</div>

</div>

<?php if ($order): ?>

<div class="order-box">

    Assigned Order:

    <strong>
        #RR-<?php echo $order["id"]; ?>
    </strong>

    <br>

    Status:

    <span
        class="status"
        id="orderStatus_<?php echo $rider["id"]; ?>"
    >
        <?php echo htmlspecialchars($order["status"]); ?>
    </span>

</div>

<div class="delivery-address">

    <div class="delivery-title">
        Delivery Address
    </div>

    <div class="customer-name">

        <?php

        echo htmlspecialchars(
            $order["fullname"] ?? "Customer"
        );

        ?>

    </div>

    <div class="address-text">

        <?php

        $addressParts = [];

        if (!empty($order["house_no"])) {
            $addressParts[] = $order["house_no"];
        }

        if (!empty($order["street_name"])) {
            $addressParts[] = $order["street_name"];
        }

        if (!empty($order["city"])) {
            $addressParts[] = $order["city"];
        }

        if (!empty($order["country"])) {
            $addressParts[] = $order["country"];
        }

        if (!empty($order["zip_code"])) {
            $addressParts[] = $order["zip_code"];
        }

        if (count($addressParts) > 0) {

            echo htmlspecialchars(
                implode(", ", $addressParts)
            );

        } else {

            echo "Delivery address not available.";

        }

        ?>

    </div>

</div>

<div class="eta-box">

    <div class="eta-title">
        Estimated Arrival
    </div>

    <div
        class="eta-time"
        id="etaTime_<?php echo $rider["id"]; ?>"
    >
        Waiting for GPS...
    </div>

    <div
        class="eta-distance"
        id="etaDistance_<?php echo $rider["id"]; ?>"
    >
        Start tracking to calculate arrival time.
    </div>

</div>

<input
    type="hidden"
    id="order_<?php echo $rider["id"]; ?>"
    value="<?php echo $order["id"]; ?>"
>

<input
    type="hidden"
    id="destinationLat_<?php echo $rider["id"]; ?>"
    value="<?php echo htmlspecialchars($order["latitude"] ?? ""); ?>"
>

<input
    type="hidden"
    id="destinationLng_<?php echo $rider["id"]; ?>"
    value="<?php echo htmlspecialchars($order["longitude"] ?? ""); ?>"
>

<button
    id="startBtn_<?php echo $rider["id"]; ?>"
    onclick="startTracking(<?php echo $rider["id"]; ?>)"
>
    Start Delivery Tracking
</button>

<button
    class="stop-btn"
    id="stopBtn_<?php echo $rider["id"]; ?>"
    onclick="stopTracking(<?php echo $rider["id"]; ?>)"
    disabled
>
    Stop Tracking
</button>

<button
    class="delivered-btn"
    id="deliveredBtn_<?php echo $rider["id"]; ?>"
    onclick="markDelivered(<?php echo $rider["id"]; ?>)"
>
    ✓ Mark as Delivered
</button>

<div
    class="status-box"
    id="statusBox_<?php echo $rider["id"]; ?>"
>
    Waiting for GPS...
</div>

<div
    class="map-title"
    id="mapTitle_<?php echo $rider["id"]; ?>"
>
    Live Rider Location
</div>

<div
    class="map"
    id="map_<?php echo $rider["id"]; ?>"
></div>

<div
    class="coordinates"
    id="coordinates_<?php echo $rider["id"]; ?>"
>
    Waiting for location...
</div>

<?php else: ?>

<div class="no-order">
    No assigned delivery yet.
</div>

<?php endif; ?>

</div>

<?php endforeach; ?>

</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>

const riderData = {};

<?php foreach ($riders as $rider): ?>

riderData[
    <?php echo $rider["id"]; ?>
] = {
    watchId: null,
    map: null,
    marker: null,
    firstLocation: true
};

<?php endforeach; ?>

function calculateETA(
    riderId,
    latitude,
    longitude
) {

    const destinationLatElement =
        document.getElementById(
            "destinationLat_" + riderId
        );

    const destinationLngElement =
        document.getElementById(
            "destinationLng_" + riderId
        );

    const etaTime =
        document.getElementById(
            "etaTime_" + riderId
        );

    const etaDistance =
        document.getElementById(
            "etaDistance_" + riderId
        );

    if (
        !destinationLatElement ||
        !destinationLngElement
    ) {
        return;
    }

    const destinationLat =
        parseFloat(
            destinationLatElement.value
        );

    const destinationLng =
        parseFloat(
            destinationLngElement.value
        );

    if (
        isNaN(destinationLat) ||
        isNaN(destinationLng)
    ) {

        etaTime.textContent =
            "Destination unavailable";

        etaDistance.textContent =
            "Customer location coordinates are not available.";

        return;
    }

    const earthRadius = 6371;

    const latDifference =
        (destinationLat - latitude) *
        Math.PI / 180;

    const lngDifference =
        (destinationLng - longitude) *
        Math.PI / 180;

    const a =
        Math.sin(latDifference / 2) *
        Math.sin(latDifference / 2) +
        Math.cos(
            latitude *
            Math.PI / 180
        ) *
        Math.cos(
            destinationLat *
            Math.PI / 180
        ) *
        Math.sin(lngDifference / 2) *
        Math.sin(lngDifference / 2);

    const c =
        2 *
        Math.atan2(
            Math.sqrt(a),
            Math.sqrt(1 - a)
        );

    const distance =
        earthRadius * c;

    const averageSpeed = 25;

    let minutes =
        Math.ceil(
            (distance / averageSpeed) * 60
        );

    if (minutes < 1) {
        minutes = 1;
    }

    const arrivalTime =
        new Date(
            Date.now() +
            minutes * 60 * 1000
        );

    const timeString =
        arrivalTime.toLocaleTimeString(
            [],
            {
                hour: "numeric",
                minute: "2-digit"
            }
        );

    etaTime.textContent =
        minutes + " min";

    etaDistance.textContent =
        distance.toFixed(2) +
        " km away • Estimated arrival " +
        timeString;
}

function initializeMap(
    riderId,
    latitude,
    longitude
) {

    const mapElement =
        document.getElementById(
            "map_" + riderId
        );

    const mapTitle =
        document.getElementById(
            "mapTitle_" + riderId
        );

    const coordinates =
        document.getElementById(
            "coordinates_" + riderId
        );

    mapElement.style.display =
        "block";

    mapTitle.style.display =
        "block";

    coordinates.style.display =
        "block";

    const data =
        riderData[riderId];

    if (data.map === null) {

        data.map =
            L.map(
                mapElement
            ).setView(
                [
                    latitude,
                    longitude
                ],
                17
            );

        L.tileLayer(
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            {
                maxZoom: 19,
                attribution:
                    "&copy; OpenStreetMap contributors"
            }
        ).addTo(
            data.map
        );

        data.marker =
            L.marker(
                [
                    latitude,
                    longitude
                ]
            )
            .addTo(
                data.map
            )
            .bindPopup(
                "Rider Location"
            )
            .openPopup();

    } else {

        data.marker.setLatLng(
            [
                latitude,
                longitude
            ]
        );

        if (data.firstLocation) {

            data.map.setView(
                [
                    latitude,
                    longitude
                ],
                17
            );

        }

    }

    data.firstLocation =
        false;

    coordinates.innerHTML =
        "<strong>Current Location</strong><br>" +
        "Latitude: " +
        latitude.toFixed(6) +
        "<br>" +
        "Longitude: " +
        longitude.toFixed(6);

    setTimeout(
        function() {
            data.map.invalidateSize();
        },
        200
    );

    calculateETA(
        riderId,
        latitude,
        longitude
    );
}

function startTracking(
    riderId
) {

    const orderInput =
        document.getElementById(
            "order_" + riderId
        );

    const statusBox =
        document.getElementById(
            "statusBox_" + riderId
        );

    if (!orderInput) {
        return;
    }

    const orderId =
        orderInput.value;

    if (!orderId) {

        statusBox.className =
            "status-box error";

        statusBox.textContent =
            "No assigned order.";

        return;
    }

    if (!navigator.geolocation) {

        statusBox.className =
            "status-box error";

        statusBox.textContent =
            "GPS is not supported by this browser.";

        return;
    }

    statusBox.className =
        "status-box";

    statusBox.textContent =
        "Requesting GPS permission...";

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const latitude =
                position.coords.latitude;

            const longitude =
                position.coords.longitude;

            initializeMap(
                riderId,
                latitude,
                longitude
            );

            statusBox.className =
                "status-box success";

            statusBox.innerHTML =
                "<strong>GPS Active</strong><br>" +
                "Rider location is being tracked.";

            document.getElementById(
                "startBtn_" + riderId
            ).disabled =
                true;

            document.getElementById(
                "stopBtn_" + riderId
            ).disabled =
                false;

            sendLocation(
                riderId,
                orderId,
                latitude,
                longitude
            );

            riderData[riderId].watchId =
                navigator.geolocation.watchPosition(

                    function(position) {

                        const latitude =
                            position.coords.latitude;

                        const longitude =
                            position.coords.longitude;

                        initializeMap(
                            riderId,
                            latitude,
                            longitude
                        );

                        statusBox.className =
                            "status-box success";

                        statusBox.innerHTML =
                            "<strong>GPS Active</strong><br>" +
                            "Live location is updating.";

                        sendLocation(
                            riderId,
                            orderId,
                            latitude,
                            longitude
                        );

                    },

                    function(error) {

                        showGpsError(
                            error,
                            statusBox
                        );

                    },

                    {
                        enableHighAccuracy: true,
                        maximumAge: 5000,
                        timeout: 15000
                    }

                );

        },

        function(error) {

            showGpsError(
                error,
                statusBox
            );

        },

        {
            enableHighAccuracy: true,
            maximumAge: 0,
            timeout: 15000
        }

    );
}

function showGpsError(
    error,
    statusBox
) {

    statusBox.className =
        "status-box error";

    if (error.code === 1) {

        statusBox.textContent =
            "GPS permission denied.";

    } else if (error.code === 2) {

        statusBox.textContent =
            "GPS position unavailable.";

    } else if (error.code === 3) {

        statusBox.textContent =
            "GPS request timed out.";

    } else {

        statusBox.textContent =
            "GPS error.";

    }
}

function sendLocation(
    riderId,
    orderId,
    latitude,
    longitude
) {

    const data =
        new FormData();

    data.append(
        "order_id",
        orderId
    );

    data.append(
        "rider_id",
        riderId
    );

    data.append(
        "latitude",
        latitude
    );

    data.append(
        "longitude",
        longitude
    );

    fetch(
        "update_rider_location.php",
        {
            method: "POST",
            body: data,
            cache: "no-store"
        }
    )

    .then(
        function(response) {
            return response.text();
        }
    )

    .then(
        function(text) {

            try {

                const result =
                    JSON.parse(text);

                if (!result.success) {

                    document.getElementById(
                        "statusBox_" + riderId
                    ).className =
                        "status-box error";

                    document.getElementById(
                        "statusBox_" + riderId
                    ).textContent =
                        result.message;

                } else {

                    document.getElementById(
                        "orderStatus_" + riderId
                    ).textContent =
                        "out_for_delivery";

                }

            } catch (error) {

                console.log(
                    "Server response:",
                    text
                );

            }

        }
    )

    .catch(
        function(error) {

            console.log(
                "GPS request error:",
                error
            );

        }
    );
}

function stopTracking(
    riderId
) {

    const data =
        riderData[riderId];

    if (
        data.watchId !== null
    ) {

        navigator.geolocation.clearWatch(
            data.watchId
        );

        data.watchId =
            null;
    }

    const statusBox =
        document.getElementById(
            "statusBox_" + riderId
        );

    statusBox.className =
        "status-box";

    statusBox.textContent =
        "GPS tracking stopped.";

    document.getElementById(
        "startBtn_" + riderId
    ).disabled =
        false;

    document.getElementById(
        "stopBtn_" + riderId
    ).disabled =
        true;

    document.getElementById(
        "etaTime_" + riderId
    ).textContent =
        "Tracking stopped";

    document.getElementById(
        "etaDistance_" + riderId
    ).textContent =
        "Start tracking again to update the ETA.";
}

function markDelivered(
    riderId
) {

    const orderInput =
        document.getElementById(
            "order_" + riderId
        );

    const button =
        document.getElementById(
            "deliveredBtn_" + riderId
        );

    const statusBox =
        document.getElementById(
            "statusBox_" + riderId
        );

    if (!orderInput) {
        return;
    }

    const orderId =
        parseInt(
            orderInput.value
        );

    if (
        !orderId ||
        orderId <= 0
    ) {

        alert(
            "Invalid order ID."
        );

        return;
    }

    if (
        !confirm(
            "Are you sure you want to mark this order as delivered?"
        )
    ) {
        return;
    }

    button.disabled =
        true;

    button.textContent =
        "Updating...";

    const data =
        riderData[riderId];

    if (
        data &&
        data.watchId !== null
    ) {

        navigator.geolocation.clearWatch(
            data.watchId
        );

        data.watchId =
            null;
    }

    const formData =
        new FormData();

    formData.append(
        "order_id",
        orderId
    );

    formData.append(
        "rider_id",
        riderId
    );

    fetch(
        "mark_delivered.php",
        {
            method: "POST",
            body: formData
        }
    )

    .then(
        function(response) {
            return response.text();
        }
    )

    .then(
        function(text) {

            try {

                const result =
                    JSON.parse(text);

                if (result.success) {

                    document.getElementById(
                        "startBtn_" + riderId
                    ).disabled =
                        true;

                    document.getElementById(
                        "stopBtn_" + riderId
                    ).disabled =
                        true;

                    document.getElementById(
                        "orderStatus_" + riderId
                    ).textContent =
                        "delivered";

                    button.textContent =
                        "✓ Order Delivered";

                    statusBox.className =
                        "status-box success";

                    statusBox.innerHTML =
                        "<strong>Order delivered successfully!</strong><br>" +
                        "Order #RR-" +
                        orderId +
                        " is now completed.";

                    document.getElementById(
                        "etaTime_" + riderId
                    ).textContent =
                        "Delivered";

                    document.getElementById(
                        "etaDistance_" + riderId
                    ).textContent =
                        "Order has been delivered successfully.";

                } else {

                    button.disabled =
                        false;

                    button.textContent =
                        "✓ Mark as Delivered";

                    alert(
                        result.message
                    );

                }

            } catch (error) {

                button.disabled =
                    false;

                button.textContent =
                    "✓ Mark as Delivered";

                alert(
                    "Invalid server response: " +
                    text
                );

            }

        }
    )

    .catch(
        function(error) {

            button.disabled =
                false;

            button.textContent =
                "✓ Mark as Delivered";

            alert(
                "Connection error."
            );

        }
    );
}

</script>

</body>

</html>