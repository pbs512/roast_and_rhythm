<?php
session_start();

require_once "../database.php";

header("Content-Type: application/json");

if (!isset($_SESSION["rider_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "Rider login required."
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request."
    ]);
    exit;
}

$order_id = intval($_POST["order_id"] ?? 0);
$rider_id = intval($_POST["rider_id"] ?? 0);

if ($order_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid order ID."
    ]);
    exit;
}

if ($rider_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid rider ID."
    ]);
    exit;
}

$riderCheck = $conn->prepare("
    SELECT id
    FROM users
    WHERE id = ?
    AND LOWER(role) = 'rider'
    LIMIT 1
");

$riderCheck->bind_param(
    "i",
    $rider_id
);

$riderCheck->execute();

$riderResult =
    $riderCheck->get_result();

if ($riderResult->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "message" => "Rider does not exist."
    ]);

    exit;
}

$riderCheck->close();

$check = $conn->prepare("
    SELECT id
    FROM orders
    WHERE id = ?
    AND rider_id = ?
    LIMIT 1
");

$check->bind_param(
    "ii",
    $order_id,
    $rider_id
);

$check->execute();

$result =
    $check->get_result();

if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "message" => "Order is not assigned to this rider."
    ]);

    exit;
}

$check->close();

$orderStmt = $conn->prepare("
    UPDATE orders
    SET status = 'delivered'
    WHERE id = ?
    AND rider_id = ?
");

$orderStmt->bind_param(
    "ii",
    $order_id,
    $rider_id
);

if (!$orderStmt->execute()) {

    echo json_encode([
        "success" => false,
        "message" => "Failed to update order."
    ]);

    exit;
}

$orderStmt->close();

$trackStmt = $conn->prepare("
    UPDATE delivery_tracking
    SET status = 'delivered'
    WHERE order_id = ?
");

$trackStmt->bind_param(
    "i",
    $order_id
);

$trackStmt->execute();

$trackStmt->close();

echo json_encode([
    "success" => true,
    "message" => "Order marked as delivered."
]);

$conn->close();
?>