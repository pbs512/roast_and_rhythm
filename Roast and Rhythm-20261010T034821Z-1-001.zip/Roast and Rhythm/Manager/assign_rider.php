<?php

header('Content-Type: application/json');

include '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
$rider_id = isset($_POST['rider_id']) ? (int)$_POST['rider_id'] : 0;

if ($order_id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid order ID'
    ]);
    exit;
}

if ($rider_id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Please select a rider'
    ]);
    exit;
}

try {

    $riderStmt = $conn->prepare("
        SELECT id, fullname
        FROM users
        WHERE id = ?
        AND role = 'rider'
        LIMIT 1
    ");

    if (!$riderStmt) {
        throw new Exception($conn->error);
    }

    $riderStmt->bind_param("i", $rider_id);
    $riderStmt->execute();

    $riderResult = $riderStmt->get_result();
    $rider = $riderResult->fetch_assoc();

    $riderStmt->close();

    if (!$rider) {
        echo json_encode([
            'success' => false,
            'message' => 'Rider not found'
        ]);
        exit;
    }

    $orderStmt = $conn->prepare("
        SELECT id
        FROM orders
        WHERE id = ?
        LIMIT 1
    ");

    if (!$orderStmt) {
        throw new Exception($conn->error);
    }

    $orderStmt->bind_param("i", $order_id);
    $orderStmt->execute();

    $orderResult = $orderStmt->get_result();
    $order = $orderResult->fetch_assoc();

    $orderStmt->close();

    if (!$order) {
        echo json_encode([
            'success' => false,
            'message' => 'Order not found'
        ]);
        exit;
    }

    $updateStmt = $conn->prepare("
        UPDATE orders
        SET rider_id = ?
        WHERE id = ?
    ");

    if (!$updateStmt) {
        throw new Exception($conn->error);
    }

    $updateStmt->bind_param("ii", $rider_id, $order_id);
    $updateStmt->execute();

    $updateStmt->close();

    echo json_encode([
        'success' => true,
        'message' => 'Rider assigned successfully',
        'order_id' => $order_id,
        'rider_id' => $rider_id,
        'rider_name' => $rider['fullname']
    ]);

} catch (Exception $e) {

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>