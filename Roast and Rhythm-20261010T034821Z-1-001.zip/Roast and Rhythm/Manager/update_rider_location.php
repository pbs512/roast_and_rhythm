<?php
session_start();

require_once __DIR__ . "/../Config/database.php";

header("Content-Type: application/json");
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION["rider_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "Rider login required."
    ]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

$rider_id = intval($_SESSION["rider_id"]);
$rider_name = $_SESSION["rider_name"] ?? "Rider";

$order_id = intval($_POST["order_id"] ?? 0);
$latitude = isset($_POST["latitude"]) ? floatval($_POST["latitude"]) : 0;
$longitude = isset($_POST["longitude"]) ? floatval($_POST["longitude"]) : 0;

if ($order_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid order ID."
    ]);
    exit;
}

if ($latitude == 0 || $longitude == 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid GPS coordinates."
    ]);
    exit;
}

$orderCheck = $conn->prepare("
    SELECT id, status
    FROM orders
    WHERE id = ?
    AND rider_id = ?
    LIMIT 1
");

if (!$orderCheck) {
    echo json_encode([
        "success" => false,
        "message" => "Database error."
    ]);
    exit;
}

$orderCheck->bind_param("ii", $order_id, $rider_id);
$orderCheck->execute();

$orderResult = $orderCheck->get_result();
$order = $orderResult->fetch_assoc();

$orderCheck->close();

if (!$order) {
    echo json_encode([
        "success" => false,
        "message" => "Order is not assigned to this rider."
    ]);
    exit;
}

if (
    $order["status"] === "delivered" ||
    $order["status"] === "completed" ||
    $order["status"] === "cancelled"
) {
    echo json_encode([
        "success" => false,
        "message" => "This order is already closed."
    ]);
    exit;
}

$check = $conn->prepare("
    SELECT id
    FROM delivery_tracking
    WHERE order_id = ?
    LIMIT 1
");

if (!$check) {
    echo json_encode([
        "success" => false,
        "message" => "Tracking database error."
    ]);
    exit;
}

$check->bind_param("i", $order_id);
$check->execute();

$result = $check->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    $stmt = $conn->prepare("
        UPDATE delivery_tracking
        SET rider_name = ?,
            latitude = ?,
            longitude = ?,
            status = 'out_for_delivery',
            updated_at = NOW()
        WHERE id = ?
    ");

    if (!$stmt) {
        $check->close();

        echo json_encode([
            "success" => false,
            "message" => "Failed to prepare tracking update."
        ]);

        exit;
    }

    $stmt->bind_param(
        "sddi",
        $rider_name,
        $latitude,
        $longitude,
        $row["id"]
    );

} else {

    $stmt = $conn->prepare("
        INSERT INTO delivery_tracking
        (
            order_id,
            rider_name,
            latitude,
            longitude,
            status,
            updated_at
        )
        VALUES (?, ?, ?, ?, 'out_for_delivery', NOW())
    ");

    if (!$stmt) {
        $check->close();

        echo json_encode([
            "success" => false,
            "message" => "Failed to prepare tracking insert."
        ]);

        exit;
    }

    $stmt->bind_param(
        "isdd",
        $order_id,
        $rider_name,
        $latitude,
        $longitude
    );
}

if (!$stmt->execute()) {

    $stmt->close();
    $check->close();

    echo json_encode([
        "success" => false,
        "message" => "Failed to save GPS location."
    ]);

    exit;
}

$stmt->close();
$check->close();

$statusUpdate = $conn->prepare("
    UPDATE orders
    SET status = 'out_for_delivery'
    WHERE id = ?
    AND rider_id = ?
    AND status NOT IN ('delivered', 'completed', 'cancelled')
");

if ($statusUpdate) {

    $statusUpdate->bind_param(
        "ii",
        $order_id,
        $rider_id
    );

    $statusUpdate->execute();
    $statusUpdate->close();
}

echo json_encode([
    "success" => true,
    "message" => "Location updated.",
    "rider_name" => $rider_name,
    "order_status" => "out_for_delivery",
    "latitude" => $latitude,
    "longitude" => $longitude
]);

$conn->close();
?>