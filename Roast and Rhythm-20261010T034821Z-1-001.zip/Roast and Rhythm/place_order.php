<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'database.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function sendResponse($success, $message, $extra = [])
{
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}

if (!isset($_SESSION['user_id'])) {
    sendResponse(false, 'Please log in before placing an order.');
}

$data = json_decode(file_get_contents('php://input'), true);

if (!is_array($data)) {
    sendResponse(false, 'Invalid order data received.');
}

if (empty($data['cart']) || !is_array($data['cart'])) {
    sendResponse(false, 'Your cart is empty.');
}

$fulfillment = strtolower(trim((string)($data['fulfillment'] ?? '')));
$requested_order_type = strtolower(trim((string)($data['order_type'] ?? 'takeout')));

if (!in_array($fulfillment, ['delivery', 'pickup'], true)) {
    sendResponse(false, 'Please select delivery or self pick-up.');
}

$order_type = $fulfillment === 'delivery'
    ? 'delivery'
    : (
        $requested_order_type === 'dine_in' &&
        !empty($_SESSION['table_number'])
            ? 'dine_in'
            : 'takeout'
    );

$requested_payment_method = strtolower(trim(
    (string)($data['payment_method'] ?? '')
));

if (in_array($requested_payment_method, ['qr', 'qr_payment'], true)) {
    $payment_method = 'qr_payment';
} elseif (in_array($requested_payment_method, ['cod', 'cash_on_delivery'], true)) {
    $payment_method = 'cash_on_delivery';
} else {
    sendResponse(false, 'Please select Cash on Delivery or QR Payment.');
}

$user_id = (int)$_SESSION['user_id'];
$pass_redeemed = !empty($data['pass_redeemed']);
$table_number = $order_type === 'dine_in' && isset($_SESSION['table_number'])
    ? (int)$_SESSION['table_number']
    : null;

$total = 0;

foreach ($data['cart'] as $item) {
    if (!is_array($item)) {
        sendResponse(false, 'Invalid cart item.');
    }

    $quantity = (int)($item['quantity'] ?? 1);
    $price = (float)($item['price'] ?? 0);

    if ($quantity < 1 || $price < 0) {
        sendResponse(false, 'Invalid item quantity or price.');
    }

    $total += $price * $quantity;
}

try {
    $conn->begin_transaction();

    $stmt = $conn->prepare(
        "INSERT INTO orders
        (user_id, total_amount, order_type, payment_method,
         table_number, pass_redeemed, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())"
    );

    $stmt->bind_param(
        "idssii",
        $user_id,
        $total,
        $order_type,
        $payment_method,
        $table_number,
        $pass_redeemed
    );

    $stmt->execute();

    $order_id = $stmt->insert_id;
    $stmt->close();

    $item_stmt = $conn->prepare(
        "INSERT INTO order_items
        (order_id, product_id, product_name, size, sugar,
         milk, extras, quantity, price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );

    foreach ($data['cart'] as $item) {
        $product_id = (int)($item['id'] ?? 0);
        $product_name = (string)($item['name'] ?? 'Unknown item');
        $size = (string)($item['size'] ?? '');
        $sugar = (string)($item['sugar'] ?? '');
        $milk = (string)($item['milk'] ?? '');

        $extras = $item['extras'] ?? '';

        if (is_array($extras)) {
            $extras = implode(', ', $extras);
        } else {
            $extras = (string)$extras;
        }

        $quantity = (int)($item['quantity'] ?? 1);
        $price = (float)($item['price'] ?? 0);

        $item_stmt->bind_param(
            "iisssssid",
            $order_id,
            $product_id,
            $product_name,
            $size,
            $sugar,
            $milk,
            $extras,
            $quantity,
            $price
        );

        $item_stmt->execute();
    }

    $item_stmt->close();

    if ($pass_redeemed) {
        $sub_stmt = $conn->prepare(
            "UPDATE user_subscriptions
             SET total_cups = GREATEST(0, total_cups - 1)
             WHERE user_id = ? AND status = 'active'"
        );

        $sub_stmt->bind_param("i", $user_id);
        $sub_stmt->execute();
        $sub_stmt->close();
    }

    $conn->commit();

    sendResponse(true, 'Order placed successfully!', [
        'order_id' => $order_id,
        'order_type' => $order_type,
        'payment_method' => $payment_method,
        'total' => $total
    ]);

} catch (Throwable $e) {
    if (isset($conn) && $conn instanceof mysqli) {
        try {
            $conn->rollback();
        } catch (Throwable $rollbackError) {
        }
    }

    error_log('Order submission error: ' . $e->getMessage());

    sendResponse(
        false,
        'Unable to place your order. Please check the server error log.'
    );
}
?>