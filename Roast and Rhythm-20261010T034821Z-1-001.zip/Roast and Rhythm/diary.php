<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'Config/database.php';

$message = '';
$message_type = '';
$user_id = (int)$_SESSION['user_id'];

$conn->query("
    CREATE TABLE IF NOT EXISTS order_feedback (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        order_id INT NOT NULL,
        rating TINYINT NOT NULL,
        comment TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_order_feedback (user_id, order_id)
    )
");

if (isset($_SESSION['diary_message'])) {
    $message = $_SESSION['diary_message'];
    $message_type = $_SESSION['diary_message_type'] ?? 'success';

    unset($_SESSION['diary_message']);
    unset($_SESSION['diary_message_type']);
}

if (isset($_GET['success']) && $_GET['success'] == 1) {
    $message = "Order placed successfully!";
    $message_type = "success";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;

    if ($order_id > 0) {

        if ($action === 'submit_feedback') {
            $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
            $comment = trim($_POST['comment'] ?? '');

            $order_check = $conn->prepare("
                SELECT id, status
                FROM orders
                WHERE id = ?
                AND user_id = ?
                LIMIT 1
            ");

            if ($order_check) {
                $order_check->bind_param("ii", $order_id, $user_id);
                $order_check->execute();
                $order_result = $order_check->get_result();
                $feedback_order = $order_result->fetch_assoc();
                $order_check->close();

                if (!$feedback_order) {
                    $message = "Order not found.";
                    $message_type = "error";
                } elseif (!in_array(strtolower($feedback_order['status']), ['delivered', 'completed'], true)) {
                    $message = "You can leave feedback after your order has been delivered.";
                    $message_type = "error";
                } elseif ($rating < 1 || $rating > 5) {
                    $message = "Please select a rating from 1 to 5 stars.";
                    $message_type = "error";
                } else {
                    $feedback_stmt = $conn->prepare("
                        INSERT INTO order_feedback (user_id, order_id, rating, comment)
                        VALUES (?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                            rating = VALUES(rating),
                            comment = VALUES(comment),
                            created_at = CURRENT_TIMESTAMP
                    ");

                    if ($feedback_stmt) {
                        $feedback_stmt->bind_param("iiis", $user_id, $order_id, $rating, $comment);

                        if ($feedback_stmt->execute()) {
                            $message = "Thank you! Your feedback for Order #{$order_id} has been saved.";
                            $message_type = "success";
                        } else {
                            $message = "Unable to save your feedback. Please try again.";
                            $message_type = "error";
                        }

                        $feedback_stmt->close();
                    } else {
                        $message = "Database error while saving feedback.";
                        $message_type = "error";
                    }
                }
            } else {
                $message = "Database error while checking order.";
                $message_type = "error";
            }
        }

        if ($action === 'update_order_status') {
            $new_status = isset($_POST['status']) ? trim($_POST['status']) : '';

            $allowed_statuses = [
                'ready_for_delivery',
                'completed',
                'delivered'
            ];

            if (in_array($new_status, $allowed_statuses, true)) {
                $stmt = $conn->prepare("
                    UPDATE orders
                    SET status = ?
                    WHERE id = ?
                    AND user_id = ?
                ");

                if ($stmt) {
                    $stmt->bind_param("sii", $new_status, $order_id, $user_id);

                    if ($stmt->execute() && $stmt->affected_rows > 0) {
                        if ($new_status === 'completed' || $new_status === 'delivered') {
                            $message = "Order #{$order_id} has been marked as delivered.";
                        } else {
                            $message = "Order #{$order_id} is ready for pick up.";
                        }

                        $message_type = "success";
                    } else {
                        $message = "Unable to update the order.";
                        $message_type = "error";
                    }

                    $stmt->close();
                } else {
                    $message = "Database error.";
                    $message_type = "error";
                }
            } else {
                $message = "Invalid order status.";
                $message_type = "error";
            }
        }

        if ($action === 'assign_rider') {
            $rider_id = isset($_POST['rider_id']) ? (int)$_POST['rider_id'] : 0;

            if ($rider_id <= 0) {
                $message = "Please select a rider.";
                $message_type = "error";
            } else {
                $order_stmt = $conn->prepare("
                    SELECT id
                    FROM orders
                    WHERE id = ?
                    AND user_id = ?
                    LIMIT 1
                ");

                if ($order_stmt) {
                    $order_stmt->bind_param("ii", $order_id, $user_id);
                    $order_stmt->execute();
                    $order_result = $order_stmt->get_result();
                    $order_data = $order_result->fetch_assoc();
                    $order_stmt->close();

                    if (!$order_data) {
                        $message = "Order not found.";
                        $message_type = "error";
                    } else {
                        $rider_stmt = $conn->prepare("
                            SELECT id, fullname
                            FROM users
                            WHERE id = ?
                            AND LOWER(role) = 'rider'
                            LIMIT 1
                        ");

                        if ($rider_stmt) {
                            $rider_stmt->bind_param("i", $rider_id);
                            $rider_stmt->execute();
                            $rider_result = $rider_stmt->get_result();
                            $rider_data = $rider_result->fetch_assoc();
                            $rider_stmt->close();

                            if (!$rider_data) {
                                $message = "Selected rider was not found.";
                                $message_type = "error";
                            } else {
                                $availability_stmt = $conn->prepare("
                                    SELECT id
                                    FROM orders
                                    WHERE rider_id = ?
                                    AND status NOT IN ('completed', 'delivered', 'cancelled')
                                    AND id <> ?
                                    LIMIT 1
                                ");

                                if ($availability_stmt) {
                                    $availability_stmt->bind_param("ii", $rider_id, $order_id);
                                    $availability_stmt->execute();
                                    $availability_result = $availability_stmt->get_result();
                                    $busy_order = $availability_result->fetch_assoc();
                                    $availability_stmt->close();

                                    if ($busy_order) {
                                        $message = "This rider is currently assigned to another active order.";
                                        $message_type = "error";
                                    } else {
                                        $assign_stmt = $conn->prepare("
                                            UPDATE orders
                                            SET rider_id = ?
                                            WHERE id = ?
                                            AND user_id = ?
                                        ");

                                        if ($assign_stmt) {
                                            $assign_stmt->bind_param("iii", $rider_id, $order_id, $user_id);

                                            if ($assign_stmt->execute()) {
                                                $message = "Rider " . $rider_data['fullname'] . " has been assigned to Order #" . $order_id . ".";
                                                $message_type = "success";
                                            } else {
                                                $message = "Unable to assign rider.";
                                                $message_type = "error";
                                            }

                                            $assign_stmt->close();
                                        } else {
                                            $message = "Database error while assigning rider.";
                                            $message_type = "error";
                                        }
                                    }
                                } else {
                                    $message = "Database error while checking rider availability.";
                                    $message_type = "error";
                                }
                            }
                        } else {
                            $message = "Database error while checking rider.";
                            $message_type = "error";
                        }
                    }
                } else {
                    $message = "Database error while checking order.";
                    $message_type = "error";
                }
            }
        }

        if ($action === 'delete_order') {
            $check_stmt = $conn->prepare("
                SELECT id
                FROM orders
                WHERE id = ?
                AND user_id = ?
                LIMIT 1
            ");

            if ($check_stmt) {
                $check_stmt->bind_param("ii", $order_id, $user_id);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                $order_exists = $check_result->fetch_assoc();
                $check_stmt->close();

                if ($order_exists) {
                    $conn->begin_transaction();

                    try {
                        $item_stmt = $conn->prepare("
                            DELETE FROM order_items
                            WHERE order_id = ?
                        ");

                        if ($item_stmt) {
                            $item_stmt->bind_param("i", $order_id);
                            $item_stmt->execute();
                            $item_stmt->close();
                        }

                        $order_stmt = $conn->prepare("
                            DELETE FROM orders
                            WHERE id = ?
                            AND user_id = ?
                        ");

                        if (!$order_stmt) {
                            throw new Exception("Failed to delete order.");
                        }

                        $order_stmt->bind_param("ii", $order_id, $user_id);

                        if (!$order_stmt->execute()) {
                            throw new Exception($order_stmt->error);
                        }

                        $order_stmt->close();
                        $conn->commit();

                        $message = "Order #{$order_id} has been deleted.";
                        $message_type = "success";
                    } catch (Exception $e) {
                        $conn->rollback();
                        $message = "Failed to delete order.";
                        $message_type = "error";
                    }
                } else {
                    $message = "Order not found.";
                    $message_type = "error";
                }
            }
        }

        if ($action === 'reorder_entire_past_order') {
            $has_products_table = ($conn->query("SHOW TABLES LIKE 'products'")->num_rows > 0);
            $has_menu_table = ($conn->query("SHOW TABLES LIKE 'menu'")->num_rows > 0);

            $prod_join_sql = "";
            $prod_display_col = "oi.product_id";

            if ($has_products_table) {
                if ($conn->query("SHOW COLUMNS FROM products LIKE 'name'")->num_rows > 0) {
                    $prod_display_col = "p.name";
                } elseif ($conn->query("SHOW COLUMNS FROM products LIKE 'product_name'")->num_rows > 0) {
                    $prod_display_col = "p.product_name";
                }

                $prod_join_sql = "LEFT JOIN products p ON oi.product_id = p.id";
            } elseif ($has_menu_table) {
                if ($conn->query("SHOW COLUMNS FROM menu LIKE 'name'")->num_rows > 0) {
                    $prod_display_col = "m.name";
                } elseif ($conn->query("SHOW COLUMNS FROM menu LIKE 'item_name'")->num_rows > 0) {
                    $prod_display_col = "m.item_name";
                }

                $prod_join_sql = "LEFT JOIN menu m ON oi.product_id = m.id";
            }

            $item_stmt = $conn->prepare("
                SELECT
                    {$prod_display_col} AS product_name,
                    oi.product_id,
                    oi.quantity,
                    oi.price,
                    oi.size,
                    oi.sugar,
                    oi.milk,
                    oi.extras
                FROM order_items oi
                {$prod_join_sql}
                INNER JOIN orders o
                    ON oi.order_id = o.id
                WHERE oi.order_id = ?
                AND o.user_id = ?
            ");

            if ($item_stmt) {
                $item_stmt->bind_param("ii", $order_id, $user_id);
                $item_stmt->execute();
                $items_result = $item_stmt->get_result();

                if ($items_result && $items_result->num_rows > 0) {
                    if (!isset($_SESSION['cart'])) {
                        $_SESSION['cart'] = [];
                    }

                    while ($item = $items_result->fetch_assoc()) {
                        $p_name = !empty($item['product_name']) ? $item['product_name'] : 'Item';
                        $price = !empty($item['price']) ? (float)$item['price'] : 0.00;

                        $cart_item = [
                            'id' => $item['product_id'],
                            'product_id' => $item['product_id'],
                            'name' => $p_name,
                            'price' => $price,
                            'quantity' => (int)$item['quantity'],
                            'size' => !empty($item['size']) ? $item['size'] : 'N/A',
                            'sugar' => !empty($item['sugar']) ? $item['sugar'] : 'N/A',
                            'milk' => !empty($item['milk']) ? $item['milk'] : 'N/A',
                            'extras' => !empty($item['extras']) ? $item['extras'] : 'None'
                        ];

                        $cart_key = $item['product_id'] . '_' . md5(
                            json_encode([
                                $cart_item['size'],
                                $cart_item['sugar'],
                                $cart_item['milk'],
                                $cart_item['extras']
                            ])
                        );

                        if (isset($_SESSION['cart'][$cart_key])) {
                            $_SESSION['cart'][$cart_key]['quantity'] += (int)$item['quantity'];
                        } else {
                            $_SESSION['cart'][$cart_key] = $cart_item;
                        }
                    }

                    $item_stmt->close();
                    header("Location: cart.php?reordered=1");
                    exit();
                } else {
                    $message = "No items found for this order.";
                    $message_type = "error";
                }

                $item_stmt->close();
            }
        }
    }

    if (!empty($message)) {
        $_SESSION['diary_message'] = $message;
        $_SESSION['diary_message_type'] = $message_type;
    }

    header("Location: diary.php");
    exit();
}

$available_riders = [];

$rider_query = $conn->query("
    SELECT
        u.id,
        u.fullname
    FROM users u
    WHERE LOWER(u.role) = 'rider'
    AND NOT EXISTS (
        SELECT 1
        FROM orders o
        WHERE o.rider_id = u.id
        AND o.status NOT IN ('completed', 'delivered', 'cancelled')
    )
    ORDER BY u.fullname ASC
");

if ($rider_query) {
    while ($rider = $rider_query->fetch_assoc()) {
        $available_riders[] = $rider;
    }
}

$has_products_table = ($conn->query("SHOW TABLES LIKE 'products'")->num_rows > 0);
$has_menu_table = ($conn->query("SHOW TABLES LIKE 'menu'")->num_rows > 0);

$prod_join_sql = "";
$prod_display_col = "oi.product_id";

if ($has_products_table) {
    if ($conn->query("SHOW COLUMNS FROM products LIKE 'name'")->num_rows > 0) {
        $prod_display_col = "p.name";
    } elseif ($conn->query("SHOW COLUMNS FROM products LIKE 'product_name'")->num_rows > 0) {
        $prod_display_col = "p.product_name";
    }

    $prod_join_sql = "LEFT JOIN products p ON oi.product_id = p.id";
} elseif ($has_menu_table) {
    if ($conn->query("SHOW COLUMNS FROM menu LIKE 'name'")->num_rows > 0) {
        $prod_display_col = "m.name";
    } elseif ($conn->query("SHOW COLUMNS FROM menu LIKE 'item_name'")->num_rows > 0) {
        $prod_display_col = "m.item_name";
    }

    $prod_join_sql = "LEFT JOIN menu m ON oi.product_id = m.id";
}

$orders = [];

$query = "
    SELECT
        o.id AS order_id,
        o.status,
        o.order_type,
        o.rider_id,
        r.fullname AS rider_name,
        DATE_FORMAT(
            o.created_at,
            '%b %d, %Y - %h:%i %p'
        ) AS order_date,
        {$prod_display_col} AS product_name,
        oi.quantity,
        oi.size,
        oi.sugar,
        oi.milk,
        oi.extras
    FROM orders o
    LEFT JOIN order_items oi
        ON o.id = oi.order_id
    {$prod_join_sql}
    LEFT JOIN users r
        ON o.rider_id = r.id
        AND LOWER(r.role) = 'rider'
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
";

$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $oid = $row['order_id'];

            if (!isset($orders[$oid])) {
                $orders[$oid] = [
                    'order_id' => $oid,
                    'status' => $row['status'],
                    'order_type' => $row['order_type'],
                    'rider_id' => $row['rider_id'],
                    'rider_name' => $row['rider_name'],
                    'order_date' => $row['order_date'],
                    'items' => []
                ];
            }

            if (!empty($row['product_name'])) {
                $options = [];

                $isValidSpec = function ($val) {
                    if ($val === null || $val === '') {
                        return false;
                    }

                    $v = strtoupper(trim($val));

                    return !in_array($v, ['N/A', 'NONE', 'NULL', ''], true);
                };

                if ($isValidSpec($row['size'])) {
                    $options['Size'] = $row['size'];
                }

                if ($isValidSpec($row['sugar'])) {
                    $options['Sugar Level'] = $row['sugar'];
                }

                if ($isValidSpec($row['milk'])) {
                    $options['Milk Type'] = $row['milk'];
                }

                if ($isValidSpec($row['extras'])) {
                    $options['Add-ons / Extras'] = $row['extras'];
                }

                $orders[$oid]['items'][] = [
                    'product_name' => $row['product_name'],
                    'quantity' => $row['quantity'],
                    'options' => $options
                ];
            }
        }
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Roast & Rhythm - Quick Re-Order</title>

<style>
:root {
    --cream: #FAF5EF;
    --dark-brown: #3C2A20;
    --medium-brown: #795548;
    --light-cream: #FFFDFB;
    --text-main: #2F1F17;
    --text-muted: #8D7B70;
    --shadow: 0 8px 24px rgba(60, 42, 32, 0.08);
    --transition: all 0.25s ease;
}

* {
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background-color: var(--cream);
    color: var(--text-main);
    margin: 0;
    padding: 40px 20px;
    min-height: 100vh;
}

.page-container {
    width: 100%;
    max-width: 900px;
    margin: auto;
}

.back-link {
    text-decoration: none;
    color: var(--medium-brown);
    font-weight: 600;
    font-size: 0.9rem;
    margin-bottom: 20px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.header-section {
    text-align: center;
    margin-bottom: 30px;
}

.header-section h1 {
    color: var(--dark-brown);
    margin: 0 0 8px;
    font-size: 2.2rem;
}

.header-section p {
    color: var(--text-muted);
    margin: 0;
    font-size: 0.95rem;
}

.header-actions {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 25px;
}

.rider-tracking-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 11px 20px;
    background-color: var(--dark-brown);
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 700;
    transition: var(--transition);
}

.rider-tracking-btn:hover {
    background-color: var(--medium-brown);
    transform: translateY(-1px);
}

.alert {
    padding: 14px 18px;
    border-radius: 12px;
    margin-bottom: 25px;
    font-size: 0.9rem;
    text-align: center;
    font-weight: 600;
}

.alert.success {
    background-color: #e2f0d9;
    color: #385d1a;
    border: 1px solid #c5e0b4;
}

.alert.error {
    background-color: #fce8e6;
    color: #a83232;
    border: 1px solid #f5c2c2;
}

.orders-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
    gap: 22px;
}

.order-card {
    background-color: var(--light-cream);
    padding: 24px;
    border-radius: 20px;
    box-shadow: var(--shadow);
    border: 1px solid rgba(121, 85, 72, 0.12);
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 14px;
    border-bottom: 1px dashed rgba(121, 85, 72, 0.15);
    padding-bottom: 10px;
    gap: 12px;
}

.order-title {
    font-weight: bold;
    font-size: 1.15rem;
    color: var(--dark-brown);
    margin: 0;
}

.order-date {
    font-size: 0.8rem;
    color: var(--text-muted);
    margin: 4px 0 0;
}

.status-badge {
    padding: 5px 11px;
    border-radius: 10px;
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}

.status-pending,
.status-placed {
    background-color: #fff3cd;
    color: #856404;
}

.status-in_preparation {
    background-color: #cce5ff;
    color: #004085;
}

.status-ready_for_delivery {
    background-color: #d4edda;
    color: #155724;
}

.status-out_for_delivery {
    background-color: #cce5ff;
    color: #004085;
}

.status-completed {
    background-color: #e2e3e5;
    color: #383d41;
}

.status-delivered {
    background-color: #d1e7dd;
    color: #0f5132;
}

.status-cancelled {
    background-color: #f8d7da;
    color: #721c24;
}

.items-box {
    background-color: var(--cream);
    padding: 16px;
    border-radius: 14px;
    margin-bottom: 18px;
}

.item-row {
    padding-bottom: 10px;
    margin-bottom: 10px;
    border-bottom: 1px dashed rgba(121, 85, 72, 0.12);
}

.item-row:last-child {
    border-bottom: none;
    padding-bottom: 0;
    margin-bottom: 0;
}

.item-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 700;
    font-size: 1.05rem;
    color: var(--dark-brown);
    gap: 10px;
}

.item-qty {
    background-color: rgba(121, 85, 72, 0.15);
    color: var(--dark-brown);
    padding: 2px 9px;
    border-radius: 12px;
    font-size: 0.82rem;
    font-weight: 700;
}

.customization-details {
    background: #ffffff;
    border-radius: 10px;
    padding: 10px 12px;
    border: 1px solid rgba(121, 85, 72, 0.1);
    margin-top: 8px;
}

.spec-line {
    display: flex;
    justify-content: space-between;
    font-size: 0.83rem;
    padding: 4px 0;
    border-bottom: 1px dotted rgba(121, 85, 72, 0.08);
    gap: 10px;
}

.spec-line:last-child {
    border-bottom: none;
}

.spec-label {
    color: var(--text-muted);
    font-weight: 500;
}

.spec-value {
    color: var(--dark-brown);
    font-weight: 600;
    text-align: right;
}

.rider-box {
    background-color: #f7f0ea;
    border: 1px solid rgba(121, 85, 72, 0.15);
    padding: 14px;
    border-radius: 14px;
    margin-bottom: 16px;
}

.rider-title {
    color: var(--dark-brown);
    font-weight: 700;
    font-size: 0.9rem;
    margin-bottom: 9px;
}

.rider-current {
    color: var(--medium-brown);
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 10px;
}

.rider-form {
    display: flex;
    gap: 8px;
    align-items: stretch;
}

.rider-select {
    flex: 1;
    min-width: 0;
    padding: 11px;
    border-radius: 10px;
    border: 1px solid rgba(121, 85, 72, 0.25);
    background: white;
    color: var(--dark-brown);
    font-size: 0.85rem;
    outline: none;
}

.assign-btn {
    border: none;
    border-radius: 10px;
    padding: 11px 15px;
    background-color: #795548;
    color: white;
    font-weight: 700;
    cursor: pointer;
    white-space: nowrap;
}

.assign-btn:hover {
    background-color: #5D4037;
}

.no-rider {
    color: var(--text-muted);
    font-size: 0.83rem;
    margin: 0;
}

.order-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.order-actions form {
    flex: 1;
    min-width: 150px;
}

.order-actions button {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 12px;
    font-size: 0.88rem;
    font-weight: 700;
    cursor: pointer;
    transition: var(--transition);
}

.reorder-btn {
    background-color: var(--dark-brown);
    color: white;
}

.reorder-btn:hover {
    background-color: var(--medium-brown);
}

.ready-btn {
    background-color: #5C8A29;
    color: white;
}

.ready-btn:hover {
    background-color: #42691D;
}

.delivered-btn {
    background-color: #3D6E9E;
    color: white;
}

.delivered-btn:hover {
    background-color: #2D557A;
}

.delete-btn {
    background-color: #A94442;
    color: white;
}

.delete-btn:hover {
    background-color: #812F2D;
}

.feedback-box {
    background: #fffaf5;
    border: 1px solid rgba(121, 85, 72, 0.2);
    border-radius: 14px;
    padding: 16px;
    margin: 0 0 18px;
}

.feedback-title {
    color: var(--dark-brown);
    font-size: 0.95rem;
    font-weight: 700;
    margin: 0 0 10px;
}

.feedback-rating {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
    gap: 5px;
    margin: 0 0 12px;
}

.feedback-rating input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

.feedback-rating label {
    color: #d6c9bf;
    cursor: pointer;
    font-size: 1.8rem;
    line-height: 1;
}

.feedback-rating input:checked ~ label,
.feedback-rating label:hover,
.feedback-rating label:hover ~ label {
    color: #e6a23c;
}

.feedback-comment {
    width: 100%;
    min-height: 85px;
    resize: vertical;
    border: 1px solid rgba(121, 85, 72, 0.25);
    border-radius: 10px;
    padding: 11px;
    font: inherit;
    font-size: 0.88rem;
    margin-bottom: 10px;
    background: #fff;
}

.feedback-submit {
    width: 100%;
    padding: 11px;
    border: none;
    border-radius: 10px;
    background: var(--dark-brown);
    color: white;
    font-weight: 700;
    cursor: pointer;
}

.feedback-submit:hover {
    background: var(--medium-brown);
}

.feedback-saved {
    color: #385d1a;
    background: #e2f0d9;
    border-radius: 10px;
    padding: 12px;
    font-size: 0.88rem;
    margin-bottom: 18px;
}

.empty-history {
    text-align: center;
    padding: 50px 20px;
    color: var(--text-muted);
    background-color: var(--light-cream);
    border-radius: 20px;
    border: 1px dashed rgba(121, 85, 72, 0.2);
    grid-column: 1 / -1;
}

@media (max-width: 600px) {
    .orders-grid {
        grid-template-columns: 1fr;
    }

    .order-header {
        flex-direction: column;
    }

    .order-actions {
        flex-direction: column;
    }

    .order-actions form {
        width: 100%;
    }

    .rider-form {
        flex-direction: column;
    }
}
</style>
</head>

<body>
<div class="page-container">

<a href="index.php" class="back-link">
← Back to Menu
</a>

<div class="header-actions">
<a href="manager/rider_tracking.php" class="rider-tracking-btn">
Rider Tracking
</a>
</div>

<div class="header-section">
<h1>☕ Quick Re-Order</h1>
<p>
Re-order your favorite usual drinks & treats with one tap to save time on the go.
</p>
</div>

<?php if (!empty($message)): ?>
<div class="alert <?php echo htmlspecialchars($message_type); ?>">
<?php echo htmlspecialchars($message); ?>
</div>
<?php endif; ?>

<div class="orders-grid">

<?php if (empty($orders)): ?>
<div class="empty-history">
<p style="margin: 0; font-size: 1.1rem; font-weight: 600;">
No past orders found!
</p>
<p style="margin: 6px 0 0; font-size: 0.88rem;">
Once you place an order from the menu, your order presets will appear here for fast re-ordering.
</p>
</div>
<?php else: ?>

<?php foreach ($orders as $order): ?>
<?php
$feedback_data = null;
$feedback_check = $conn->prepare("
    SELECT rating, comment
    FROM order_feedback
    WHERE user_id = ?
    AND order_id = ?
    LIMIT 1
");

if ($feedback_check) {
    $feedback_check->bind_param("ii", $user_id, $order['order_id']);
    $feedback_check->execute();
    $feedback_result = $feedback_check->get_result();
    $feedback_data = $feedback_result->fetch_assoc();
    $feedback_check->close();
}

$status = strtolower(trim($order['status']));

$status_display = strtoupper(
    str_replace('_', ' ', $status)
);
?>

<div class="order-card">
<div>
<div class="order-header">
<div>
<h4 class="order-title">
Order #<?php echo (int)$order['order_id']; ?>
</h4>
<p class="order-date">
<?php echo htmlspecialchars($order['order_date']); ?>
</p>
</div>

<span class="status-badge status-<?php echo htmlspecialchars($status); ?>">
<?php echo htmlspecialchars($status_display); ?>
</span>
</div>

<div class="items-box">
<?php if (empty($order['items'])): ?>
<p style="margin: 0; font-size: 0.85rem; color: var(--text-muted); font-style: italic;">
Items processing...
</p>
<?php else: ?>

<?php foreach ($order['items'] as $item): ?>
<div class="item-row">
<div class="item-main">
<span>
<?php echo htmlspecialchars($item['product_name']); ?>
</span>
<span class="item-qty">
x<?php echo (int)$item['quantity']; ?>
</span>
</div>

<?php if (!empty($item['options'])): ?>
<div class="customization-details">
<?php foreach ($item['options'] as $label => $val): ?>
<div class="spec-line">
<span class="spec-label">
<?php echo htmlspecialchars($label); ?>:
</span>
<span class="spec-value">
<?php echo htmlspecialchars($val); ?>
</span>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<?php endforeach; ?>

<?php endif; ?>
</div>
</div>

<div class="rider-box">
<div class="rider-title">
Rider Assignment
</div>

<?php if (!empty($order['rider_id']) && !empty($order['rider_name'])): ?>
<div class="rider-current">
Assigned Rider:
<?php echo htmlspecialchars($order['rider_name']); ?>
</div>
<?php else: ?>
<div class="rider-current">
No rider assigned yet.
</div>

<?php if (!empty($available_riders)): ?>
<form action="diary.php" method="POST" class="rider-form">
<input type="hidden" name="action" value="assign_rider">
<input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">

<select name="rider_id" class="rider-select" required>
<option value="">Select Available Rider</option>
<?php foreach ($available_riders as $rider): ?>
<option value="<?php echo (int)$rider['id']; ?>">
<?php echo htmlspecialchars($rider['fullname']); ?>
</option>
<?php endforeach; ?>
</select>

<button type="submit" class="assign-btn">
Assign Rider
</button>
</form>
<?php else: ?>
<p class="no-rider">
No available riders right now.
</p>
<?php endif; ?>
<?php endif; ?>
</div>

<?php if (in_array($status, ['delivered', 'completed'], true)): ?>
    <?php if ($feedback_data): ?>
        <div class="feedback-saved">
            <strong>Your rating:</strong>
            <?php echo str_repeat('★', (int)$feedback_data['rating']); ?><?php echo str_repeat('☆', 5 - (int)$feedback_data['rating']); ?>
            <?php if (!empty($feedback_data['comment'])): ?>
                <div style="margin-top: 6px;"><?php echo nl2br(htmlspecialchars($feedback_data['comment'])); ?></div>
            <?php endif; ?>
            <div style="margin-top: 6px;">Thank you for your feedback!</div>
        </div>
    <?php else: ?>
        <form action="diary.php" method="POST" class="feedback-box">
            <div class="feedback-title">How was your order?</div>
            <input type="hidden" name="action" value="submit_feedback">
            <input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">

            <div class="feedback-rating" aria-label="Choose a rating from 1 to 5 stars">
                <?php for ($star = 1; $star <= 5; $star++): ?>
                    <input type="radio" id="rating-<?php echo (int)$order['order_id']; ?>-<?php echo $star; ?>" name="rating" value="<?php echo $star; ?>" required>
                    <label for="rating-<?php echo (int)$order['order_id']; ?>-<?php echo $star; ?>" title="<?php echo $star; ?> star<?php echo $star > 1 ? 's' : ''; ?>">★</label>
                <?php endfor; ?>
            </div>

            <textarea class="feedback-comment" name="comment" maxlength="1000" placeholder="Tell us about your experience (optional)"></textarea>
            <button type="submit" class="feedback-submit">Submit Feedback</button>
        </form>
    <?php endif; ?>
<?php endif; ?>

<div class="order-actions">
<form action="diary.php" method="POST">
<input type="hidden" name="action" value="reorder_entire_past_order">
<input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">
<button type="submit" class="reorder-btn">Re-Order</button>
</form>

<?php if (
    $status === 'pending' ||
    $status === 'placed' ||
    $status === 'in_preparation'
): ?>
<form action="diary.php" method="POST" onsubmit="return confirm('Mark this order as ready for pick up?');">
<input type="hidden" name="action" value="update_order_status">
<input type="hidden" name="status" value="ready_for_delivery">
<input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">
<button type="submit" class="ready-btn">Ready to Pick Up</button>
</form>
<?php endif; ?>

<?php if (
    $status === 'ready_for_delivery' ||
    $status === 'out_for_delivery'
): ?>
<form action="diary.php" method="POST" onsubmit="return confirm('Mark this order as delivered?');">
<input type="hidden" name="action" value="update_order_status">
<input type="hidden" name="status" value="completed">
<input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">
<button type="submit" class="delivered-btn">Mark as Delivered</button>
</form>
<?php endif; ?>

<?php if ($status === 'delivered'): ?>
<div style="flex: 1; min-width: 150px; padding: 12px; border-radius: 12px; background: #d1e7dd; color: #0f5132; font-size: 0.88rem; font-weight: 700; text-align: center;">
✓ Delivered
</div>
<?php endif; ?>

<form action="diary.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this order? This cannot be undone.');">
<input type="hidden" name="action" value="delete_order">
<input type="hidden" name="order_id" value="<?php echo (int)$order['order_id']; ?>">
<button type="submit" class="delete-btn">Delete</button>
</form>
</div>
</div>

<?php endforeach; ?>
<?php endif; ?>

</div>
</div>
</body>
</html>