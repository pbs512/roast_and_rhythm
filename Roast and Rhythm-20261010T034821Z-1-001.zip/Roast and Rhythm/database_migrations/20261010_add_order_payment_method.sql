ALTER TABLE orders
ADD COLUMN payment_method VARCHAR(50) NULL AFTER order_type;
