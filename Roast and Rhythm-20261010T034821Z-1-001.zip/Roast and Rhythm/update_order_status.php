<?php
// barista/update_order_status.php
include '../config/database.php';

// Prevent browser caching
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function normalizeStatus($status) {
    $status = strtolower(trim($status));
    $map = [
        'order placed'     => 'placed',
        'order_placed'    => 'placed',
        'preparing'        => 'in_preparation',
        'ready for pickup' => 'ready_for_pickup'
    ];
    return $map[$status] ?? $status;
}

// Handle AJAX Status Update Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_update'])) {
    // Suppress warning output to keep JSON clean
    ini_set('display_errors', 0);
    error_reporting(E_ALL);
    
    header('Content-Type: application/json');
    $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
    $raw_status = $_POST['new_status'] ?? '';
    $new_status = normalizeStatus($raw_status);

    $allowed_statuses = ['placed', 'in_preparation', 'ready_for_pickup', 'completed', 'cancelled'];

    if ($order_id > 0 && in_array($new_status, $allowed_statuses, true)) {
        // Standardized UPDATE query using core columns
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $new_status, $order_id);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => "Order #RR-{$order_id} updated successfully!"]);
            } else {
                echo json_encode(['success' => false, 'message' => "Database error: " . $stmt->error]);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => "Query prep error: " . $conn->error]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => "Invalid status or order ID."]);
    }
    exit;
}

// Fetch Active Orders
$query = "SELECT id, total_amount, status, order_type, table_number, created_at FROM orders WHERE status NOT IN ('completed', 'cancelled') ORDER BY id DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barista - Order Management</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #FAF7F2; color: #3D2314; padding: 20px; }
        .alert { padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-weight: 600; display: none; }
        .alert-success { background: #E2F0D9; color: #2B5B11; border: 1px solid #C5E0B4; }
        .alert-error { background: #FCE4D6; color: #C00000; border: 1px solid #F8CBAD; }
        .order-card { background: #FFF; border: 1px solid #EFE8DE; border-radius: 12px; padding: 16px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.04); transition: border-color 0.3s ease; }
        .order-info { font-weight: bold; font-size: 1.05rem; display: flex; align-items: center; gap: 10px; }
        .table-tag { background-color: #8C6239; color: #FFF; padding: 4px 10px; border-radius: 6px; font-size: 0.9rem; }
        .takeout-tag { background-color: #6c757d; color: #FFF; padding: 4px 10px; border-radius: 6px; font-size: 0.9rem; }
        
        /* Dynamic Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .status-placed { background-color: #FFF3CD; color: #856404; border: 1px solid #FFEEBA; }
        .status-in_preparation { background-color: #CCE5FF; color: #004085; border: 1px solid #B8DAFF; }
        .status-ready_for_pickup { background-color: #D4EDDA; color: #155724; border: 1px solid #C3E6CB; }
        .status-completed { background-color: #E2E3E5; color: #383D41; border: 1px solid #D6D8DB; }
        .status-cancelled { background-color: #F8D7DA; color: #721C24; border: 1px solid #F5C6CB; }

        /* Status Highlight Animation */
        @keyframes statusHighlight {
            0%   { transform: scale(1); box-shadow: 0 0 0px rgba(140, 98, 57, 0); }
            50%  { transform: scale(1.08); box-shadow: 0 0 12px rgba(140, 98, 57, 0.5); }
            100% { transform: scale(1); box-shadow: 0 0 0px rgba(140, 98, 57, 0); }
        }

        .status-updated {
            animation: statusHighlight 1.2s ease-in-out infinite;
        }

        select { padding: 8px 12px; border-radius: 8px; border: 1px solid #C49A6C; background: #FFF; font-weight: 600; color: #3D2314; }
        button { background-color: #3D2314; color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; margin-left: 8px; }
        button:hover { background-color: #8C6239; }
    </style>
</head>
<body>

    <h2>☕ Active Barista Orders</h2>
    <div id="flash-message" class="alert"></div>

    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($order = $result->fetch_assoc()): ?>
            <?php $current_status = normalizeStatus($order['status']); ?>
            <div class="order-card" id="order-card-<?php echo $order['id']; ?>">
                <div class="order-info">
                    <span>Order #RR-<?php echo $order['id']; ?></span> | 
                    <?php if (isset($order['order_type']) && $order['order_type'] === 'dine_in' && !empty($order['table_number'])): ?>
                        <span class="table-tag">📍 Table <?php echo htmlspecialchars($order['table_number']); ?></span>
                    <?php else: ?>
                        <span class="takeout-tag">🛍️ Takeout</span>
                    <?php endif; ?>
                    | <span>₱<?php echo number_format($order['total_amount'], 2); ?></span>
                    | <span class="status-badge status-<?php echo $current_status; ?>" id="badge-<?php echo $order['id']; ?>">
                        <?php echo strtoupper(str_replace('_', ' ', $current_status)); ?>
                      </span>
                </div>
                <form onsubmit="updateOrderStatus(event, <?php echo $order['id']; ?>)">
                    <select id="status-select-<?php echo $order['id']; ?>">
                        <option value="placed" <?php echo ($current_status === 'placed') ? 'selected' : ''; ?>>Order Placed</option>
                        <option value="in_preparation" <?php echo ($current_status === 'in_preparation') ? 'selected' : ''; ?>>In Preparation</option>
                        <option value="ready_for_pickup" <?php echo ($current_status === 'ready_for_pickup') ? 'selected' : ''; ?>>Ready for Pickup</option>
                        <option value="completed" <?php echo ($current_status === 'completed') ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo ($current_status === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                    <button type="submit">Update Status</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No active orders found.</p>
    <?php endif; ?>

<script>
function updateOrderStatus(event, orderId) {
    event.preventDefault();
    const selectElem = document.getElementById(`status-select-${orderId}`);
    const badgeElem = document.getElementById(`badge-${orderId}`);
    const newStatus = selectElem.value;
    const msgBox = document.getElementById('flash-message');

    const formData = new FormData();
    formData.append('ajax_update', '1');
    formData.append('order_id', orderId);
    formData.append('new_status', newStatus);

    fetch('update_order_status.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        msgBox.style.display = 'block';
        if (data.success) {
            msgBox.className = 'alert alert-success';
            msgBox.innerText = data.message;
            
            // Update badge text and class instantly
            if (badgeElem) {
                badgeElem.innerText = newStatus.replace('_', ' ').toUpperCase();
                badgeElem.className = `status-badge status-${newStatus} status-updated`;
                
                // Remove pulse animation after 3.6s
                setTimeout(() => {
                    badgeElem.classList.remove('status-updated');
                }, 3600);
            }

            // Remove completed or cancelled orders from barista active view instantly
            if (newStatus === 'completed' || newStatus === 'cancelled') {
                setTimeout(() => {
                    const card = document.getElementById(`order-card-${orderId}`);
                    if (card) card.remove();
                }, 1000);
            }
        } else {
            msgBox.className = 'alert alert-error';
            msgBox.innerText = data.message;
        }
    })
    .catch(err => {
        console.error("Update Error:", err);
        msgBox.style.display = 'block';
        msgBox.className = 'alert alert-error';
        msgBox.innerText = 'Network error during status update.';
    });
}
</script>

</body>
</html>