<?php

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {

    require_once '../Config/database.php';

    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'User not authenticated'
        ]);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);

    if (!is_array($data)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request data'
        ]);
        exit;
    }

    $user_id = (int)$_SESSION['user_id'];
    $plan_id = isset($data['plan_id']) ? (int)$data['plan_id'] : 1;
    $cups = isset($data['cups']) ? (int)$data['cups'] : 5;

    if ($plan_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid subscription plan'
        ]);
        exit;
    }

    if ($cups <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid number of cups'
        ]);
        exit;
    }

    $stmt = $conn->prepare("
        SELECT id, total_cups, remaining_cups
        FROM user_subscriptions
        WHERE user_id = ?
        AND status = 'active'
        LIMIT 1
    ");

    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $subscription = $result->fetch_assoc();

    $stmt->close();

    if ($subscription) {

        $new_total_cups =
            (int)$subscription['total_cups'] + $cups;

        $new_remaining_cups =
            (int)$subscription['remaining_cups'] + $cups;

        $update = $conn->prepare("
            UPDATE user_subscriptions
            SET total_cups = ?,
                remaining_cups = ?
            WHERE id = ?
        ");

        $subscription_id = (int)$subscription['id'];

        $update->bind_param(
            "iii",
            $new_total_cups,
            $new_remaining_cups,
            $subscription_id
        );

        $update->execute();
        $update->close();

        echo json_encode([
            'success' => true,
            'message' => 'Subscription updated successfully',
            'remaining_cups' => $new_remaining_cups
        ]);

        exit;
    }

    $plan_stmt = $conn->prepare("
        SELECT validity_days, total_cups
        FROM subscription_plans
        WHERE id = ?
        LIMIT 1
    ");

    $plan_stmt->bind_param("i", $plan_id);
    $plan_stmt->execute();

    $plan_result = $plan_stmt->get_result();
    $plan = $plan_result->fetch_assoc();

    $plan_stmt->close();

    if (!$plan) {
        echo json_encode([
            'success' => false,
            'message' => 'Subscription plan not found'
        ]);
        exit;
    }

    $validity_days = (int)$plan['validity_days'];

    $start_date = date('Y-m-d');

    $expiration_date = date(
        'Y-m-d',
        strtotime("+{$validity_days} days")
    );

    $insert = $conn->prepare("
        INSERT INTO user_subscriptions
        (
            user_id,
            plan_id,
            remaining_cups,
            total_cups,
            start_date,
            expiration_date,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, 'active')
    ");

    $insert->bind_param(
        "iiiiss",
        $user_id,
        $plan_id,
        $cups,
        $cups,
        $start_date,
        $expiration_date
    );

    $insert->execute();
    $insert->close();

    echo json_encode([
        'success' => true,
        'message' => 'Subscription purchased successfully',
        'remaining_cups' => $cups,
        'expiration_date' => $expiration_date
    ]);

} catch (Throwable $e) {

    http_response_code(200);

    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);

    exit;
}
?>