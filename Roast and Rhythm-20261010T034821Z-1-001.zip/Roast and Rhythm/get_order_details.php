<?php
header('Content-Type: application/json');

// Include your database connection (adjust filename/path as needed)
require_once 'config/db.php'; 

$order_id = $_GET['order_id'] ?? null;

if (!$order_id) {
    echo json_encode(['success' => false, 'message' => 'Order ID is required.']);
    exit;
}

try {
    // 1. Fetch Order Status
    $orderStmt = $pdo->prepare("SELECT status FROM orders WHERE id = ?");
    $orderStmt->execute([$order_id]);
    $order = $orderStmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found.']);
        exit;
    }

    // 2. Fetch Order Items joined with Product details
    $itemsStmt = $pdo->prepare("
        SELECT 
            oi.quantity, 
            oi.price, 
            p.name AS product_name 
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
    ");
    $itemsStmt->execute([$order_id]);
    $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate total price
    $total = array_reduce($items, function($sum, $item) {
        return $sum + ($item['price'] * $item['quantity']);
    }, 0);

    echo json_encode([
        'success' => true,
        'status'  => strtolower($order['status']), // e.g., 'placed', 'brewing', 'ready', 'served'
        'total'   => number_format($total, 2),
        'items'   => $items
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error.']);
}