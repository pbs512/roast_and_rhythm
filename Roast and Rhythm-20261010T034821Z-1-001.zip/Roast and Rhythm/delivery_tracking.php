<?php
session_start();
require_once "database.php";

$order_id = intval($_GET["order_id"] ?? 0);

if ($order_id <= 0) {
    die("Invalid order ID.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Track Your Order</title>

    <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    >

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: Arial, Helvetica, sans-serif;
            background: #f5f5f5;
            overflow: hidden;
        }

        #map {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        .top-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 70px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 20px;
            z-index: 1000;
            box-shadow: 0 2px 12px rgba(0,0,0,.12);
        }

        .back-btn {
            width: 42px;
            height: 42px;
            border: none;
            border-radius: 50%;
            background: #f3f3f3;
            font-size: 22px;
            cursor: pointer;
            margin-right: 14px;
        }

        .top-title {
            flex: 1;
        }

        .top-title h2 {
            margin: 0;
            font-size: 18px;
            color: #222;
        }

        .top-title p {
            margin: 3px 0 0;
            font-size: 12px;
            color: #777;
        }

        .live-badge {
            background: #e8f8ee;
            color: #15803d;
            padding: 8px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .bottom-panel {
            position: fixed;
            left: 50%;
            bottom: 20px;
            transform: translateX(-50%);
            width: calc(100% - 30px);
            max-width: 520px;
            background: white;
            border-radius: 24px;
            padding: 22px;
            z-index: 1000;
            box-shadow: 0 8px 35px rgba(0,0,0,.22);
        }

        .status-row {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 20px;
        }

        .status-icon {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: #fff0e8;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
        }

        .status-text {
            flex: 1;
        }

        .status-text h3 {
            margin: 0;
            font-size: 19px;
            color: #222;
        }

        .status-text p {
            margin: 5px 0 0;
            color: #777;
            font-size: 13px;
        }

        .eta {
            text-align: right;
        }

        .eta strong {
            display: block;
            font-size: 20px;
            color: #6f4e37;
        }

        .eta span {
            font-size: 11px;
            color: #888;
        }

        .progress {
            display: flex;
            align-items: center;
            margin: 15px 0 20px;
        }

        .progress-step {
            position: relative;
            flex: 1;
            text-align: center;
        }

        .progress-step::before {
            content: "";
            position: absolute;
            top: 13px;
            left: 50%;
            width: 100%;
            height: 4px;
            background: #e5e5e5;
            z-index: -1;
        }

        .progress-step:last-child::before {
            display: none;
        }

        .progress-dot {
            width: 28px;
            height: 28px;
            margin: 0 auto 7px;
            border-radius: 50%;
            background: #e4e4e4;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 12px;
            color: white;
            font-weight: bold;
        }

        .progress-step.active .progress-dot {
            background: #6f4e37;
        }

        .progress-step.active::before {
            background: #6f4e37;
        }

        .progress-step span {
            font-size: 10px;
            color: #777;
        }

        .rider-card {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 14px;
            background: #f8f8f8;
            border-radius: 16px;
        }

        .rider-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: #6f4e37;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
        }

        .rider-info {
            flex: 1;
        }

        .rider-info small {
            display: block;
            color: #888;
            font-size: 11px;
            margin-bottom: 3px;
        }

        .rider-info strong {
            display: block;
            color: #222;
            font-size: 15px;
        }

        .rider-info span {
            display: block;
            color: #15803d;
            font-size: 11px;
            margin-top: 3px;
        }

        .call-btn {
            width: 42px;
            height: 42px;
            border: none;
            border-radius: 50%;
            background: #6f4e37;
            color: white;
            font-size: 18px;
            cursor: pointer;
        }

        .order-info {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #777;
        }

        .order-info strong {
            color: #222;
        }

        .locate-btn {
            position: fixed;
            right: 20px;
            bottom: 365px;
            width: 48px;
            height: 48px;
            border: none;
            border-radius: 50%;
            background: white;
            z-index: 900;
            box-shadow: 0 4px 15px rgba(0,0,0,.2);
            font-size: 20px;
            cursor: pointer;
        }

        .custom-rider-marker {
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background: #6f4e37;
            border: 4px solid white;
            box-shadow: 0 4px 15px rgba(0,0,0,.35);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 21px;
        }

        @media (max-width: 600px) {

            .top-bar {
                height: 62px;
                padding: 0 14px;
            }

            .bottom-panel {
                bottom: 0;
                width: 100%;
                border-radius: 24px 24px 0 0;
                padding: 18px;
            }

            .locate-btn {
                right: 16px;
                bottom: 355px;
            }

            .status-text h3 {
                font-size: 17px;
            }

            .eta strong {
                font-size: 18px;
            }
        }
    </style>
</head>

<body>

<div id="map"></div>

<div class="top-bar">

    <button class="back-btn" onclick="history.back()">
        ←
    </button>

    <div class="top-title">
        <h2>Track Your Order</h2>
        <p>Order #RR-<?php echo $order_id; ?></p>
    </div>

    <div class="live-badge" id="liveBadge">
        ● LIVE
    </div>

</div>

<button class="locate-btn" onclick="centerOnRider()">
    ⌖
</button>

<div class="bottom-panel">

    <div class="status-row">

        <div class="status-icon" id="statusIcon">
            ☕
        </div>

        <div class="status-text">

            <h3 id="status">
                Waiting for order...
            </h3>

            <p id="statusDescription">
                We're preparing your order.
            </p>

        </div>

        <div class="eta">

            <strong id="eta">
                -- min
            </strong>

            <span>estimated</span>

        </div>

    </div>

    <div class="progress">

        <div class="progress-step" id="stepConfirmed">
            <div class="progress-dot">1</div>
            <span>Confirmed</span>
        </div>

        <div class="progress-step" id="stepPreparing">
            <div class="progress-dot">2</div>
            <span>Preparing</span>
        </div>

        <div class="progress-step" id="stepOnWay">
            <div class="progress-dot">3</div>
            <span>On the way</span>
        </div>

        <div class="progress-step" id="stepDelivered">
            <div class="progress-dot">4</div>
            <span>Delivered</span>
        </div>

    </div>

    <div class="rider-card">

        <div class="rider-avatar">
            🛵
        </div>

        <div class="rider-info">

            <small>Your rider</small>

            <strong id="rider">
                Finding rider...
            </strong>

            <span id="riderStatus">
                Waiting for live location
            </span>

        </div>

        <button class="call-btn" onclick="alert('Rider contact feature coming soon.')">
            ☎
        </button>

    </div>

    <div class="order-info">

        <span>
            Order
            <strong>#RR-<?php echo $order_id; ?></strong>
        </span>

        <span id="lastUpdate">
            Updating...
        </span>

    </div>

</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>

const orderId = <?php echo $order_id; ?>;

let map;
let riderMarker = null;
let riderLocation = null;

map = L.map("map", {
    zoomControl: false
}).setView([14.5995, 120.9842], 13);

L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
        attribution: "&copy; OpenStreetMap contributors"
    }
).addTo(map);

L.control.zoom({
    position: "topright"
}).addTo(map);

const riderIcon = L.divIcon({
    className: "",
    html: '<div class="custom-rider-marker">🛵</div>',
    iconSize: [46, 46],
    iconAnchor: [23, 23]
});

function resetProgress() {

    document.getElementById("stepConfirmed")
        .classList.remove("active");

    document.getElementById("stepPreparing")
        .classList.remove("active");

    document.getElementById("stepOnWay")
        .classList.remove("active");

    document.getElementById("stepDelivered")
        .classList.remove("active");
}

function updateProgress(status) {

    resetProgress();

    const confirmed =
        document.getElementById("stepConfirmed");

    const preparing =
        document.getElementById("stepPreparing");

    const onWay =
        document.getElementById("stepOnWay");

    const delivered =
        document.getElementById("stepDelivered");

    if (status === "pending") {

        confirmed.classList.add("active");

    } else if (
        status === "preparing" ||
        status === "confirmed"
    ) {

        confirmed.classList.add("active");
        preparing.classList.add("active");

    } else if (
        status === "out_for_delivery" ||
        status === "on_the_way"
    ) {

        confirmed.classList.add("active");
        preparing.classList.add("active");
        onWay.classList.add("active");

    } else if (status === "delivered") {

        confirmed.classList.add("active");
        preparing.classList.add("active");
        onWay.classList.add("active");
        delivered.classList.add("active");
    }
}

function updateStatus(status) {

    const title =
        document.getElementById("status");

    const description =
        document.getElementById("statusDescription");

    const icon =
        document.getElementById("statusIcon");

    const eta =
        document.getElementById("eta");

    if (status === "pending") {

        title.textContent =
            "Order confirmed!";

        description.textContent =
            "Your order has been received.";

        icon.textContent = "✓";

        eta.textContent = "-- min";

    } else if (
        status === "preparing" ||
        status === "confirmed"
    ) {

        title.textContent =
            "Your coffee is being prepared";

        description.textContent =
            "Our barista is preparing your order.";

        icon.textContent = "☕";

        eta.textContent = "-- min";

    } else if (
        status === "out_for_delivery" ||
        status === "on_the_way"
    ) {

        title.textContent =
            "Your coffee is on the way!";

        description.textContent =
            "Your rider is heading to you.";

        icon.textContent = "🛵";

        eta.textContent = "Live";

    } else if (status === "delivered") {

        title.textContent =
            "Order delivered!";

        description.textContent =
            "Enjoy your coffee!";

        icon.textContent = "✓";

        eta.textContent = "Done";

    } else {

        title.textContent =
            "Order status";

        description.textContent =
            "We're keeping you updated.";

        eta.textContent = "-- min";
    }

    updateProgress(status);
}

async function getRiderLocation() {

    try {

        const response = await fetch(
            "get_rider_location.php?order_id=" +
            orderId +
            "&t=" +
            Date.now()
        );

        const data = await response.json();

        if (!data.success) {

            updateStatus("pending");

            document.getElementById("rider")
                .textContent = "Finding rider...";

            document.getElementById("riderStatus")
                .textContent = "Waiting for live location";

            document.getElementById("lastUpdate")
                .textContent = "Waiting...";

            return;
        }

        const latitude =
            parseFloat(data.latitude);

        const longitude =
            parseFloat(data.longitude);

        riderLocation = [
            latitude,
            longitude
        ];

        const currentStatus =
            data.status || "out_for_delivery";

        updateStatus(currentStatus);

        document.getElementById("rider")
            .textContent =
            data.rider_name || "Rider";

        document.getElementById("riderStatus")
            .textContent =
            "● Live location active";

        document.getElementById("lastUpdate")
            .textContent =
            "Updated just now";

        if (riderMarker === null) {

            riderMarker = L.marker(
                [latitude, longitude],
                {
                    icon: riderIcon
                }
            ).addTo(map);

            riderMarker.bindPopup(
                "<strong>" +
                (data.rider_name || "Rider") +
                "</strong><br>" +
                "Your coffee is on the way."
            );

            map.setView(
                [latitude, longitude],
                16
            );

        } else {

            riderMarker.setLatLng([
                latitude,
                longitude
            ]);
        }

        calculateETA();

    } catch (error) {

        document.getElementById("status")
            .textContent =
            "Connection problem";

        document.getElementById("statusDescription")
            .textContent =
            "Trying to reconnect to live tracking...";

        document.getElementById("riderStatus")
            .textContent =
            "Reconnecting...";
    }
}

function calculateETA() {

    if (!riderLocation) {
        return;
    }

    document.getElementById("eta")
        .textContent = "Live";
}

function centerOnRider() {

    if (!riderLocation) {
        return;
    }

    map.setView(
        riderLocation,
        17,
        {
            animate: true
        }
    );

    if (riderMarker) {
        riderMarker.openPopup();
    }
}

getRiderLocation();

setInterval(
    getRiderLocation,
    5000
);

</script>

</body>
</html>