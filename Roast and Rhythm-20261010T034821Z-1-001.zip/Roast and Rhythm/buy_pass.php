<?php

session_start();

header('Content-Type: application/json; charset=utf-8');

try {

    require_once '../Config/database.php';

    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Please log in to buy a coffee pass.'
        ]);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);

    if (!is_array($data)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request data.'
        ]);
        exit;
    }

    $user_id = (int)$_SESSION['user_id'];
    $plan_id = isset($data['plan_id']) ? (int)$data['plan_id'] : 0;

    if ($plan_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Please select a valid subscription plan.'
        ]);
        exit;
    }

    $stmt = $conn->prepare("
        SELECT id, validity_days, total_cups
        FROM subscription_plans
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param("i", $plan_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $plan = $result->fetch_assoc();

    $stmt->close();

    if (!$plan) {
        echo json_encode([
            'success' => false,
            'message' => 'Subscription plan not found.'
        ]);
        exit;
    }

    $validityDays = (int)$plan['validity_days'];
    $totalCups = (int)$plan['total_cups'];

    if ($validityDays <= 0) {
        $validityDays = 30;
    }

    if ($totalCups <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'This subscription plan has no available cups.'
        ]);
        exit;
    }

    $startDate = date('Y-m-d H:i:s');

    $expirationDate = date(
        'Y-m-d H:i:s',
        strtotime("+{$validityDays} days")
    );

    $check = $conn->prepare("
        SELECT id
        FROM user_subscriptions
        WHERE user_id = ?
        AND status = 'active'
        LIMIT 1
    ");

    $check->bind_param("i", $user_id);
    $check->execute();

    $checkResult = $check->get_result();
    $existing = $checkResult->fetch_assoc();

    $check->close();

    if ($existing) {

        $subscriptionId = (int)$existing['id'];

        $update = $conn->prepare("
            UPDATE user_subscriptions
            SET plan_id = ?,
                remaining_cups = ?,
                total_cups = ?,
                start_date = ?,
                expiration_date = ?,
                status = 'active'
            WHERE id = ?
        ");

        $update->bind_param(
            "iiissi",
            $plan_id,
            $totalCups,
            $totalCups,
            $startDate,
            $expirationDate,
            $subscriptionId
        );

        $update->execute();
        $update->close();

    } else {

        $insert = $conn->prepare("
            INSERT INTO user_subscriptions
            (
                user_id,
                plan_id,
                remaining_cups,
                total_cups,
                start_date,
                expiration_date,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, 'active')
        ");

        $insert->bind_param(
            "iiiiss",
            $user_id,
            $plan_id,
            $totalCups,
            $totalCups,
            $startDate,
            $expirationDate
        );

        $insert->execute();
        $insert->close();
    }

    echo json_encode([
        'success' => true,
        'message' => 'Pass activated successfully!',
        'cups' => $totalCups,
        'expiration_date' => $expirationDate
    ]);

    exit;

} catch (Throwable $e) {

    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);

    exit;
}
?>